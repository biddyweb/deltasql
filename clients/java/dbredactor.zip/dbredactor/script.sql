-- Please make sure this script is executed on the correct schema!!

-- version: 268 module: allegro-collection date: 2012-11-06 15:40:16 
-- applied to:  HEAD 

/*
repower Mantis 1913 oct/nov CO2 curves II
*/
select * from pricevalue where pricedate='2012-11-05' order by priceindex,pricedate,delivdate;
--delete from pricevalue where pricedate='2012-11-05';

-- repower Mantis 1913 oct/nov CO2 curves
SELECT * FROM valuation WHERE valuation=102841; -- 5.11.2012 23:20
SELECT * FROM valuation WHERE valuation=102842; -- 5.11.2012 23:30

SELECT p.counterparty, p.positiontype, p.marketarea, p.product, SUM(quantity) AS qty, SUM(pricequantity) AS pqty, SUM(value) AS cv, SUM(marketvalue) AS mv
FROM valuationdetail vd, position p
WHERE vd.valuation = 102841
AND vd.position = p.position
GROUP BY p.counterparty, p.positiontype, p.marketarea, p.product 
ORDER BY p.counterparty ASC,p.positiontype ASC, p.marketarea ASC, p.product ASC;

SELECT p.counterparty, p.positiontype, p.marketarea, p.product, SUM(quantity) AS qty, SUM(pricequantity) AS pqty, SUM(value) AS cv, SUM(marketvalue) AS mv
FROM valuationdetail vd, position p
WHERE vd.valuation = 102842
AND vd.position = p.position
GROUP BY p.counterparty, p.positiontype, p.marketarea, p.product 
ORDER BY p.counterparty ASC,p.positiontype ASC, p.marketarea ASC, p.product ASC;

-- valuationdetail count
SELECT count(*) FROM valuationdetail WHERE valuation=102841;
SELECT count(*) FROM valuationdetail WHERE valuation=102842;

-- detail of BNP_P difference
SELECT * FROM valuationdetail vd, position p WHERE vd.position=p.position AND p.counterparty='BNP_P' AND valuation=102841 ORDER BY p.trade ASC, valuationdetail ASC;
SELECT * FROM valuationdetail vd, position p WHERE vd.position=p.position AND p.counterparty='BNP_P' AND valuation=102842 ORDER BY p.trade ASC, valuationdetail ASC;

SELECT * FROM trade WHERE trade IN (138166,138466,141882,142162);

SELECT * FROM valuationdetail vd, position p WHERE vd.position=p.position AND p.counterparty='Credit Agricole' AND exposure='MARKET' AND valuation=102841 ORDER BY p.trade ASC, valuationdetail ASC;
SELECT * FROM valuationdetail vd, position p WHERE vd.position=p.position AND p.counterparty='Credit Agricole' AND exposure='MARKET' AND valuation=102842 ORDER BY p.trade ASC, valuationdetail ASC;

ELECT * FROM valuationdetail vd, position p WHERE vd.position=p.position AND p.counterparty='SET' AND exposure='POSITION' 
AND p.positiontype='SELL' AND valuation=102841 and p.product='CER' ORDER BY p.trade ASC, valuationdetail ASC;
SELECT * FROM valuationdetail vd, position p WHERE vd.position=p.position AND p.counterparty='SET' AND exposure='POSITION' 
AND p.positiontype='SELL' AND valuation=102842 and p.product='CER'  ORDER BY p.trade ASC, valuationdetail ASC;


SELECT * FROM valuationdetail vd, position p WHERE vd.position=p.position AND p.counterparty='SET' AND exposure='POSITION' 
AND p.positiontype='SELL' AND valuation=102841 and p.product='EUA' ORDER BY p.trade ASC, valuationdetail ASC;
SELECT * FROM valuationdetail vd, position p WHERE vd.position=p.position AND p.counterparty='SET' AND exposure='POSITION' 
AND p.positiontype='SELL' AND valuation=102842 and p.product='EUA'  ORDER BY p.trade ASC, valuationdetail ASC;


select p.* from trade t, position p where trade in (136084, 136063);





-- version: 271 module: allegro-collection date: 2012-11-09 16:18:59 
-- applied to:  HEAD 

/*
analyze how a trade values over time in cv, mv and m2m
*/
select * from trade where trade in (136084, 136063);

select v.valuationtime, sum(vd.value) as cv, sum(vd.marketvalue) as mv, (sum(vd.value)-sum(vd.marketvalue)) as m2m from valuationdetail vd, valuation v where 
vd.trade=136084 
and vd.valuation=v.valuation
and v.valuationmode='Position'
and v.valuationtime in (
select DATEADD(HOUR, 23, valuationdate) from cvwEoDValuationTimeHistory where valuationdate>='2012-10-01' and valuationdate<'2012-11-01') 
group by v.valuationtime
order by v.valuationtime asc;


select v.valuationtime, sum(vd.value) as cv, sum(vd.marketvalue) as mv, (sum(vd.value)-sum(vd.marketvalue)) as m2m from valuationdetail vd, valuation v where 
vd.trade=136063
and vd.valuation=v.valuation
and v.valuationmode='Position'
and v.valuationtime in (
select DATEADD(HOUR, 23, valuationdate) from cvwEoDValuationTimeHistory where valuationdate>='2012-10-01' and valuationdate<'2012-11-01') 
group by v.valuationtime
order by v.valuationtime asc;


-- version: 272 module: allegro-collection date: 2012-11-20 15:55:39 
-- applied to:  HEAD 

EXEC cspCheckConveyEffDate;

select top 100 * from cstinterfaceaudit order by creationdate desc;
delete from cstinterfaceaudit where id_cia in (33906983,33906982)
------------------------------

USE [Allegro]
GO
/****** Object:  StoredProcedure [dbo].[cspCheckConveyEffDate]    Script Date: 12/10/2012 16:19:30 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
*  Stored Procedure cspCheckConveyEffDate
*
*  This stored procedure goes through counterparties for which a convey was executed and which are set to INVALID.
*  If it finds trades with an enddate after the convey.effdate it outputs an error into cstinterfaceaudit
*
* Test with
* EXEC cspCheckConveyEffDate
* select top 1000 * from cstinterfaceaudit order by creationdate desc;
*
*  author: tiziano.mengotti
*  last changed: 20.11.2012
*/


ALTER PROCEDURE [dbo].[cspCheckConveyEffDate] AS
BEGIN
DECLARE @cpty VARCHAR(255);
DECLARE @sourcecpty VARCHAR(255);
DECLARE @effdate DATETIME;
DECLARE @maxenddate DATETIME;
DECLARE @tradecount INT;
DECLARE @tradeid INT;
DECLARE @tradeenddate DATETIME;
DECLARE @tradedate DATETIME;
DECLARE @message VARCHAR(255);

DECLARE cpty_cursor CURSOR FOR 
SELECT counterparty, sourcecounterparty,effdate
FROM counterpartyconvey
ORDER BY sourcecounterparty;

EXECUTE cspUpdateInterfaceAudit 'ConveyCk','0', '0', 'cspCheckConveyEffDate', 'INFO', 'Starting check on conveys...'                        

OPEN cpty_cursor

FETCH NEXT FROM cpty_cursor 
INTO @cpty, @sourcecpty, @effdate

WHILE @@FETCH_STATUS = 0
BEGIN
    SELECT @tradecount=count(*) FROM trade t, position p WHERE p.trade=t.trade AND p.counterparty=@sourcecpty AND t.tradestatus NOT IN ('NEW', 'void') AND tradetype NOT LIKE '%Emissions%'
    --PRINT 'cpty: '+@cpty+' sourcecpty: '+@sourcecpty+' tradecount: '+CAST(@tradecount as varchar(10))

    IF (@tradecount>0) 
                BEGIN
                        SELECT @maxenddate=MAX(t.enddate) FROM trade t, position p WHERE p.trade=t.trade AND p.counterparty=@sourcecpty AND t.tradestatus NOT IN ('NEW', 'void') AND tradetype NOT LIKE '%Emissions%'
                        --PRINT 'maxenddate: '+CAST(@maxenddate AS varchar(12))+' effdate: '+CAST(@effdate AS varchar(12))

                        IF (@maxenddate>@effdate)
                                BEGIN
                                        SELECT @message='ERROR, there is at least one trade with counterparty '+@sourcecpty+' conveyed to '+@cpty+' which extends after convey.effdate of '+CAST(@effdate AS varchar(12))
										PRINT @message
                                        EXECUTE cspUpdateInterfaceAudit 'ConveyCk','1', '0', 'cspCheckConveyEffDate', 'ERROR', @Message
                    
                    
                                        DECLARE td_cursor CURSOR FOR 
                                        SELECT t.trade, t.enddate, t.tradedate
                                        FROM trade t, position p WHERE p.trade=t.trade AND p.counterparty=@sourcecpty AND t.enddate>@effdate
                                                   AND t.tradestatus NOT IN ('NEW', 'void') AND tradetype NOT LIKE '%Emissions%'
                                        ORDER BY t.trade;
                                                        
										OPEN td_cursor

                                        FETCH NEXT FROM td_cursor 
										INTO @tradeid, @tradeenddate, @tradedate
                                        WHILE @@FETCH_STATUS = 0
										BEGIN
											SELECT @message='cpty: '+@sourcecpty+' tradeid: '+CAST(@tradeid AS VARCHAR(12))+' enddate: '+CAST(@tradeenddate AS VARCHAR(12))+
                                            ' tradedate: '+CAST(@tradedate AS VARCHAR(12))
                                            PRINT @message
											EXECUTE cspUpdateInterfaceAudit 'ConveyCk','2', '0', 'cspCheckConveyEffDate', 'ERROR', @Message
                    
											FETCH NEXT FROM td_cursor 
											INTO @tradeid, @tradeenddate, @tradedate
                                        END

                                        CLOSE td_cursor;
										DEALLOCATE td_cursor;

                                END --if
        END -- if

    FETCH NEXT FROM cpty_cursor 
    INTO @cpty, @sourcecpty, @effdate    
END  -- while
CLOSE cpty_cursor;
DEALLOCATE cpty_cursor;

EXECUTE cspUpdateInterfaceAudit 'ConveyCk','3', '0', 'cspCheckConveyEffDate', 'INFO', 'Convey check completed.'
END


-- version: 273 module: allegro-collection date: 2012-11-23 18:24:41 
-- applied to:  HEAD 

/*
EoD PnL Profit and Loss detail for Fabio Zanetti
*/
/*
v5
*/
SELECT 
--1
cr.bidrate AS CHFEUR, t.csttradingstrategy, t.currency AS originalcurrency, ft.fintransact,ft.company, ft.subledger, CONVERT(VARCHAR(19),ft.acctdate,20) AS acctdate,
ft.counterparty, ft.currency, ft.finstatus,
--2
ft.valuation, ft.invoice, CONVERT(VARCHAR(19),ft.duedate,20) AS duedate,ft.invoicetype, ft.transactiontype, CONVERT(VARCHAR(19),ft.voiddate, 20) AS voiddate,
CONVERT(VARCHAR(19),ft.conveydate,20) AS conveydate, ft.collaboration,
-- findetail
fd.cstsalestaxcode,fd.findetail,fd.fintransact,fd.account,fd.description,fd.trade,fd.position,fd.posdetail,CONVERT(VARCHAR(19),fd.begtime,20) AS begtime,CONVERT(VARCHAR(19),fd.endtime,20) AS endtime,fd.contract,
fd.fee,fd.invoice, CONVERT(VARCHAR(19),fd.invoicedate,20) AS invoicedate,fd.product,fd.grossquantity,fd.price,fd.pricequantity,fd.quantity,
fd.priceunit, fd.unit,fd.decint, fd.grossvalue,fd.credit,fd.debit,fd.taxlocation,fd.confirmstatus,fd.company,fd.counterparty,fd.currency,
fd.paymentterms, fd.quantitystatus, fd.acctstatus, fd.point, fd.controlarea, CONVERT(VARCHAR(19),fd.settlementdate,20) AS settlementdate,
fd.tradebook, fd.marketarea,  CONVERT(VARCHAR(19),mtmaccrualdate,20) AS mtmaccrualdate, fd.vintageyear, fd.cstaccountingpurpose,fd.csttradingstrategy,fd.cstexternalid,
CONVERT(VARCHAR(19),fd.creationdate,20) AS creationdate,fd.cstsalestaxcode,fd.term,fd.producttype,fd.tsperiod,fd.cstgenplantname
FROM findetail fd,fintransact ft, trade t, currexchrate cr 
WHERE 
fd.fintransact=ft.fintransact 
AND ft.acctdate>='2012-01-01' AND ft.acctdate<'2013-01-01'
AND fd.trade=t.trade AND
cr.pricedate=ft.acctdate AND cr.basecurrency='CHF' AND cr.quotecurrency='EUR';

select distinct ft.acctdate from fintransact ft where  ft.acctdate>='2012-01-01' AND ft.acctdate<'2013-01-01' order by ft.acctdate asc;

/*
* v4
*/
-- valuationdetail
SELECT p.positiontype, t.trade,vd.fee,vd.cstdeliverymonth,vd.description,vd.currency, sum(vd.quantity)/2 AS quantity,sum(vd.pricequantity)/2 as pricequantity,
sum(vd.value) AS value, sum(vd.marketvalue) AS marketvalue, sum(vd.marketvalue)-sum(vd.value) AS mtm
 FROM valuationdetail vd, valuation v, trade t, position p WHERE
 v.valuation=vd.valuation AND v.valuationtime='2012-10-31 23:00' AND v.valuationmode='Position' AND
vd.trade=t.trade /*AND t.cstaccountingpurpose='HfT' */ 
AND vd.begtime>='2012-01-01 00:00:00'
AND p.trade=t.trade 
GROUP BY p.positiontype, t.trade,vd.fee,vd.cstdeliverymonth,vd.description,vd.currency;

-- trade summary
SELECT t.trade,t.tradestatus,t.cstaccountingpurpose,p.product,p.positiontype,p.block,p.counterparty,t.currency,p.tradebook,t.csttradingstrategy,CONVERT(VARCHAR(19),t.tradedate,20) AS tradedate,
       CONVERT(VARCHAR(19),t.begtime,20) AS begtime,CONVERT(VARCHAR(19),t.endtime,20) AS endtime,p.company,t.tradeclass,t.trader,
 CONVERT(VARCHAR(19),t.creationdate,20) AS creationdate, CONVERT(VARCHAR(19),t.revisiondate,20) AS revisiondate
FROM trade t, position p
WHERE
p.trade=t.trade
AND t.begtime>='2012-01-01 00:00:00';

-- fintransact and findetail
SELECT 
--1
cr.bidrate AS CHFEUR, t.csttradingstrategy, t.currency AS originalcurrency, ft.fintransact,ft.company, ft.subledger, CONVERT(VARCHAR(19),ft.acctdate,20) AS acctdate,
ft.counterparty, ft.currency, ft.finstatus,
--2
ft.valuation, ft.invoice, CONVERT(VARCHAR(19),ft.duedate,20) AS duedate,ft.invoicetype, ft.transactiontype, CONVERT(VARCHAR(19),ft.voiddate, 20) as voiddate,
CONVERT(VARCHAR(19),ft.conveydate,20) AS conveydate, ft.collaboration,
-- findetail
fd.cstsalestaxcode,fd.findetail,fd.fintransact,fd.account,fd.description,fd.trade,fd.position,fd.posdetail,CONVERT(VARCHAR(19),fd.begtime,20) as begtime,CONVERT(VARCHAR(19),fd.endtime,20) as endtime,fd.contract,
fd.fee,fd.invoice, CONVERT(VARCHAR(19),fd.invoicedate,20) AS invoicedate,fd.product,fd.grossquantity,fd.price,fd.pricequantity,fd.quantity,
fd.priceunit, fd.unit,fd.decint, fd.grossvalue,fd.credit,fd.debit,fd.taxlocation,fd.confirmstatus,fd.company,fd.counterparty,fd.currency,
fd.paymentterms, fd.quantitystatus, fd.acctstatus, fd.point, fd.controlarea, CONVERT(VARCHAR(19),fd.settlementdate,20) AS settlementdate,
fd.tradebook, fd.marketarea,  CONVERT(VARCHAR(19),mtmaccrualdate,20) AS mtmaccrualdate, fd.vintageyear, fd.cstaccountingpurpose,fd.csttradingstrategy,fd.cstexternalid,
CONVERT(VARCHAR(19),fd.creationdate,20) AS creationdate,fd.cstsalestaxcode,fd.term,fd.producttype,fd.tsperiod,fd.cstgenplantname
FROM findetail fd,fintransact ft, trade t, currexchrate cr 
WHERE 
fd.fintransact=ft.fintransact 
AND ft.acctdate IN 
('2012-12-31', '2012-11-30','2012-10-31','2012-09-30','2012-08-31','2012-07-31','2012-06-30','2012-05-31','2012-04-30','2012-03-31','2012-02-29','2012-01-31') AND
fd.trade=t.trade AND
cr.pricedate=ft.acctdate AND cr.basecurrency='CHF' AND cr.quotecurrency='EUR';



/*
* v3
*/

SELECT CONVERT(VARCHAR(19),t.tradedate,20) AS tradedate, CONVERT(VARCHAR(19),vd.begtime,20) AS begtime, CONVERT(VARCHAR(19),vd.endtime,20) AS endtime, vd.quantity, vd.price, 
vd.quantitystatus, vd.value, vd.marketprice, vd.marketvalue, vd.trade, vd.description, vd.unit, vd.exposure,
vd.currency, CONVERT(VARCHAR(19),vd.duedate,20) AS duedate, CONVERT(VARCHAR(19),vd.settlementdate,20) AS settlementdate, vd.company, vd.counterparty, vd.trader, vd.tradebook, 
vd.transactiontype, vd.marketarea, vd.csttradingstrategy, vd.positionmode, vd.producttype, vd.tradetype, vd.block,
vd.cstdeliveryyear, vd.cstdeliveryquarter, vd.cstdeliverymonth, vd.cstnpvalue0, vd.cstnpvalue1, vd.cstnpvalue2, vd.cstnpvalue3,vd.cstgenplantname,vd.cstexternalid,p.positiontype
FROM valuationdetail vd, valuation v, trade t, position p WHERE
v.valuation=vd.valuation AND v.valuationtime='2012-10-31 23:00' AND  
vd.trade=t.trade AND vd.position=p.position AND
t.cstaccountingpurpose='HfT' 
AND vd.begtime>='2012-01-01 00:00:00';
--order by vd.trade;


SELECT t.trade, t.status, vd.fee, vd.cstdeliverymonth, sum(vd.quantity) as quantity,
sum(vd.value) as value, sum(vd.marketvalue) as marketvalue
 FROM valuationdetail vd, valuation v, trade t, fee f WHERE
 v.valuation=vd.valuation AND v.valuationtime='2012-10-31 23:00' AND  
vd.trade=t.trade /*AND t.cstaccountingpurpose='HfT' */ 
AND vd.begtime>='2012-01-01 00:00:00'
group by t.trade,t.status,vd.fee,vd.cstdeliverymonth;

/*
*
*
v1
*
*/

select t.tradedate, vd.begtime, vd.endtime, vd.quantity, vd.price, vd.quantitystatus, vd.value, vd.marketprice, vd.marketvalue, vd.trade, vd.description, vd.unit, vd.exposure,
vd.currency, vd.duedate, vd.settlementdate, vd.company, vd.counterparty, vd.trader, vd.tradebook, vd.transactiontype, vd.marketarea, vd.csttradingstrategy, vd.positionmode, vd.producttype, vd.tradetype, vd.block,
vd.cstdeliveryyear, vd.cstdeliveryquarter, vd.cstdeliverymonth, vd.cstnpvalue0, vd.cstnpvalue1, vd.cstnpvalue2, vd.cstnpvalue3
 from valuationdetail vd, valuation v, trade t where
 v.valuation=vd.valuation and v.valuationtime='2012-10-31 23:00' and  
vd.trade=t.trade and t.cstaccountingpurpose='HfT' 
and vd.begtime>='2012-01-01 00:00:00';
--order by vd.trade;

select count(*)
 from valuationdetail vd, valuation v, trade t where
 v.valuation=vd.valuation and v.valuationtime='2012-10-31 23:00' and  
vd.trade=t.trade and t.cstaccountingpurpose='HfT' 
and vd.begtime>='2012-01-01 00:00:00';

select * from findetail fd, fintransact ft where fd.fintransact=ft.fintransact and ft.acctdate='2012-10-31';

select top 100 * from findetail;
select top 100 * from fintransact;

select count(*) from findetail fd, fintransact ft where fd.fintransact=ft.fintransact and ft.acctdate='2012-10-31';

select t.csttradingstrategy, t.currency, ft.*, fd.* from findetail fd, fintransact ft, trade t 
where 
fd.fintransact=ft.fintransact and ft.acctdate='2012-10-31' and
fd.trade=t.trade;


-- version: 274 module: allegro-collection date: 2012-11-27 14:29:31 
-- applied to:  HEAD 
-- marked as: view 
/*
view reset for Logistics views related to KWoffline trade
*/
select * from userconfig where configkey in ('EnergyPositionbyBook/hourflatViewState','PowerSchedulingPOSGenerationViewState') and userid<>'SYSTEM';
--delete from userconfig where configkey in ('EnergyPositionbyBook/hourflatViewState','PowerSchedulingPOSGenerationViewState') and userid<>'SYSTEM';

select * from viewselectcriteria where value like '%KWoff%';
select * from userconfig;


-- version: 275 module: allegro-collection date: 2012-11-29 15:34:16 
-- applied to:  HEAD 

-- it is possible to delete a Settlement valuation if findetail records are not generated
-- check with
SELECT * FROM findetail fd, valuationdetail vd WHERE fd.valuationdetail=vd.valuationdetail AND vd.valuation=103679;

--delete from valuationdetail where valuation=103568;

--delete from cstvaluationaggregation where valuation=103568;

--delete from valuation where valuation=103568;




-- version: 276 module: allegro-collection date: 2012-11-30 14:31:59 
-- applied to:  HEAD 
-- marked as: view 
select * from userconfig where userid='SYSTEM';
select * from viewname where viewname like '%EoD HoM%';

select distinct viewpane from viewcolumn where viewname='EoD HoM Power Open Position Detail';
select dbtable,dbcolumn,label,visible from viewcolumn where viewname='EoD HoM Power Open Position Detail' /*and visible=1*/ and viewpane='position_valuation' order by dbcolumn asc;
select * from viewcriteria where viewname='EoD HoM Power Open Position Detail';


select distinct viewpane from viewcolumn where viewname='EoD HoM Power Open Position';
select dbtable,dbcolumn,label,visible from viewcolumn where viewname='EoD HoM Power Open Position' /*and visible=1*/ and viewpane='position_valuation' order by dbcolumn asc;
select * from viewcriteria where viewname='EoD HoM Power Open Position';

select distinct viewpane from viewcolumn where viewname='EoD HoM Emissions Open Position Detail';
select dbtable,dbcolumn,label,visible from viewcolumn where viewname='EoD HoM Emissions Open Position Detail' /*and visible=1*/ and viewpane='position_valuation' order by dbcolumn asc;
select * from viewcriteria where viewname='EoD HoM Emissions Open Position Detail';



-- version: 278 module: allegro-collection date: 2012-12-04 10:22:44 
-- applied to:  HEAD 
-- marked as: view 
DROP TABLE dbo.cstpriceindexcheck;
CREATE TABLE dbo.cstpriceindexcheck (
   [cstpriceindexcheck] [varchar](32) NOT NULL,
   [active] [bit] NULL DEFAULT ((1)),
   [warninglevel] [varchar](32) NOT NULL /*DEFAULT ('ERROR')*/,
   [wkday] [varchar](32) NOT NULL /*DEFAULT ('1234567')*/, 
   [evening] [bit] NULL DEFAULT ((0)),
   [afternoon] [bit] NULL DEFAULT ((0)),
   [endofmonth] [bit] NULL DEFAULT ((1)),
   [validfrom] [datetime] NULL,
   [validto] [datetime] NULL,
   [countatleast] [int] NOT NULL DEFAULT ((1)),
   [creationname] [varchar](64) NOT NULL,
   [creationdate] [datetime] NOT NULL,
   [revisionname] [varchar](64) NULL,
   [revisiondate] [datetime] NULL,
   CONSTRAINT [pk_cstpriceindexchek] PRIMARY KEY CLUSTERED ([cstpriceindexcheck] ASC) ON [PRIMARY]
); 
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('CO2 CER Forward', 1, 'ERROR', '123456',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('CO2 CER Settlement', 1, 'ERROR', '123456',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('CO2 EUA Forward', 1, 'ERROR', '123456',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('CO2 EUA Settlement', 1, 'ERROR', '123456',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power AT Hour Forward', 1, 'ERROR', '123456',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power AT Hour Settle', 1, 'ERROR', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power AT Offpeak Day Forward', 1, 'ERROR', '123456',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power AT Offpeak Settle', 1, 'ERROR', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power AT Peak Day Forward', 1, 'ERROR', '123456',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power AT Peak Settle', 1, 'ERROR', '23456',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power Capacity AT/CH Hour Settle', 1, 'ERROR', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power Capacity CH/AT Hour Settle', 1, 'ERROR', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power Capacity CH/DE Hour Settle', 1, 'ERROR', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power Capacity CH/FR Hour Settle', 1, 'ERROR', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power Capacity CH/IT Hour Settle', 1, 'ERROR', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power Capacity DE/CH Hour Settle', 1, 'ERROR', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power Capacity FR/CH Hour Settle', 1, 'ERROR', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power Capacity FR/IT Hour Settle', 1, 'WARNING', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power Capacity IT/CH Hour Settle', 1, 'ERROR', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power Capacity IT/FR Hour Settle', 1, 'WARNING', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power CH Hour Forward', 1, 'ERROR', '123456',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power CH Hour Settle', 1, 'ERROR', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power CH Offpeak Day Forward', 1, 'ERROR', '123456',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power CH Offpeak Settle', 1, 'ERROR', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power CH Peak Day Forward', 1, 'ERROR', '123456',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power CH Peak Settle', 1, 'ERROR', '23456',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power DE Hour Forward', 1, 'ERROR', '123456',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power DE Hour Settle', 1, 'ERROR', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power DE Offpeak Day Forward', 1, 'ERROR', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power DE Offpeak Settle', 1, 'ERROR', '123456',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power DE Peak Day Forward', 1, 'ERROR', '123456',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power DE Peak Settle', 1, 'ERROR', '23456',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power FR Hour Forward', 1, 'ERROR', '123456',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power FR Hour Settle', 1, 'ERROR', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power FR Offpeak Day Forward', 1, 'ERROR', '123456',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power FR Offpeak Settle', 1, 'ERROR', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power FR Peak Day Forward', 1, 'ERROR', '123456',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power FR Peak Settle', 1, 'ERROR', '23456',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power IT IPEX CSud Hour Forward', 1, 'WARNING', '123456',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power IT IPEX CSud Hour Settle', 1, 'WARNING', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power IT IPEX North Hour Forward', 1, 'ERROR', '123456',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power IT IPEX North Hour Settle', 1, 'ERROR', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power IT IPEX PUN Hour Forward', 1, 'ERROR', '123456',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power IT IPEX PUN Hour Settle', 1, 'ERROR', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power IT IPEX Sicily Hour Forwar', 1, 'WARNING', '123456',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power IT IPEX Sicily Hour Settle', 1, 'WARNING', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power IT IPEX Sud Hour Forward', 1, 'WARNING', '123456',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power IT IPEX Sud Hour Settle', 1, 'WARNING', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power IT MI1 CSud Hour Settle', 1, 'WARNING', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power IT MI1 North Hour Settle', 1, 'WARNING', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power IT MI1 Sicily Hour Settle', 1, 'WARNING', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power IT MI1 Sud Hour Settle', 1, 'WARNING', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power IT MI2 CSud Hour Settle', 1, 'WARNING', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power IT MI2 North Hour Settle', 1, 'WARNING', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power IT MI2 Sicily Hour Settle', 1, 'WARNING', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power IT MI2 Sud Hour Settle', 1, 'WARNING', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power IT Offpeak Day Forward', 1, 'ERROR', '123456',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power IT Offpeak Settle', 1, 'ERROR', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power IT Peak Day Forward', 1, 'ERROR', '123456',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power IT Peak Settle', 1, 'ERROR', '123456',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power NP Base Day Forward', 1, 'ERROR', '123456',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power NP Base Quarter Forward', 1, 'ERROR', '123456',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power NP Base Settle', 1, 'ERROR', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power NP Base Year Forward', 1, 'ERROR', '123456',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power VaR Month Forward', 1, 'WARNING', '123456',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('SET PPA MB Down Settle', 1, 'WARNING', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('SET PPA MB Up Settle', 1, 'WARNING', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('SET PPA MSD Down Settle', 1, 'WARNING', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('SET PPA MSD Up Settle', 1, 'WARNING', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('SET PPA Settle', 1, 'WARNING', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());

select * from dbo.cstpriceindexcheck;

-- datamodel update for Allegro
DELETE from dbtable where dbtable='cstpriceindexcheck';
INSERT INTO dbo.dbtable(dbtable, dbgroup, dbdefinition, dbprevious, label, datamethod, scopestatus,creationname,creationdate)
VALUES('cstpriceindexcheck','Price','This table defines prices to be monitored by cspCheckPriceCurves','','Checks on Price Curves','Configuration',0,'Tiziano Mengotti',getdate());

/*
   [priceindex] [varchar](32) NOT NULL,
   [active] [bit] NULL DEFAULT ((1)),
   [warninglevel] [varchar](32) NOT NULL /*DEFAULT ('ERROR')*/,
   [wkday] [varchar](32) NOT NULL /*DEFAULT ('1234567')*/, 
   [evening] [bit] NULL DEFAULT ((0)),
   [afternoon] [bit] NULL DEFAULT ((0)),
   [endofmonth] [bit] NULL DEFAULT ((1)),
   [validfrom] [datetime] NULL,
   [validto] [datetime] NULL,
   [countatleast] [int] NOT NULL DEFAULT ((1)),
   [creationname] [varchar](64) NOT NULL,
   [creationdate] [datetime] NOT NULL,
   [revisionname] [varchar](64) NULL,
   [revisiondate] [datetime] NULL,*/W

SELECT * FROM dbobject WHERE dbtable='cstpriceindexcheck' ORDER BY dbseq ASC;
DELETE FROM dbobject WHERE dbtable='cstpriceindexcheck';
INSERT INTO dbo.dbobject (dbtable, dbseq, dbcolumn, dbtype, dblen, dbprecision, dbdefinition, dbprimarykey, dbindex, dbnull, label, dbsysgen, dbdefault, dbconstraint, dbprevious, creationname, creationdate)
VALUES ('cstpriceindexcheck', 1, 'cstpriceindexcheck', 'varchar', 32, 0, 'Priceindex on which to perform the check', 1, 0, 0, 'Price Index',0,'','','cstpriceindexcheck','Tiziano Mengotti', getdate());
INSERT INTO dbo.dbobject (dbtable, dbseq, dbcolumn, dbtype, dblen, dbprecision, dbdefinition, dbprimarykey, dbindex, dbnull, label, dbsysgen, dbdefault, dbconstraint, dbprevious, creationname, creationdate)
VALUES ('cstpriceindexcheck', 2, 'active', 'boolean', 1, 0, 'If the check is active or not', 0, 0, 1, 'Active',0,'1','','','Tiziano Mengotti', getdate());
INSERT INTO dbo.dbobject (dbtable, dbseq, dbcolumn, dbtype, dblen, dbprecision, dbdefinition, dbprimarykey, dbindex, dbnull, label, dbsysgen, dbdefault, dbconstraint, dbprevious, creationname, creationdate)
VALUES ('cstpriceindexcheck', 3, 'warninglevel', 'varchar', 32, 0, 'Warning level: WARNING, ERROR, INFO are allowed', 0, 0, 0, 'Warning Level',0,'','','','Tiziano Mengotti', getdate());
INSERT INTO dbo.dbobject (dbtable, dbseq, dbcolumn, dbtype, dblen, dbprecision, dbdefinition, dbprimarykey, dbindex, dbnull, label, dbsysgen, dbdefault, dbconstraint, dbprevious, creationname, creationdate)
VALUES ('cstpriceindexcheck', 4, 'wkday', 'varchar', 32, 0, 'On which days the curves are loaded: 1 - Sunday, 2 - Monday, ... , 7 - Saturday', 0, 0, 0, 'Weekday',0,'','','','Tiziano Mengotti', getdate());
INSERT INTO dbo.dbobject (dbtable, dbseq, dbcolumn, dbtype, dblen, dbprecision, dbdefinition, dbprimarykey, dbindex, dbnull, label, dbsysgen, dbdefault, dbconstraint, dbprevious, creationname, creationdate)
VALUES ('cstpriceindexcheck', 5, 'evening', 'boolean', 1, 0, 'This price is loaded in the evening', 0, 0, 1, 'Evening',0,'0','','','Tiziano Mengotti', getdate());
INSERT INTO dbo.dbobject (dbtable, dbseq, dbcolumn, dbtype, dblen, dbprecision, dbdefinition, dbprimarykey, dbindex, dbnull, label, dbsysgen, dbdefault, dbconstraint, dbprevious, creationname, creationdate)
VALUES ('cstpriceindexcheck', 6, 'afternoon', 'boolean', 1, 0, 'This price is loaded in the afternoon', 0, 0, 1, 'Afternoon',0,'0','','','Tiziano Mengotti', getdate());
INSERT INTO dbo.dbobject (dbtable, dbseq, dbcolumn, dbtype, dblen, dbprecision, dbdefinition, dbprimarykey, dbindex, dbnull, label, dbsysgen, dbdefault, dbconstraint, dbprevious, creationname, creationdate)
VALUES ('cstpriceindexcheck', 7, 'endofmonth', 'boolean', 1, 0, 'This price is loaded at the end of month', 0, 0, 1, 'End of Month',0,'0','','','Tiziano Mengotti', getdate());
INSERT INTO dbo.dbobject (dbtable, dbseq, dbcolumn, dbtype, dblen, dbprecision, dbdefinition, dbprimarykey, dbindex, dbnull, label, dbsysgen, dbdefault, dbconstraint, dbprevious, creationname, creationdate)
VALUES ('cstpriceindexcheck', 8, 'countatleast', 'int', 8, 0, 'Minimal amount of prices to be loaded', 0, 0, 0, 'At least',0,'0','','','Tiziano Mengotti', getdate());
INSERT INTO dbo.dbobject (dbtable, dbseq, dbcolumn, dbtype, dblen, dbprecision, dbdefinition, dbprimarykey, dbindex, dbnull, label, dbsysgen, dbdefault, dbconstraint, dbprevious, creationname, creationdate)
VALUES ('cstpriceindexcheck', 9, 'validfrom', 'datetime', 8, 0, 'Valid From', 0, 0, 1, 'Valid From',0,'0','','','Tiziano Mengotti', getdate());
INSERT INTO dbo.dbobject (dbtable, dbseq, dbcolumn, dbtype, dblen, dbprecision, dbdefinition, dbprimarykey, dbindex, dbnull, label, dbsysgen, dbdefault, dbconstraint, dbprevious, creationname, creationdate)
VALUES ('cstpriceindexcheck', 10, 'validto', 'datetime', 8, 0, 'Valid To', 0, 0, 1, 'Valid To',0,'0','','','Tiziano Mengotti', getdate());
INSERT INTO dbo.dbobject (dbtable, dbseq, dbcolumn, dbtype, dblen, dbprecision, dbdefinition, dbprimarykey, dbindex, dbnull, label, dbsysgen, dbdefault, dbconstraint, dbprevious, creationname, creationdate)
VALUES ('cstpriceindexcheck', 11, 'creationname', 'varchar', 64, 0, 'Creation Name', 0, 0, 0, 'Creation Name',0,'0','','creationname','Tiziano Mengotti', getdate());
INSERT INTO dbo.dbobject (dbtable, dbseq, dbcolumn, dbtype, dblen, dbprecision, dbdefinition, dbprimarykey, dbindex, dbnull, label, dbsysgen, dbdefault, dbconstraint, dbprevious, creationname, creationdate)
VALUES ('cstpriceindexcheck', 12,'creationdate', 'datetime', 8, 0, 'Creation Date', 0, 0, 0, 'Creation Date',0,'0','','creationdate','Tiziano Mengotti', getdate());
INSERT INTO dbo.dbobject (dbtable, dbseq, dbcolumn, dbtype, dblen, dbprecision, dbdefinition, dbprimarykey, dbindex, dbnull, label, dbsysgen, dbdefault, dbconstraint, dbprevious, creationname, creationdate)
VALUES ('cstpriceindexcheck', 13, 'revisionname', 'varchar', 64, 0, 'Revision Name', 0, 0, 1, 'Revision Name',0,'0','','revisionname','Tiziano Mengotti', getdate());
INSERT INTO dbo.dbobject (dbtable, dbseq, dbcolumn, dbtype, dblen, dbprecision, dbdefinition, dbprimarykey, dbindex, dbnull, label, dbsysgen, dbdefault, dbconstraint, dbprevious, creationname, creationdate)
VALUES ('cstpriceindexcheck', 14, 'revisiondate', 'datetime', 8, 0, 'Revision Date', 0, 0, 1, 'Revision Date',0,'0','','revisiondate','Tiziano Mengotti', getdate());


/*
delete from viewpane where viewname='Repower Parameters' and viewpane='cstPriceIndexChecks';
INSERT INTO dbo.viewpane (viewname, viewpane, priority, sortseq, panetype, charttype, timecolumn, datatable, autoheight, autosizecolumn, viewpanetitle, viewpanefont, viewpanefontsize, viewpanefontbold, visible, securitycriteria, creationname, creationdate)
VALUES ('Repower Parameters', 'cstPriceIndexChecks',1,8,'GRID',NULL,NULL,'cstpriceindexcheck',0,0,'Priceindex Checks', 'Arial',8,0,1,0,'Tiziano Mengotti',getdate());
*/

select * from dbconstraint where dbconstraint like 'cstpriceindexcheck';
delete from dbo.dbconstraint where dbconstraint='cstpriceindexcheck';
INSERT INTO dbo.dbconstraint (dbconstraint, constrainttype, dbtable, dbcolumn, dbsearch, dbexpr, creationname, creationdate)
VALUES('cstpriceindexcheck','DDDW','cstpriceindexcheck','cstpriceindexcheck','cstpriceindexcheck','status='+CHAR(39)+'ACTIVE'+CHAR(39),'SYSTEM',getdate()); 

select * from viewcolumn where viewname='Repower Parameters' and viewpane='cstPriceIndexChecks' --and gridseq in (2,3);

delete from viewcolumn where viewname='Repower Parameters' and viewpane='cstPriceIndexChecks';
INSERT INTO dbo.viewcolumn (viewname,viewpane,viewcolumn,gridseq,dbtable,dbcolumn,label,visible,sortseq,sortorder,viewdefault,subtotal,grandtotal,drill,pagebreak,crosstab,crosstabtype,linkview,expression,columnedit,columnreq,columngroup,creationname,creationdate)
VALUES('Repower Parameters','cstPriceIndexChecks','cstpriceindexcheck',1,'cstpriceindexcheck','cstpriceindexcheck','Price Index',1,1,'ASC',NULL,0,0,0,0,NULL,NULL,NULL,NULL,0,0,0,'Tiziano Mengotti',getdate() );
INSERT INTO dbo.viewcolumn (viewname,viewpane,viewcolumn,gridseq,dbtable,dbcolumn,label,visible,sortseq,sortorder,viewdefault,subtotal,grandtotal,drill,pagebreak,crosstab,crosstabtype,linkview,expression,columnedit,columnreq,columngroup,creationname,creationdate)
VALUES('Repower Parameters','cstPriceIndexChecks','active',2,'cstpriceindexcheck','active','Active',1,NULL,NULL,NULL,0,0,0,0,NULL,NULL,NULL,NULL,0,0,0,'Tiziano Mengotti',getdate() );
INSERT INTO dbo.viewcolumn (viewname,viewpane,viewcolumn,gridseq,dbtable,dbcolumn,label,visible,sortseq,sortorder,viewdefault,subtotal,grandtotal,drill,pagebreak,crosstab,crosstabtype,linkview,expression,columnedit,columnreq,columngroup,creationname,creationdate)
VALUES('Repower Parameters','cstPriceIndexChecks','warninglevel',3,'cstpriceindexcheck','warninglevel','Warning Level',1,NULL,NULL,NULL,0,0,0,0,NULL,NULL,NULL,NULL,0,0,0,'Tiziano Mengotti',getdate() );
INSERT INTO dbo.viewcolumn (viewname,viewpane,viewcolumn,gridseq,dbtable,dbcolumn,label,visible,sortseq,sortorder,viewdefault,subtotal,grandtotal,drill,pagebreak,crosstab,crosstabtype,linkview,expression,columnedit,columnreq,columngroup,creationname,creationdate)
VALUES('Repower Parameters','cstPriceIndexChecks','wkday',4,'cstpriceindexcheck','wkday','Week Day',1,NULL,NULL,NULL,0,0,0,0,NULL,NULL,NULL,NULL,0,0,0,'Tiziano Mengotti',getdate() );

INSERT INTO dbo.viewcolumn (viewname,viewpane,viewcolumn,gridseq,dbtable,dbcolumn,label,visible,sortseq,sortorder,viewdefault,subtotal,grandtotal,drill,pagebreak,crosstab,crosstabtype,linkview,expression,columnedit,columnreq,columngroup,creationname,creationdate)
VALUES('Repower Parameters','cstPriceIndexChecks','evening',5,'cstpriceindexcheck','evening','Evening',1,NULL,NULL,NULL,0,0,0,0,NULL,NULL,NULL,NULL,0,0,0,'Tiziano Mengotti',getdate() );
INSERT INTO dbo.viewcolumn (viewname,viewpane,viewcolumn,gridseq,dbtable,dbcolumn,label,visible,sortseq,sortorder,viewdefault,subtotal,grandtotal,drill,pagebreak,crosstab,crosstabtype,linkview,expression,columnedit,columnreq,columngroup,creationname,creationdate)
VALUES('Repower Parameters','cstPriceIndexChecks','afternoon',6,'cstpriceindexcheck','afternoon','Afternoon',1,NULL,NULL,NULL,0,0,0,0,NULL,NULL,NULL,NULL,0,0,0,'Tiziano Mengotti',getdate() );
INSERT INTO dbo.viewcolumn (viewname,viewpane,viewcolumn,gridseq,dbtable,dbcolumn,label,visible,sortseq,sortorder,viewdefault,subtotal,grandtotal,drill,pagebreak,crosstab,crosstabtype,linkview,expression,columnedit,columnreq,columngroup,creationname,creationdate)
VALUES('Repower Parameters','cstPriceIndexChecks','endofmonth',7,'cstpriceindexcheck','endofmonth','End Of Month',1,NULL,NULL,NULL,0,0,0,0,NULL,NULL,NULL,NULL,0,0,0,'Tiziano Mengotti',getdate() );
INSERT INTO dbo.viewcolumn (viewname,viewpane,viewcolumn,gridseq,dbtable,dbcolumn,label,visible,sortseq,sortorder,viewdefault,subtotal,grandtotal,drill,pagebreak,crosstab,crosstabtype,linkview,expression,columnedit,columnreq,columngroup,creationname,creationdate)
VALUES('Repower Parameters','cstPriceIndexChecks','countatleast',8,'cstpriceindexcheck','countatleast','Count At Least',1,NULL,NULL,NULL,0,0,0,0,NULL,NULL,NULL,NULL,0,0,0,'Tiziano Mengotti',getdate() );

INSERT INTO dbo.viewcolumn (viewname,viewpane,viewcolumn,gridseq,dbtable,dbcolumn,label,visible,sortseq,sortorder,viewdefault,subtotal,grandtotal,drill,pagebreak,crosstab,crosstabtype,linkview,expression,columnedit,columnreq,columngroup,creationname,creationdate)
VALUES('Repower Parameters','cstPriceIndexChecks','validfrom',9,'cstpriceindexcheck','validfrom','Valid From',1,NULL,NULL,NULL,0,0,0,0,NULL,NULL,NULL,NULL,0,0,0,'Tiziano Mengotti',getdate() );
INSERT INTO dbo.viewcolumn (viewname,viewpane,viewcolumn,gridseq,dbtable,dbcolumn,label,visible,sortseq,sortorder,viewdefault,subtotal,grandtotal,drill,pagebreak,crosstab,crosstabtype,linkview,expression,columnedit,columnreq,columngroup,creationname,creationdate)
VALUES('Repower Parameters','cstPriceIndexChecks','validto',10,'cstpriceindexcheck','validto','Valid To',1,NULL,NULL,NULL,0,0,0,0,NULL,NULL,NULL,NULL,0,0,0,'Tiziano Mengotti',getdate() );


INSERT INTO dbo.viewcolumn (viewname,viewpane,viewcolumn,gridseq,dbtable,dbcolumn,label,visible,sortseq,sortorder,viewdefault,subtotal,grandtotal,drill,pagebreak,crosstab,crosstabtype,linkview,expression,columnedit,columnreq,columngroup,creationname,creationdate)
VALUES('Repower Parameters','cstPriceIndexChecks','creationname',20,'cstpriceindexcheck','creationname','Creation Name',1,NULL,NULL,NULL,0,0,0,0,NULL,NULL,NULL,NULL,1,0,0,'Tiziano Mengotti',getdate() );
INSERT INTO dbo.viewcolumn (viewname,viewpane,viewcolumn,gridseq,dbtable,dbcolumn,label,visible,sortseq,sortorder,viewdefault,subtotal,grandtotal,drill,pagebreak,crosstab,crosstabtype,linkview,expression,columnedit,columnreq,columngroup,creationname,creationdate)
VALUES('Repower Parameters','cstPriceIndexChecks','creationdate',21,'cstpriceindexcheck','creationdate','Creation Date',1,NULL,NULL,NULL,0,0,0,0,NULL,NULL,NULL,NULL,1,0,0,'Tiziano Mengotti',getdate() );
INSERT INTO dbo.viewcolumn (viewname,viewpane,viewcolumn,gridseq,dbtable,dbcolumn,label,visible,sortseq,sortorder,viewdefault,subtotal,grandtotal,drill,pagebreak,crosstab,crosstabtype,linkview,expression,columnedit,columnreq,columngroup,creationname,creationdate)
VALUES('Repower Parameters','cstPriceIndexChecks','revisionname',22,'cstpriceindexcheck','revisionname','Revision Name',1,NULL,NULL,NULL,0,0,0,0,NULL,NULL,NULL,NULL,1,0,0,'Tiziano Mengotti',getdate() );
INSERT INTO dbo.viewcolumn (viewname,viewpane,viewcolumn,gridseq,dbtable,dbcolumn,label,visible,sortseq,sortorder,viewdefault,subtotal,grandtotal,drill,pagebreak,crosstab,crosstabtype,linkview,expression,columnedit,columnreq,columngroup,creationname,creationdate)
VALUES('Repower Parameters','cstPriceIndexChecks','revisiondate',23,'cstpriceindexcheck','revisiondate','Revision Date',1,NULL,NULL,NULL,0,0,0,0,NULL,NULL,NULL,NULL,1,0,0,'Tiziano Mengotti',getdate() );


BEGIN
   DECLARE @pricedate DATETIME;
   DECLARE @weekday INT;
   DECLARE @priceidxck VARCHAR(32);   
   DECLARE @warninglevel VARCHAR(32);
   DECLARE @countatleast INT;
   DECLARE @curcount INT;
   DECLARE @message VARCHAR(255);

   SELECT @pricedate=(SELECT DATEADD(dd, DATEDIFF(dd,0,getdate()-1), 0));
   SELECT @weekday=DATEPART(WEEKDAY, GETDATE()-1);
   PRINT 'Launching price curve check for '+ CAST(@pricedate AS varchar(20))+' (weekday '+CAST(@weekday AS VARCHAR(10))+')'

   DECLARE curve_cursor CURSOR FOR 
   SELECT cpi.cstpriceindexcheck,cpi.warninglevel,cpi.countatleast FROM cstpriceindexcheck cpi
   WHERE cpi.active=1 AND cpi.wkday like '%'+CAST(@weekday AS VARCHAR(1))+'%'ORDER BY cpi.cstpriceindexcheck;

   OPEN curve_cursor

   FETCH NEXT FROM curve_cursor 
   INTO @priceidxck,@warninglevel,@countatleast

   WHILE @@FETCH_STATUS = 0
   BEGIN
       --PRINT 'Currently checking '+@priceidxck+' with warning level '+@warninglevel+' and minimal count '+CAST(@countatleast AS VARCHAR(6))
	   
	   SELECT @curcount=count(*) from pricevalue where pricedate=@pricedate and priceindex=@priceidxck;
       
       IF (@curcount<@countatleast) 
			BEGIN
                IF (@curcount=0)
                   SELECT @message='No prices found for priceindex "'+@priceidxck+'" on pricedate '+CONVERT(VARCHAR(19),@pricedate,20)
                ELSE
                   SELECT @message=CAST(@curcount AS VARCHAR(6))+' prices found for priceindex "'+@priceidxck+'" on pricedate '+CONVERT(VARCHAR(19),@pricedate,20)+', but at least '+
                                   CAST(@countatleast AS VARCHAR(6))+' required!'

                PRINT @message
                --EXECUTE cspUpdateInterfaceAudit 'PriceCk','1', '0', 'cspCheckPriceCurves', @warninglevel, @Message
         	END

	   FETCH NEXT FROM curve_cursor 
       INTO @priceidxck,@warninglevel,@countatleast
   END -- WHILE over cstpriceindexcheck

   CLOSE curve_cursor;
   DEALLOCATE curve_cursor;
   PRINT 'Price curve check over.'
END


-- version: 279 module: allegro-collection date: 2012-12-05 11:41:19 
-- applied to:  HEAD 

/*
"Allegro.DbAdapterException: Arithmetic overflow error converting numeric to data type numeric.
The statement has been terminated.
SQL:INSERT INTO valuationdetail (valuationdetail.valuationdetail, valuationdetail.valuation, valuationdetail.position, valuationdetail.posdetail, valuationdetail.begtime, valuationdetail.endtime, valuationdetail.timezone, valuationdetail.shipment, valuationdetail.measure, valuationdetail.tsperiod, valuationdetail.credittype, valuationdetail.futuremonth, valuationdetail.expirationdate, valuationdetail.settlementdate, valuationdetail.daylightsaving, valuationdetail.marketdayhour, valuationdetail.cycle, valuationdetail.taxlocation, valuationdetail.optionstatus, valuationdetail.exposure, valuationdetail.priceindex, valuationdetail.compositeindex, valuationdetail.exposuretype, valuationdetail.pricestatus, valuationdetail.currencyfactor, valuationdetail.quantitystatus, valuationdetail.description, valuationdetail.quantitytype, valuationdetail.positionstatus, valuationdetail.settlementstatus, valuationdetail.evergreenstatus, valuationdetail.pricedate, valuationdetail.quantity, valuationdetail.pricequantity, valuationdetail.exposurequantity, valuationdetail.unit, valuationdetail.value, valuationdetail.price, valuationdetail.marketvalue, valuationdetail.marketprice, valuationdetail.currency, valuationdetail.priceunit, valuationdetail.npvfactor, valuationdetail.validation, valuationdetail.strikeprice, valuationdetail.optrefprice, valuationdetail.intrate, valuationdetail.optionvalue, valuationdetail.delta, valuationdetail.gamma, valuationdetail.theta, valuationdetail.vega, valuationdetail.rho, valuationdetail.volatility, valuationdetail.promptvolatility, valuationdetail.var, valuationdetail.creditexposure, valuationdetail.creditvar, valuationdetail.creationname, valuationdetail.creationdate, valuationdetail.quantitycontribution, valuationdetail.deltacontribution, valuationdetail.gammacontribution, valuationdetail.thetacontribution, valuationdetail.vegacontribution, valuationdetail.rhocontribution, valuationdetail.interactioncontribution, valuationdetail.netcontribution, valuationdetail.movement, valuationdetail.company, valuationdetail.counterparty, valuationdetail.contract, valuationdetail.trade, valuationdetail.trader, valuationdetail.tradebook, valuationdetail.paymentterms, valuationdetail.transactiontype, valuationdetail.subledger, valuationdetail.product, valuationdetail.component, valuationdetail.block, valuationdetail.marketarea, valuationdetail.carrier, valuationdetail.location, valuationdetail.property, valuationdetail.pile, valuationdetail.quality, valuationdetail.tradetype, valuationdetail.feetype, valuationdetail.fee, valuationdetail.tier, valuationdetail.strategy, valuationdetail.strategydetail, valuationdetail.hedge, valuationdetail.hypothetical, valuationdetail.producttype, valuationdetail.valuationexposure, valuationdetail.valuationproduct, valuationdetail.valuationperiod, valuationdetail.pricebegtime, valuationdetail.priceendtime, valuationdetail.accountname, valuationdetail.accountnumber, valuationdetail.cascadable, valuationdetail.cascadedate, valuationdetail.cascadereference, valuationdetail.cstaccountingpurpose, valuationdetail.cstcompetencycentre, valuationdetail.cstdeliverydate, valuationdetail.cstdeliverymonth, valuationdetail.cstdeliveryquarter, valuationdetail.cstdeliveryyear, valuationdetail.cstexternalid, valuationdetail.cstgenplantname, valuationdetail.cstmarketaccesscc, valuationdetail.cstmarketregion, valuationdetail.cstmtmvalue, valuationdetail.cstnpvalue, valuationdetail.cstnpvalue0, valuationdetail.cstnpvalue1, valuationdetail.cstnpvalue2, valuationdetail.cstnpvalue3, valuationdetail.cstnpvyear0, valuationdetail.cstnpvyear1, valuationdetail.cstnpvyear2, valuationdetail.cstnpvyear3, valuationdetail.cstquantityoffpeak, valuationdetail.cstquantitypeak, valuationdetail.cstquantityrealised, valuationdetail.cstquantityrealisedoffpeak, valuationdetail.cstquantityrealisedpeak, valuationdetail.cstquantityunrealised, valuationdetail.cstquantityunrealisedoffpeak, valuationdetail.cstquantityunrealisedpeak, valuationdetail.cstrealisedvalue, valuationdetail.cstregroup, valuationdetail.csttradingstrategy, valuationdetail.cstunrealisedvalue, valuationdetail.duedate, valuationdetail.marginfactor, valuationdetail.matched, valuationdetail.matchedquantity, valuationdetail.phase, valuationdetail.positionmode, valuationdetail.productclass, valuationdetail.program, valuationdetail.settlephysically, valuationdetail.term, valuationdetail.tradeclass, valuationdetail.vintageyear) 
VALUES (341746860, '103583', '145302', '137940', '2012-12-01 00:00:00.000', '2012-12-05 00:00:00.000', 'CET', null, null, 'Off Peak', 'DELIVERED', null, null, '2012-12-01 00:00:00.000', 0, 0, null, 'Germany', null, 'POSITION', null, null, null, 'FIXED', 1, 'PLAN', 'TENNET_D', 'DELIVERY', null, 0, null, null, 0.0000, 0, 0.0000, 'MWh', 0, -38810416666666612.83333, 0, 0, 'EUR', 'MWh', 1, null, 0.000000, 0, 0.00, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'http://192.168.0.29/allegro', '2012-12-05 03:09:34.810', null, null, null, null, null, null, null, 0, 0, 'RE_AG', 'EXAA', '100645', '145053', 'Daniela Luzzi', 'POS Market Place', '20th DAY', 'AR', null, 'Power Profile', null, 'Profile', 'DE', 'TENNET_D', 'TENNET_D', null, null, null, 'Power Profile', null, null, null, null, null, null, 0, 'Power', null, null, null, null, null, null, null, 0, null, null, 'OU', 'POS', '2012-12-01 00:00:00.000', null, null, null, null, 'EXAA', null, null, 0, 0, 0, 0, 0, 0, '2012', '2013', '2014', '2015', 0.0000, 0, 0.0000, 0.0000, 0, 0.0000, 0.0000, 0, 0, 'Repower', 'POS-MP-SMA', 0, null, 0.000000, 0, 0, null, 'PHYSICAL', 'Power Profile', null, 0, 'MT', 'MP', null)  ---> System.Data.SqlClient.SqlException: Arithmetic overflow error converting numeric to data type numeric.
The statement has been terminated.
   at System.Data.Common.DbDataAdapter.UpdatedRowStatusErrors(RowUpdatedEventArgs rowUpdatedEvent, BatchCommandInfo[] batchCommands, Int32 commandCount)
   at System.Data.Common.DbDataAdapter.UpdatedRowStatus(RowUpdatedEventArgs rowUpdatedEvent, BatchCommandInfo[] batchCommands, Int32 commandCount)
   at System.Data.Common.DbDataAdapter.Update(DataRow[] dataRows, DataTableMapping tableMapping)
   at System.Data.Common.DbDataAdapter.UpdateFromDataTable(DataTable dataTable, DataTableMapping tableMapping)
   at System.Data.Common.DbDataAdapter.Update(DataSet dataSet, String srcTable)
   at Allegro.Data.DbAdapter.Update(DataTable[] dtUpdates, String[] selectSqls, Boolean sysGen, Boolean backgroundProcess)
   --- End of inner exception stack trace ---
   at Allegro.Data.DbAdapter.SetGenericDbUpdateException(Exception e, DataSet updatingDS, String dbErrorMessage)
   at Allegro.Data.DbAdapter.Update(DataTable[] dtUpdates, String[] selectSqls, Boolean sysGen, Boolean backgroundProcess)
   at Allegro.Data.DbAdapter.Update(DataTable[] dtUpdates)
   at Allegro.Valuation.Valuation.Update(SelectCriteria selectCriteria)
   at Allegro.Valuation.Valuation.<>c__DisplayClassa.<CreateValuationByValuationMode>b__8()
   at Allegro.Valuation.Diagnostic.ValuationPerfMon.LogExecutionTime(ValuationPerfMonArgs perfMonArgs, PerfMonMethod perfMonDelegate)
   at Allegro.Valuation.Valuation.CreateValuationByValuationMode(SelectCriteria selectCriteria)
   at Allegro.Valuation.Valuation.CreateValuation(SelectCriteria selectCriteria)
   at Allegro.Valuation.Diagnostic.ValuationPerfMon.LogExecutionTime(ValuationPerfMonArgs perfMonArgs, PerfMonMethod perfMonDelegate)
   at Allegro.Valuation.Valuation.Invoke(WorkerParam parameters)
   at Allegro.GridWorker.Invoke(Object stateinfo)"
*/

-- position: 145302  posdetail: 137940

-- Trade 145053 per il 4.12 o il 5.12
select pq.* from trade t, position p, powerquantity pq
where p.trade=t.trade and p.position=pq.position
and pq.begtime>='2012-12-04' and pq.begtime<'2012-12-06'
and t.trade=145053 order by begtime asc;

select top 100 * from gridlog order by creationdate desc;
select * from gridlog where surrogate=132045;
delete from gridlog where surrogate=132045;


-- version: 280 module: allegro-collection date: 2012-12-05 17:55:26 
-- applied to:  HEAD 

/*
mancava il vd.valuationmode='Position', analisi per pol, Lorenzo Pola
*/

select sum(vd.marketvalue)-sum(vd.value) from valuationdetail vd, valuation v where
vd.valuation=v.valuation
--and v.valuationtime='2011-12-31 23:00' and
and v.valuationtime='2012-12-05 23:00' and v.valuationmode='Position' and
vd.csttradingstrategy in ('POS-PT-PRO','POS-OR-DOR')
and vd.begtime>='2012-01-01'/* and vd.endtime<='2014-01-01'*/ and (vd.fee is not null)
and vd.cstCompetencyCentre='POS' 


select sum(vd.marketvalue)-sum(vd.value) from valuationdetail vd, valuation v,trade t where
vd.valuation=v.valuation and vd.trade=t.trade
--and v.valuationtime='2011-12-31 23:00' and
and v.valuationtime='2012-12-05 23:00' and v.valuationmode='Position' and
vd.csttradingstrategy in ('POS-PT-PRO','POS-OR-DOR')
and t.tradedate>='2012-01-01'
/*and vd.begtime>='2012-01-01'and vd.endtime<='2014-01-01'*/ and (vd.fee is not null)
and vd.cstCompetencyCentre='POS' 


select vd.valuationdetail,vd.trade,vd.exposure,vd.validation,vd.quantitystatus,vd.quantitytype,sum(vd.quantity) as qty,sum(vd.value) as cv, sum(vd.marketvalue) as mv,
sum(vd.var) from valuationdetail vd, valuation v where
vd.valuation=v.valuation
--and v.valuationtime='2011-12-31 23:00' and
and v.valuationtime='2012-12-05 23:00' and v.valuationmode='Position' and
vd.csttradingstrategy in ('POS-OR-DOR')
and vd.begtime>='2012-12-01' and vd.endtime<='2013-01-01' --and (vd.fee is null)
and vd.cstCompetencyCentre='POS' 
and vd.trade in (119176) group by vd.valuationdetail,vd.trade,vd.exposure,vd.validation,vd.quantitystatus,vd.quantitytype order by vd.exposure,vd.valuationdetail;


select vd.* from valuationdetail vd, valuation v where
vd.valuation=v.valuation
--and v.valuationtime='2011-12-31 23:00' and
and v.valuationtime='2012-12-05 23:00' and
vd.trade=119176 and vd.marketvalue=-16214.621472 


-- version: 281 module: allegro-collection date: 2012-12-06 09:44:36 
-- applied to:  HEAD 

 SELECT valuationdetail.begtime begtime, valuationdetail.counterparty counterparty, valuationdetail.marketprice marketprice, valuationdetail.marketvalue marketvalue, valuationdetail.price price, 
 valuationdetail.pricequantity pricequantity, valuationdetail.quantity quantity, valuationdetail.trade trade, valuationdetail.validation validation, valuationdetail.value value, valuationdetail.description description, 
 valuationdetail.endtime endtime, position.exchange exchange, valuationdetail.exposure exposure, valuationdetail.exposurequantity exposurequantity, valuationdetail.exposuretype exposuretype, valuationdetail.npvfactor npvfactor, 
 valuationdetail.position position, valuationdetail.positionmode positionmode, position.optionposition optionposition, position.positiontype positiontype, valuationdetail.quantitystatus quantitystatus, 
 valuationdetail.currencyfactor currencyfactor, valuationdetail.valuationdetail valuationdetail, valuationdetail.product product, valuationdetail.marketarea marketarea, valuationdetail.tradebook tradebook, 
 valuationdetail.trader trader, valuationdetail.currency currency, valuationdetail.priceunit priceunit, valuationdetail.unit unit, valuationdetail.positionstatus positionstatus, valuationdetail.evergreenstatus evergreenstatus, 
 valuation.valuationtime valuationtime, valuation.valuationmode valuationmode, valuationdetail.tradetype tradetype, valuationdetail.pricestatus pricestatus, valuationdetail.posdetail posdetail, valuationdetail.fee fee, 
 valuationdetail.cstquantitypeak cstquantitypeak, valuationdetail.cstquantityoffpeak cstquantityoffpeak, valuationdetail.cstquantityrealised cstquantityrealised, valuationdetail.cstquantityrealisedpeak cstquantityrealisedpeak, 
 valuationdetail.cstquantityrealisedoffpeak cstquantityrealisedoffpeak, valuationdetail.cstquantityunrealised cstquantityunrealised, valuationdetail.cstquantityunrealisedpeak cstquantityunrealisedpeak, 
 valuationdetail.cstquantityunrealisedoffpeak cstquantityunrealisedoffpeak, valuationdetail.cstmtmvalue cstmtmvalue, valuationdetail.cstnpvalue cstnpvalue, valuationdetail.cstrealisedvalue cstrealisedvalue, 
 valuationdetail.cstunrealisedvalue cstunrealisedvalue, valuationdetail.cstnpvyear1 cstnpvyear1, valuationdetail.cstnpvalue1 cstnpvalue1, valuationdetail.cstnpvyear2 cstnpvyear2, valuationdetail.cstnpvalue2 cstnpvalue2, 
 valuationdetail.cstnpvyear3 cstnpvyear3, valuationdetail.cstnpvalue3 cstnpvalue3, valuationdetail.productclass productclass, valuationdetail.producttype producttype, valuationdetail.location location, valuationdetail.block block, 
 valuationdetail.tsperiod tsperiod, valuationdetail.quantitytype quantitytype, valuationdetail.matchedquantity matchedquantity, valuationdetail.matched matched, valuationdetail.measure measure, 
 valuationdetail.cascadable cascadable, valuationdetail.cascadedate cascadedate, valuationdetail.cascadereference cascadereference, valuationdetail.feetype feetype, valuationdetail.tier tier, 
 valuationdetail.pricebegtime pricebegtime, valuationdetail.priceendtime priceendtime, valuationdetail.pricedate pricedate, valuationdetail.priceindex priceindex, valuationdetail.compositeindex compositeindex, 
 valuationdetail.cstmarketregion cstmarketregion, valuationdetail.futuremonth futuremonth, valuationdetail.marginfactor marginfactor, valuationdetail.settlementdate settlementdate, valuationdetail.settlementstatus settlementstatus, 
 valuationdetail.volatility volatility, valuationdetail.cstgenplantname cstgenplantname, valuationdetail.credittype credittype, valuationdetail.timezone timezone, valuationdetail.creditexposure creditexposure, 
 valuationdetail.cstMarketAccessCC cstMarketAccessCC, valuationdetail.daylightsaving daylightsaving, valuationdetail.cstdeliverydate cstdeliverydate, valuationdetail.duedate duedate, valuationdetail.begtime deliveryquarterhour, 
 valuationdetail.begtime deliveryhalfhour, valuationdetail.begtime deliveryhour, valuationdetail.begtime deliveryday, valuationdetail.cstdeliverymonth cstdeliverymonth, valuationdetail.begtime deliverymonth, 
 valuationdetail.cstdeliveryquarter cstdeliveryquarter, valuationdetail.begtime deliveryquarter, valuationdetail.cstdeliveryyear cstdeliveryyear, valuationdetail.begtime deliveryyear, valuationdetail.cstexternalid cstexternalid, 
 valuationdetail.phase phase, valuationdetail.accountnumber accountnumber, valuationdetail.accountname accountname, valuationdetail.csttradingstrategy csttradingstrategy, valuationdetail.cstaccountingpurpose cstaccountingpurpose, 
 valuationdetail.contract contract, valuationdetail.company company, valuationdetail.cstCompetencyCentre cstCompetencyCentre, valuationdetail.var var, valuationdetail.shipment shipment, valuationdetail.carrier carrier, 
 valuationdetail.strategy strategy, valuationdetail.strategydetail strategydetail, valuationdetail.hedge hedge, valuationdetail.optionvalue optionvalue, valuationdetail.component component, valuationdetail.pile pile, 
 valuationdetail.promptvolatility promptvolatility, valuation.valuation valuation 
 FROM valuationdetail, position, valuation, ngposition 
 WHERE valuation.valuationmode = 'Position' and valuation.valuation=valuationdetail.valuation and valuationdetail.position=ngposition.position and valuationdetail.posdetail=ngposition.posdetail and 
 valuationdetail.position = position.position and valuationdetail.quantitytype <> 'LOSS' and position.positiontype <> 'INTERCONNECT' 
 and ( (valuation.valuationtype = 'SUMMATION' and valuation.valuationtime = '2012-12-05 23:00:00.000') or (valuation.valuationtype = 'INCREMENTAL' and valuation.valuationtime >= '2012-12-05 23:00:00.000' and 
 valuation.valuationtime <= '2012-12-05 23:00:00.000') ) and  position.trade is null and valuationdetail.strategy is not null  AND ((valuationdetail.begtime<'2016-01-01 00:00:00.000' OR valuationdetail.begtime is null) 
 AND (valuationdetail.endtime>'2012-01-01 00:00:00.000' OR valuationdetail.endtime is null))  AND (  valuationdetail.cstcompetencycentre = 'POS'   AND  valuationdetail.csttradingstrategy = 'POS-PT-PRO'  ) 


-- version: 282 module: allegro-collection date: 2012-12-07 09:17:29 
-- applied to:  HEAD 

SELECT fintransact.fintransact fintransact, fintransact.company company, fintransact.subledger subledger, fintransact.acctdate acctdate, fintransact.counterparty counterparty, fintransact.currency currency, fintransact.finstatus finstatus, fintransact.accountant accountant, fintransact.printdate printdate, fintransact.printname printname, fintransact.reverse reverse, fintransact.reversedate reversedate, fintransact.fiscalclose fiscalclose, fintransact.recondate recondate, fintransact.valuation valuation, fintransact.frequency frequency, fintransact.invoice invoice, fintransact.duedate duedate, fintransact.invoicedate invoicedate, fintransact.recdate recdate, fintransact.transmittaldate transmittaldate, fintransact.remadvice remadvice, fintransact.handling handling, fintransact.payaddress payaddress, fintransact.invaddress invaddress, fintransact.invoicetype invoicetype, fintransact.paymethod paymethod, fintransact.discount discount, fintransact.checkdate checkdate, fintransact.transactiontype transactiontype, fintransact.checknumber checknumber, fintransact.voiddate voiddate, fintransact.discountdate discountdate, fintransact.payor payor, fintransact.document document, fintransact.calendar calendar, fintransact.correspondence correspondence, fintransact.remark remark, fintransact.collaboration collaboration, fintransact.latefee latefee, fintransact.creationname creationname, fintransact.creationdate creationdate, fintransact.revisionname revisionname, fintransact.revisiondate revisiondate, fintransact.cstcompbank cstcompbank, fintransact.cstcptybank cstcptybank, fintransact.cstSalesTaxCode cstsalestaxcode, fintransact.cstvalidation cstvalidation FROM fintransact WHERE (fintransact.acctdate>='2012-11-01 00:00:00.000' AND fintransact.acctdate<'2012-12-01 00:00:00.000') AND fintransact.transactiontype = 'AR' and fintransact.transactiontype = 'AR'


-- version: 283 module: allegro-collection date: 2012-12-10 14:15:15 
-- applied to:  HEAD 

-- http://kb.trading.repower.com/Allegro_-_Data_Archiving_Strategy
select * from valuation where valuation=102653;
EXEC cspValuationArchiveRestore 102653;
select count(*) from valuationdetail where valuation=102653;

select * from valuation where valuation=102637;
EXEC cspValuationArchiveRestore 102637;
select count(*) from valuationdetail where valuation=102637;

-- rearchiving a valuation
-- http://kb.trading.repower.com/CstValuationArchive_-_Table_-_Allegro
select count(*) from valuationdetail where valuation=102653;
select * from cstValuationarchive where valuation=102653;
update cstValuationArchive set archivestatus='TRUE' where valuation=102653;
select * from cstvaluationarchive where archivestatus='TRUE';


-- version: 284 module: allegro-collection date: 2012-12-10 16:33:41 
-- applied to:  HEAD 

select * from pricevalue where priceindex like '%NP%' and pricedate>='2012-03-31' and pricedate<'2012-04-01';


-- version: 285 module: allegro-collection date: 2012-12-11 09:55:46 
-- applied to:  HEAD 

delete from pricevalue where /*pricedate>='2012-11-01' and pricedate<'2012-12-01' and */
priceindex in (
'It - Mix 80-20 Settle',
'It - Mix 80-20 Forward',
'Ctice Settle',
'Ctice Forward',
'It - Edison Settle',
'It - Edison Forward',
'It - Ice Brent 6 mth avg Settle',
'It - Ice Brent 6 mth avg Forward',
'Im gas release 2004 Settle',
'Im gas release 2004 Forward',
'Im gas release 2007 Settle',
'Im gas release 2007 Forward',
'PMGas Settle',
'PMGas Forward',
'It - Pun Mth Avg Settle',
'It - Pun Mth Avg Forward',
'It - ICEBrent901 Settle',
'It - ICEBrent901 Forward',
'It - Swap Settle',
'It - Swap Forward'
)


-- version: 286 module: allegro-collection date: 2012-12-11 15:33:03 
-- applied to:  HEAD 

SELECT priceindex, sum(price)/count(*) FROM pricevalue WHERE priceindex LIKE '%NP%' AND pricedate='2012-04-30' 
and delivdate>='2015-01-01' and delivdate<'2016-01-01' group by priceindex;


-- version: 287 module: allegro-collection date: 2012-12-12 09:36:10 
-- applied to:  HEAD 

select * from pricevalue where pricedate='2012-04-30' and priceindex like '%NP%' and revisiondate>'2012-12-11 17:31:00';


-- version: 288 module: allegro-collection date: 2012-12-13 08:40:24 
-- applied to:  HEAD 

select * from pricevalue where priceindex='Power DE Hour Settle' and pricedate>='2012-12-12' and pricedate<'2012-12-13';


select * from valuationdetail where valuation=102844;


-- version: 289 module: allegro-collection date: 2012-12-17 16:44:45 
-- applied to:  HEAD 

DROP TABLE dbo.cstpriceindexcheck;
CREATE TABLE dbo.cstpriceindexcheck (
   [cstpriceindexcheck] [varchar](32) NOT NULL,
   [active] [bit] NULL DEFAULT ((1)),
   [warninglevel] [varchar](32) NOT NULL /*DEFAULT ('ERROR')*/,
   [wkday] [varchar](32) NOT NULL /*DEFAULT ('1234567')*/, 
   [evening] [bit] NULL DEFAULT ((0)),
   [afternoon] [bit] NULL DEFAULT ((0)),
   [endofmonth] [bit] NULL DEFAULT ((1)),
   [validfrom] [datetime] NULL,
   [validto] [datetime] NULL,
   [countatleast] [int] NOT NULL DEFAULT ((1)),
   [creationname] [varchar](64) NOT NULL,
   [creationdate] [datetime] NOT NULL,
   [revisionname] [varchar](64) NULL,
   [revisiondate] [datetime] NULL,
   CONSTRAINT [pk_cstpriceindexchek] PRIMARY KEY CLUSTERED ([cstpriceindexcheck] ASC) ON [PRIMARY]
); 
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('CO2 CER Forward', 1, 'ERROR', '123456',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('CO2 CER Settlement', 1, 'ERROR', '123456',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('CO2 EUA Forward', 1, 'ERROR', '123456',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('CO2 EUA Settlement', 1, 'ERROR', '123456',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power AT Hour Forward', 1, 'ERROR', '123456',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power AT Hour Settle', 1, 'ERROR', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power AT Offpeak Day Forward', 1, 'ERROR', '123456',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power AT Offpeak Settle', 1, 'ERROR', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power AT Peak Day Forward', 1, 'ERROR', '123456',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power AT Peak Settle', 1, 'ERROR', '23456',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power Capacity AT/CH Hour Settle', 1, 'ERROR', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power Capacity CH/AT Hour Settle', 1, 'ERROR', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power Capacity CH/DE Hour Settle', 1, 'ERROR', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power Capacity CH/FR Hour Settle', 1, 'ERROR', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power Capacity CH/IT Hour Settle', 1, 'ERROR', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power Capacity DE/CH Hour Settle', 1, 'ERROR', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power Capacity FR/CH Hour Settle', 1, 'ERROR', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power Capacity FR/IT Hour Settle', 1, 'WARNING', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power Capacity IT/CH Hour Settle', 1, 'ERROR', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power Capacity IT/FR Hour Settle', 1, 'WARNING', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power CH Hour Forward', 1, 'ERROR', '123456',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power CH Hour Settle', 1, 'ERROR', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power CH Offpeak Day Forward', 1, 'ERROR', '123456',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power CH Offpeak Settle', 1, 'ERROR', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power CH Peak Day Forward', 1, 'ERROR', '123456',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power CH Peak Settle', 1, 'ERROR', '23456',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power DE Hour Forward', 1, 'ERROR', '123456',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power DE Hour Settle', 1, 'ERROR', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power DE Offpeak Day Forward', 1, 'ERROR', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power DE Offpeak Settle', 1, 'ERROR', '123456',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power DE Peak Day Forward', 1, 'ERROR', '123456',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power DE Peak Settle', 1, 'ERROR', '23456',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power FR Hour Forward', 1, 'ERROR', '123456',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power FR Hour Settle', 1, 'ERROR', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power FR Offpeak Day Forward', 1, 'ERROR', '123456',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power FR Offpeak Settle', 1, 'ERROR', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power FR Peak Day Forward', 1, 'ERROR', '123456',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power FR Peak Settle', 1, 'ERROR', '23456',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power IT IPEX CSud Hour Forward', 1, 'WARNING', '123456',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power IT IPEX CSud Hour Settle', 1, 'WARNING', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power IT IPEX North Hour Forward', 1, 'ERROR', '123456',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power IT IPEX North Hour Settle', 1, 'ERROR', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power IT IPEX PUN Hour Forward', 1, 'ERROR', '123456',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power IT IPEX PUN Hour Settle', 1, 'ERROR', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power IT IPEX Sicily Hour Forwar', 1, 'WARNING', '123456',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power IT IPEX Sicily Hour Settle', 1, 'WARNING', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power IT IPEX Sud Hour Forward', 1, 'WARNING', '123456',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power IT IPEX Sud Hour Settle', 1, 'WARNING', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power IT MI1 CSud Hour Settle', 1, 'WARNING', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power IT MI1 North Hour Settle', 1, 'WARNING', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power IT MI1 Sicily Hour Settle', 1, 'WARNING', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power IT MI1 Sud Hour Settle', 1, 'WARNING', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power IT MI2 CSud Hour Settle', 1, 'WARNING', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power IT MI2 North Hour Settle', 1, 'WARNING', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power IT MI2 Sicily Hour Settle', 1, 'WARNING', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power IT MI2 Sud Hour Settle', 1, 'WARNING', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power IT Offpeak Day Forward', 1, 'ERROR', '123456',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power IT Offpeak Settle', 1, 'ERROR', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power IT Peak Day Forward', 1, 'ERROR', '123456',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power IT Peak Settle', 1, 'ERROR', '23456',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power NP Base Day Forward', 1, 'ERROR', '123456',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power NP Base Quarter Forward', 1, 'ERROR', '123456',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power NP Base Settle', 1, 'ERROR', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power NP Base Year Forward', 1, 'ERROR', '123456',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('Power VaR Month Forward', 1, 'WARNING', '123456',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('SET PPA MB Down Settle', 1, 'WARNING', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('SET PPA MB Up Settle', 1, 'WARNING', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('SET PPA MSD Down Settle', 1, 'WARNING', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('SET PPA MSD Up Settle', 1, 'WARNING', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
INSERT INTO dbo.cstpriceindexcheck (cstpriceindexcheck, active, warninglevel, wkday, evening, afternoon, endofmonth, countatleast,creationname,creationdate) VALUES ('SET PPA Settle', 1, 'WARNING', '1234567',0,1,1, 1,'Tiziano Mengotti',getdate());
update cstpriceindexcheck set evening=1;

select * from cstpriceindexcheck;

/*
*  Stored Procedure cspCheckLoadedPriceCurvesIF49
*
*  This stored procedure goes through loaded price curves and see if all are loaded.
*  Information on which curve has to be loaded when is stored in the table cstpriceindexcheck.
*
* Test with
* EXEC cspCheckLoadedPriceCurvesIF49
*
* Retrieve output with
* select top 200 * from cstinterfaceaudit order by creationdate desc;
*
*  author: tiziano.mengotti
*  last changed: 17.12.2012
*/
ALTER PROCEDURE [dbo].[cspCheckLoadedPriceCurvesIF49] AS
BEGIN
   DECLARE @pricedate DATETIME;
   DECLARE @weekday INT;
   DECLARE @priceidxck VARCHAR(32);   
   DECLARE @warninglevel VARCHAR(32);
   DECLARE @countatleast INT;
   DECLARE @curcount INT;
   DECLARE @message VARCHAR(255);

   SELECT @pricedate=(SELECT DATEADD(dd, DATEDIFF(dd,0,getdate()-1), 0));
   SELECT @weekday=DATEPART(WEEKDAY, GETDATE()-1);
   PRINT 'Launching price curve check for '+ CAST(@pricedate AS varchar(20))+' (weekday '+CAST(@weekday AS VARCHAR(10))+')'
   EXECUTE cspUpdateInterfaceAudit 'PriceCk','0', '0', 'cspCheckLoadedPriceCurvesIF49', 'INFO', 'Starting check on loaded price curves via IF49...'

   DECLARE curve_cursor CURSOR FOR 
   SELECT cpi.cstpriceindexcheck,cpi.warninglevel,cpi.countatleast FROM cstpriceindexcheck cpi
   WHERE cpi.active=1 AND cpi.wkday like '%'+CAST(@weekday AS VARCHAR(1))+'%'ORDER BY cpi.cstpriceindexcheck;

   OPEN curve_cursor

   FETCH NEXT FROM curve_cursor 
   INTO @priceidxck,@warninglevel,@countatleast

   WHILE @@FETCH_STATUS = 0
   BEGIN
       --PRINT 'Currently checking '+@priceidxck+' with warning level '+@warninglevel+' and minimal count '+CAST(@countatleast AS VARCHAR(6))
	   
	   SELECT @curcount=count(*) from pricevalue where pricedate=@pricedate and priceindex=@priceidxck;
       
       IF (@curcount<@countatleast) 
			BEGIN
                IF (@curcount=0)
                   SELECT @message='No prices found for priceindex "'+@priceidxck+'" on pricedate '+CONVERT(VARCHAR(19),@pricedate,20)
                ELSE
                   SELECT @message=CAST(@curcount AS VARCHAR(6))+' prices found for priceindex "'+@priceidxck+'" on pricedate '+CONVERT(VARCHAR(19),@pricedate,20)+', but at least '+
                                   CAST(@countatleast AS VARCHAR(6))+' required!'

                PRINT @message
                --EXECUTE cspUpdateInterfaceAudit 'PriceCk','1', '0', 'cspCheckLoadedPriceCurvesIF49', @warninglevel, @Message
         	END

	   FETCH NEXT FROM curve_cursor 
       INTO @priceidxck,@warninglevel,@countatleast
   END -- WHILE over cstpriceindexcheck

   CLOSE curve_cursor;
   DEALLOCATE curve_cursor;
   PRINT 'Price curve check over.'
   EXECUTE cspUpdateInterfaceAudit 'PriceCk','0', '0', 'cspCheckLoadedPriceCurvesIF49', 'INFO', 'Price check of loaded prices via IF49 over.'
END

EXEC cspCheckLoadedPriceCurvesIF49;

select top 100 * from cstinterfaceaudit order by creationdate desc;


--DROP PROCEDURE cspCheckLoadedPriceCurvesIF49;
--DROP TABLE cstpriceindexcheck;



-- version: 290 module: allegro-collection date: 2012-12-19 18:19:51 
-- applied to:  HEAD 

select * from pricevalue where pricedate='2012-06-29' and delivdate='2012-07-03' and priceindex='Power NP Base Day Forward' and surrogate=103851398;
select *  from pricevalue where pricedate='2012-06-29' and delivdate='2012-07-01' and priceindex='Power NP Base Day Forward'and surrogate=103855884;



-- version: 291 module: allegro-collection date: 2012-12-19 18:49:10 
-- applied to:  HEAD 

-- Cal 2013 -> OK, 37.25 in Allegro e UBS
SELECT priceindex, sum(price)/count(*) FROM pricevalue WHERE priceindex LIKE '%NP%' AND pricedate='2012-07-31' 
AND delivdate>='2013-01-01' AND delivdate<'2014-01-01' GROUP BY priceindex;

-- Q4/13 41.167 in Allegro ma UBS dice che dovrebbe essere 40.90
SELECT priceindex, sum(price)/count(*) FROM pricevalue WHERE priceindex LIKE '%NP%' AND pricedate='2012-07-31' 
AND delivdate>='2013-10-01' AND delivdate<'2014-01-01' GROUP BY priceindex;

-- Q3/13 33.267 in Allegro ma UBS dice 33.0
SELECT priceindex, sum(price)/count(*) FROM pricevalue WHERE priceindex LIKE '%NP%' AND pricedate='2012-07-31' 
AND delivdate>='2013-07-01' AND delivdate<'2013-10-01' GROUP BY priceindex;

-- Q2/13 OK 33.48 in Allegro e UBS
SELECT priceindex, sum(price)/count(*) FROM pricevalue WHERE priceindex LIKE '%NP%' AND pricedate='2012-07-31' 
AND delivdate>='2013-04-01' AND delivdate<'2013-07-01' GROUP BY priceindex;

-- Q1/13 OK 41.13 in Allegro e UBS
SELECT priceindex, sum(price)/count(*) FROM pricevalue WHERE priceindex LIKE '%NP%' AND pricedate='2012-07-31' 
AND delivdate>='2013-01-01' AND delivdate<'2013-04-01' GROUP BY priceindex;



-- version: 292 module: allegro-collection date: 2012-12-19 18:50:02 
-- applied to:  HEAD 

-- Cal 2013 -> OK 38.33
SELECT priceindex, sum(price)/count(*) FROM pricevalue WHERE priceindex LIKE '%NP%' AND pricedate='2012-08-31' 
AND delivdate>='2013-01-01' AND delivdate<'2014-01-01' GROUP BY priceindex;

-- Q4/13 Allegro dice 42.281 ma UBS dice che dovrebbe essere 42.25
SELECT priceindex, sum(price)/count(*) FROM pricevalue WHERE priceindex LIKE '%NP%' AND pricedate='2012-08-31' 
AND delivdate>='2013-10-01' AND delivdate<'2014-01-01' GROUP BY priceindex;

-- Q3/13 Allegro dice che 34.18 ma UBS risponde con 34.15
SELECT priceindex, sum(price)/count(*) FROM pricevalue WHERE priceindex LIKE '%NP%' AND pricedate='2012-08-31' 
AND delivdate>='2013-07-01' AND delivdate<'2013-10-01' GROUP BY priceindex;

-- Q2/13 34.9 OK
SELECT priceindex, sum(price)/count(*) FROM pricevalue WHERE priceindex LIKE '%NP%' AND pricedate='2012-08-31' 
AND delivdate>='2013-04-01' AND delivdate<'2013-07-01' GROUP BY priceindex;

-- Q1/13 42 OK
SELECT priceindex, sum(price)/count(*) FROM pricevalue WHERE priceindex LIKE '%NP%' AND pricedate='2012-08-31' 
AND delivdate>='2013-01-01' AND delivdate<'2013-04-01' GROUP BY priceindex;



-- version: 293 module: allegro-collection date: 2012-12-19 18:59:55 
-- applied to:  HEAD 

-- Cal 2013 -> OK 37.35
SELECT priceindex, sum(price)/count(*) FROM pricevalue WHERE priceindex LIKE '%NP%' AND pricedate='2012-09-30' 
AND delivdate>='2013-01-01' AND delivdate<'2014-01-01' GROUP BY priceindex;

-- Q4/13 40.987 ma dovrebbe essere 41.05
SELECT priceindex, sum(price)/count(*) FROM pricevalue WHERE priceindex LIKE '%NP%' AND pricedate='2012-09-30' 
AND delivdate>='2013-10-01' AND delivdate<'2014-01-01' GROUP BY priceindex;

-- Q3/13 33.287 ma dovrebbe essere 33.35
SELECT priceindex, sum(price)/count(*) FROM pricevalue WHERE priceindex LIKE '%NP%' AND pricedate='2012-09-30' 
AND delivdate>='2013-07-01' AND delivdate<'2013-10-01' GROUP BY priceindex;

-- Q2/13 34.23 OK
SELECT priceindex, sum(price)/count(*) FROM pricevalue WHERE priceindex LIKE '%NP%' AND pricedate='2012-09-30' 
AND delivdate>='2013-04-01' AND delivdate<'2013-07-01' GROUP BY priceindex;

-- Q1/13 40.94 OK
SELECT priceindex, sum(price)/count(*) FROM pricevalue WHERE priceindex LIKE '%NP%' AND pricedate='2012-09-30' 
AND delivdate>='2013-01-01' AND delivdate<'2013-04-01' GROUP BY priceindex;


-- version: 294 module: allegro-collection date: 2012-12-21 08:49:22 
-- applied to:  HEAD 

/*
/*
d� questo errore: Msg 1205, Level 13, State 52, Line 127
Transaction (Process ID 77) was deadlocked on lock resources with another process and has been chosen as the deadlock victim. Rerun the transaction.


*/
BEGIN

DECLARE @AllegroTradeID as VARCHAR(8)
DECLARE @Position as VARCHAR(8)

DECLARE @BegTimePQ1 as datetime
DECLARE @EndTimePQ1 as datetime
DECLARE @BegTimePQ2 as datetime
DECLARE @EndTimePQ2 as datetime
DECLARE @SurrogatePQ1 as DECIMAL(16,0)
DECLARE @SurrogatePQ2 as DECIMAL(16,0)
DECLARE @TsperiodPQ1 as VARCHAR(8)
DECLARE @TsperiodPQ2 as VARCHAR(8)

-- scg:
DECLARE @overlappingRecords TABLE(
	trade varchar(8) NOT NULL,
	position varchar(8) NOT NULL,
	surrogate1 varchar(8) NOT NULL,
	surrogate2 varchar(8) NOT NULL
)

DECLARE lcursorTrade CURSOR FOR

--	SELECT trade
--	FROM trade
--	WHERE (creationdate >= dateadd(dd, -5, datediff(dd,0,getDate())) or revisiondate >= dateadd(dd, -5, datediff(dd,0,getDate()))) and
--		tradetype NOT LIKE '%Emission%' and
--		tradetype NOT LIKE '%Capacity%' and
--		tradetype LIKE '%Profile%'	and
--		tradestatus <> 'Void'	

	select t.trade
	from trade t
	where t.trade in ( select p.trade
					from position p 
					where p.position in ( select pq.position 
											from powerquantity pq 
													where pq.creationdate >= dateadd(dd, -3, datediff(dd,0,getDate())) or pq.revisiondate >= dateadd(dd, -3, datediff(dd,0,getDate()))))
	
	and t.tradetype NOT LIKE '%Emission%' 
	and t.tradetype NOT LIKE '%Capacity%' 
	and t.tradetype LIKE '%Profile%'
	and t.tradestatus <> 'Void' 
		
	OPEN lcursorTrade
	FETCH NEXT FROM lcursorTrade INTO @AllegroTradeId
	
	WHILE @@FETCH_STATUS = 0
	BEGIN
		
		SELECT @Position = position FROM powerquantity WHERE position IN 
		(SELECT Position
			FROM Position
			WHERE Trade = @AllegroTradeId) 
		and posstatus=1 
		and quantitystatus like '%FORECAST%'
		
		IF @@rowcount > 0 
		BEGIN
		
			-- Check that no PLAN records are present
			DECLARE @PlanFound INT
			SET @PlanFound = (SELECT COUNT(position) FROM powerquantity where position= @Position and quantitystatus='PLAN' and posstatus=1)

			IF @PlanFound = 0
			BEGIN
			
				DECLARE lcursor1 CURSOR FOR
					
				SELECT surrogate, begtime, endtime, tsperiod 
				FROM powerquantity 
				WHERE position = @Position and posstatus=1 and quantitystatus='FORECAST' and he25 is null
				ORDER by surrogate asc	
					
				OPEN lcursor1
				FETCH NEXT FROM lcursor1 INTO @SurrogatePQ1, @BegTimePQ1, @EndTimePQ1, @TsperiodPQ1

				WHILE @@FETCH_STATUS = 0
				BEGIN	
					
					DECLARE lcursor2 CURSOR FOR
					
					SELECT surrogate, begtime, endtime, tsperiod 
					FROM powerquantity 
					WHERE position = @Position and posstatus=1 and quantitystatus='FORECAST' and surrogate > @SurrogatePQ1 and he25 is null
					ORDER by surrogate asc	
					
					OPEN lcursor2
					FETCH NEXT FROM lcursor2 INTO @SurrogatePQ2, @BegTimePQ2, @EndTimePQ2, @TsperiodPQ2
					
					WHILE @@FETCH_STATUS = 0
					BEGIN
						
						-- Declare a BIT variable for check the overlap
						DECLARE @OverlappingDate BIT
						SET @OverlappingDate = 0
						
						-- Check Tsperiod
						IF @TsperiodPQ1 = @TsPeriodPQ2
						BEGIN
							--Check Overlapping date
							
							--SET @OverlappingDate = dbo.cfnOverlappingDate(@BegTimePQ1,@EndTimePQ1,@BegTimePQ2,@EndTimePQ2)
							
							SET @EndTimePQ1 = DATEADD(ss,-1,@EndTimePQ1)
							SET @EndTimePQ2 = DATEADD(ss,-1,@EndTimePQ2)

							IF  @BegTimePQ1 <= @EndTimePQ2 AND @BegTimePQ2 <= @EndTimePQ1
								SET @OverlappingDate = 1 
							ELSE 
								SET @OverlappingDate = 0
										
							IF @OverlappingDate = 1
							BEGIN
								-- scg
								insert into @overlappingRecords values(@AllegroTradeId, @Position, @SurrogatePQ1, @SurrogatePQ1)
--								Print 'Trade: ' + cast(@AllegroTradeId as varchar(8))
--								Print 'Position: ' + cast(@Position as varchar(8))
--								Print 'SurrogatePQ1: ' + cast(@SurrogatePQ1 as varchar(8))
--								Print 'SurrogatePQ2: ' + cast(@SurrogatePQ2 as varchar(8))
--								Print '---'							
							END

						END
					
						FETCH NEXT FROM lcursor2 INTO @SurrogatePQ2, @BegTimePQ2, @EndTimePQ2, @TsperiodPQ2
						
					END

					CLOSE lcursor2
					DEALLOCATE lcursor2
					
					FETCH NEXT FROM lcursor1 INTO @SurrogatePQ1, @BegTimePQ1, @EndTimePQ1, @TsperiodPQ1

				END
			
			CLOSE lcursor1
			DEALLOCATE lcursor1
			
			END
				
			
		END
	
FETCH NEXT FROM lcursorTrade INTO @AllegroTradeId
END

CLOSE lcursorTrade
DEALLOCATE lcursorTrade

--scg: 
select * from @overlappingRecords

END



-- version: 295 module: allegro-collection date: 2012-12-21 09:27:51 
-- applied to:  HEAD 

select * from pricevalue where priceindex like '%Forward%' and pricedate=delivdate order by priceindex, pricedate,delivdate;

select * from pricevalue where priceindex like '%Forward%' and pricedate=delivdate 
and priceindex not in ('Power NP Base Quarter Forward', 'Power VaR Month Forward', 'CO2 CER Forward', 'CO2 EUA Forward')
order by priceindex, pricedate,delivdate;

--delete FROM pricevalue WHERE priceindex LIKE '%Forward%' AND pricedate=delivdate 
--AND priceindex NOT IN ('Power NP Base Quarter Forward', 'Power VaR Month Forward', 'CO2 CER Forward', 'CO2 EUA Forward');


-- version: 296 module: allegro-collection date: 2012-12-21 11:59:17 
-- applied to:  HEAD 

SELECT DISTINCT ft.acctdate FROM fintransact ft WHERE  ft.acctdate>='2012-01-01' AND ft.acctdate<'2013-01-01' ORDER BY ft.acctdate ASC;

--findetail export
SELECT 
--1
cr.bidrate AS CHFEUR, t.csttradingstrategy, t.currency AS originalcurrency, ft.fintransact,ft.company, ft.subledger, CONVERT(VARCHAR(19),ft.acctdate,20) AS acctdate,
ft.counterparty, ft.currency, ft.finstatus,
--2
ft.valuation, ft.invoice, CONVERT(VARCHAR(19),ft.duedate,20) AS duedate,ft.invoicetype, ft.transactiontype, CONVERT(VARCHAR(19),ft.voiddate, 20) AS voiddate,
CONVERT(VARCHAR(19),ft.conveydate,20) AS conveydate, ft.collaboration,
-- findetail
fd.cstsalestaxcode,fd.findetail,fd.fintransact,fd.account,fd.description,fd.trade,fd.position,fd.posdetail,CONVERT(VARCHAR(19),fd.begtime,20) AS begtime,CONVERT(VARCHAR(19),fd.endtime,20) AS endtime,fd.contract,
fd.fee,fd.invoice, CONVERT(VARCHAR(19),fd.invoicedate,20) AS invoicedate,fd.product,fd.grossquantity,fd.price,fd.pricequantity,fd.quantity,
fd.priceunit, fd.unit,fd.decint, fd.grossvalue,fd.credit,fd.debit,fd.taxlocation,fd.confirmstatus,fd.company,fd.counterparty,fd.currency,
fd.paymentterms, fd.quantitystatus, fd.acctstatus, fd.point, fd.controlarea, CONVERT(VARCHAR(19),fd.settlementdate,20) AS settlementdate,
fd.tradebook, fd.marketarea,  CONVERT(VARCHAR(19),mtmaccrualdate,20) AS mtmaccrualdate, fd.vintageyear, fd.cstaccountingpurpose,fd.csttradingstrategy,fd.cstexternalid,
CONVERT(VARCHAR(19),fd.creationdate,20) AS creationdate,fd.cstsalestaxcode,fd.term,fd.producttype,fd.tsperiod,fd.cstgenplantname
FROM findetail fd,fintransact ft, trade t, currexchrate cr 
WHERE 
fd.fintransact=ft.fintransact 
--AND ft.acctdate>='2012-01-01' AND ft.acctdate<'2013-01-01'
AND fd.trade=t.trade AND
cr.pricedate=ft.acctdate AND cr.basecurrency='CHF' AND cr.quotecurrency='EUR'
AND  ft.acctdate='2012-11-30 00:00:00';

-- valuationdetail
SELECT p.positiontype, t.trade,vd.fee,vd.cstdeliverymonth,vd.description,vd.currency, sum(vd.quantity)/2 AS quantity,sum(vd.pricequantity)/2 AS pricequantity,
sum(vd.value) AS value, sum(vd.marketvalue) AS marketvalue, sum(vd.marketvalue)-sum(vd.value) AS mtm
 FROM valuationdetail vd, valuation v, trade t, position p WHERE
 v.valuation=vd.valuation AND v.valuationtime='2012-11-30 23:00' AND v.valuationmode='Position' AND
vd.trade=t.trade /*AND t.cstaccountingpurpose='HfT' */ 
AND vd.begtime>='2012-01-01 00:00:00'
AND p.trade=t.trade 
GROUP BY p.positiontype, t.trade,vd.fee,vd.cstdeliverymonth,vd.description,vd.currency;

-- trade summary
SELECT t.trade,t.tradestatus,t.cstaccountingpurpose,p.product,p.positiontype,p.block,p.counterparty,t.currency,p.tradebook,t.csttradingstrategy,CONVERT(VARCHAR(19),t.tradedate,20) AS tradedate,
       CONVERT(VARCHAR(19),t.begtime,20) AS begtime,CONVERT(VARCHAR(19),t.endtime,20) AS endtime,p.company,t.tradeclass,t.trader,
 CONVERT(VARCHAR(19),t.creationdate,20) AS creationdate, CONVERT(VARCHAR(19),t.revisiondate,20) AS revisiondate
FROM trade t, position p
WHERE
p.trade=t.trade
AND t.begtime>='2012-01-01 00:00:00';


-- version: 297 module: allegro-collection date: 2013-01-02 08:55:06 
-- applied to:  HEAD 

select distinct priceindex from pricevalue where pricedate='2012-12-31' order by priceindex;

select max(creationdate) from pricevalue where pricedate='2012-12-31' and priceindex='Power IT IPEX North Hour Forward';


-- version: 298 module: allegro-collection date: 2013-01-02 10:04:24 
-- applied to:  HEAD 

/*
sono trades in quarti d'ora
*/
select trade, begtime, endtime from trade where trade in (
129676,
129820,
129892,
129964,
130036,
130108,
130219
)


-- version: 299 module: allegro-collection date: 2013-01-02 15:09:32 
-- applied to:  HEAD 

select distinct p.counterparty from valuationdetail vd, position p where valuation=103582 and vd.position=p.position;



-- version: 301 module: allegro-collection date: 2013-01-03 14:54:44 
-- applied to:  HEAD 

select p.counterparty,t.* from trade t, position p where t.trade=p.trade and p.position in
(
189629, 192452, 192466
);


select p.counterparty, t.* from trade t, position p where t.trade=p.trade and  t.trade in
(
189629, 192452, 192466
);


select p.counterparty,t.* from trade t, position p where t.trade=p.trade and p.position in
(
178423,
178495,
178496,
178498,
178499,
178500,
178511,
178512,
178513,
178514
);


select p.counterparty, t.* from trade t, position p where t.trade=p.trade and  t.trade in
(
178423,
178495,
178496,
178498,
178499,
178500,
178511,
178512,
178513,
178514
);



-- version: 305 module: allegro-collection date: 2013-01-04 16:04:52 
-- applied to:  HEAD 


select * from trade t where t.endtime>'2013-01-01 00:00:00' and t.begtime<'2013-01-01 00:00:00'

-- trades per Linus a cavallo
SELECT * FROM trade t WHERE t.endtime>'2013-01-01 00:00:00' AND t.begtime<'2013-01-01 00:00:00'
and t.tradetype like '%Power%' and t.cstaccountingpurpose='HfT'


-- version: 308 module: allegro-collection date: 2013-01-07 15:20:53 
-- applied to:  HEAD 

select * from valuation where (creationdate>GETDATE()-1) or (revisiondate>GETDATE()-1) order by revisiondate,creationdate;


-- version: 309 module: allegro-collection date: 2013-01-07 15:52:35 
-- applied to:  HEAD 

select * from valuation where valuationtime>GETDATE() order by valuationtime desc


-- version: 310 module: allegro-collection date: 2013-01-07 15:54:47 
-- applied to:  HEAD 

select * from findetail fd, valuationdetail vd where fd.valuationdetail=vd.valuationdetail and vd.valuation=103679;


-- version: 311 module: allegro-collection date: 2013-01-07 16:05:06 
-- applied to:  HEAD 

-- 06
-- Power Scheduling Audit Poschiavo
-- not COMPLETED for today
SELECT distinct AllegroTradeId, creationname, creationdate, ErrorText, min (status)
FROM cvwpowerschedulingaudit
WHERE cVWPowerSchedulingAudit.CompetencyCentre = 'POS'
and AllegroTradeId not in (
	select distinct trade from trade where tradestatus = 'void'
)
AND cVWPowerSchedulingAudit.MessageId
IN (
    select distinct messageid from cvwpowerschedulingaudit
        where creationdate >= CAST(CONVERT(CHAR(11),GETDATE(),113) AS datetime)
        OR revisiondate >= CAST(CONVERT(CHAR(11),GETDATE(),113) AS datetime)
)
group by AllegroTradeId, creationname, ErrorText,creationdate
having (min (status)) <> 'COMPLETED' and ErrorText is not null
order by creationdate desc
--- EOC


select trade,begtime,endtime,tradestatus from trade where trade in
(
144981,
144957,
144945);


-- version: 312 module: allegro-collection date: 2013-01-09 11:27:31 
-- applied to:  HEAD 

select * from pricevalue where priceindex='Power CH Hour Settle'
and pricedate>='2012-04-01' and pricedate<'2013-01-01' order by pricedate;

select * from pricevalue where priceindex='Power IT IPEX North Hour Settle'
and pricedate>='2012-04-01' and pricedate<'2013-01-01' order by pricedate;


-- version: 313 module: allegro-collection date: 2013-01-09 14:09:08 
-- applied to:  HEAD 

delete from pricevalue where priceindex like '%Settle%' 
--and pricedate>='2013-01-08' and pricedate<'2013-01-09'
and delivdate='2013-12-31';


-- version: 315 module: allegro-collection date: 2013-01-10 11:46:39 
-- applied to:  HEAD 

SELECT * FROM trade WHERE trade IN
( SELECT trade FROM POSITION WHERE POSITION IN
    ( SELECT DISTINCT ft.dbvalue
    FROM feetimeperiod ft 
        INNER JOIN fee ON ft.feetimeperiod = fee.feetimeperiod 
            AND ft.dbcolumn = fee.dbcolumn 
            AND ft.dbvalue = fee.dbvalue
        INNER JOIN POSITION ps ON ps.POSITION = ft.dbvalue
        INNER JOIN trade t ON t.trade = ps.trade
    WHERE 
        ft.dbcolumn = 'POSITION' AND t.tradetype LIKE 'Power%'
		AND fee.feemethod = 'COMMODITY PRICE'
 
        AND EXISTS 
        (	SELECT * 
            FROM fee fee2
            WHERE fee2.dbcolumn = 'POSITION' AND fee2.dbvalue = ps.POSITION 
			AND fee2.feetimeperiod IS NULL
         )
 
        GROUP BY ft.dbvalue 
    HAVING COUNT(DISTINCT fee.pricediff) = 1 
    ));

 
-- come mi ha spiegato Giorgio: in questo check si voleva chiedere ai traders di inserire il prezzo sopra 
SELECT trade FROM POSITION WHERE POSITION IN
    ( SELECT DISTINCT ft.dbvalue
    FROM feetimeperiod ft 
        INNER JOIN fee ON ft.feetimeperiod = fee.feetimeperiod 
            AND ft.dbcolumn = fee.dbcolumn 
            AND ft.dbvalue = fee.dbvalue
        INNER JOIN POSITION ps ON ps.POSITION = ft.dbvalue
        INNER JOIN trade t ON t.trade = ps.trade
    WHERE 
        ft.dbcolumn = 'POSITION' AND t.tradetype LIKE 'Power%'
		AND fee.feemethod = 'COMMODITY PRICE'
 
 
        GROUP BY ft.dbvalue 
    HAVING COUNT(DISTINCT fee.pricediff) = 1 AND COUNT(fee.fee) > 1
    ) and trade=191265;


-- version: 316 module: allegro-collection date: 2013-01-10 14:48:31 
-- applied to:  HEAD 

-- in my opinion fast query / 00:00:59 / 00:00:02 -> cache effects
SELECT 
count(*)
FROM valuationdetail vd, trade t, position p
WHERE
vd.valuation=(SELECT valuation FROM valuation WHERE valuationtime='2012-03-31 23:00' AND valuationmode='Position') AND vd.trade=t.trade AND vd.trade=p.trade
AND vd.counterparty NOT IN ('RE_AG')
AND t.cstaccountingpurpose='HfT'  
AND vd.producttype='Power'
AND vd.fee IS NULL 
AND vd.marketarea<>'NP'
AND t.endtime>'2013-01-01 00:00:00'
AND t.tradedate<'2013-01-01 00:00:00'
AND t.tradestatus<>'Void';

-- in my opinion slower query / 00:00:07 / 00:00:02
SELECT 
count(*)
FROM valuationdetail vd, trade t, position p, valuation v
WHERE
vd.valuation=v.valuation
AND v.valuationtime='2012-03-31 23:00' AND v.valuationmode='Position' AND vd.trade=t.trade AND vd.trade=p.trade
AND vd.counterparty NOT IN ('RE_AG')
AND t.cstaccountingpurpose='HfT'  
AND vd.producttype='Power'
AND vd.fee IS NULL 
AND vd.marketarea<>'NP'
AND t.endtime>'2013-01-01 00:00:00'
AND t.tradedate<'2013-01-01 00:00:00'
AND t.tradestatus<>'Void';


-- version: 317 module: allegro-collection date: 2013-01-10 16:54:42 
-- applied to:  HEAD 
-- marked as: view 
/*
CREATE TABLE dbo.cstpriceindexcheck_0 ( cstpriceindexcheck varchar(32) NOT NULL, active bit NULL, warninglevel varchar(32) NOT NULL, wkday varchar(32) NOT NULL, creationname varchar(64) NOT NULL, creationdate datetime NOT NULL, revisionname varchar(64) NULL, revisiondate datetime NULL )
ALTER TABLE dbo.cstpriceindexcheck DROP CONSTRAINT pk_cstpriceindexcheck
INSERT INTO dbo.cstpriceindexcheck_0 (active, creationdate, creationname, cstpriceindexcheck, revisiondate, revisionname, warninglevel, wkday) SELECT active, creationdate, creationname, cstpriceindexcheck, revisiondate, revisionname, warninglevel, wkday FROM dbo.cstpriceindexcheck
DROP TABLE dbo.cstpriceindexcheck
dbo.sp_rename cstpriceindexcheck_0, cstpriceindexcheck
ALTER TABLE dbo.cstpriceindexcheck ADD CONSTRAINT pk_cstpriceindexcheck PRIMARY KEY (cstpriceindexcheck)
*/

CREATE TABLE dbo.cstpriceindexcheck_0 ( seq int NOT NULL, cstpriceindexcheck varchar(32) NOT NULL, warninglevel varchar(32) NOT NULL, wkday varchar(32) DEFAULT '1234567' NOT NULL, active bit NULL, creationname varchar(64) NOT NULL, creationdate datetime NOT NULL, revisionname varchar(64) NULL, revisiondate datetime NULL )
ALTER TABLE dbo.cstpriceindexcheck DROP CONSTRAINT pk_cstpriceindexcheck
INSERT INTO dbo.cstpriceindexcheck_0 (active, creationdate, creationname, cstpriceindexcheck, revisiondate, revisionname, seq, warninglevel, wkday) SELECT active, creationdate, creationname, cstpriceindexcheck, revisiondate, revisionname, 0, warninglevel, wkday FROM dbo.cstpriceindexcheck
DROP TABLE dbo.cstpriceindexcheck
dbo.sp_rename cstpriceindexcheck_0, cstpriceindexcheck
ALTER TABLE dbo.cstpriceindexcheck ADD CONSTRAINT pk_cstpriceindexcheck PRIMARY KEY (seq)
ALTER TABLE dbo.cstpriceindexcheck ADD CONSTRAINT ck_cstpriceindexcheck_war964 CHECK (warninglevel IN ('ERROR', 'INFO', 'WARNING'))

ALTER TABLE dbo.dbobject ADD CONSTRAINT ck_dbobject_dbtype CHECK (dbtype IN ('boolean', 'date', 'datetime', 'identity', 'int', 'number', 'text', 'varchar'))

ALTER TABLE dbo.cstpriceindexcheck ADD FOREIGN KEY (cstpriceindexcheck) REFERENCES priceindex (priceindex)


INSERT INTO dbo.viewpane (viewname, viewpane, priority, sortseq, panetype, charttype, timecolumn, datatable, autoheight, autosizecolumn, viewpanetitle, viewpanefont, viewpanefontsize, viewpanefontbold, visible, securitycriteria, creationname, creationdate)
VALUES ('Repower Parameters', 'cstPriceIndexChecks',1,8,'GRID',NULL,NULL,'cstpriceindexcheck',0,0,'Priceindex Checks', 'Arial',8,0,1,0,'Tiziano Mengotti',getdate());

INSERT INTO dbo.viewcolumn (viewname,viewpane,viewcolumn,gridseq,dbtable,dbcolumn,label,visible,sortseq,sortorder,viewdefault,subtotal,grandtotal,drill,pagebreak,crosstab,crosstabtype,linkview,expression,columnedit,columnreq,columngroup,creationname,creationdate)
VALUES('Repower Parameters','cstPriceIndexChecks','cstpriceindexcheck',1,'cstpriceindexcheck','cstpriceindexcheck','Price Index',1,1,'ASC',NULL,0,0,0,0,NULL,NULL,NULL,NULL,0,0,0,'Tiziano Mengotti',getdate() );
INSERT INTO dbo.viewcolumn (viewname,viewpane,viewcolumn,gridseq,dbtable,dbcolumn,label,visible,sortseq,sortorder,viewdefault,subtotal,grandtotal,drill,pagebreak,crosstab,crosstabtype,linkview,expression,columnedit,columnreq,columngroup,creationname,creationdate)
VALUES('Repower Parameters','cstPriceIndexChecks','active',2,'cstpriceindexcheck','active','Active',1,NULL,NULL,NULL,0,0,0,0,NULL,NULL,NULL,NULL,0,0,0,'Tiziano Mengotti',getdate() );
INSERT INTO dbo.viewcolumn (viewname,viewpane,viewcolumn,gridseq,dbtable,dbcolumn,label,visible,sortseq,sortorder,viewdefault,subtotal,grandtotal,drill,pagebreak,crosstab,crosstabtype,linkview,expression,columnedit,columnreq,columngroup,creationname,creationdate)
VALUES('Repower Parameters','cstPriceIndexChecks','warninglevel',3,'cstpriceindexcheck','warninglevel','Warning Level',1,NULL,NULL,NULL,0,0,0,0,NULL,NULL,NULL,NULL,0,0,0,'Tiziano Mengotti',getdate() );
INSERT INTO dbo.viewcolumn (viewname,viewpane,viewcolumn,gridseq,dbtable,dbcolumn,label,visible,sortseq,sortorder,viewdefault,subtotal,grandtotal,drill,pagebreak,crosstab,crosstabtype,linkview,expression,columnedit,columnreq,columngroup,creationname,creationdate)
VALUES('Repower Parameters','cstPriceIndexChecks','wkday',4,'cstpriceindexcheck','wkday','Week Day',1,NULL,NULL,NULL,0,0,0,0,NULL,NULL,NULL,NULL,0,0,0,'Tiziano Mengotti',getdate() );

INSERT INTO dbo.viewcolumn (viewname,viewpane,viewcolumn,gridseq,dbtable,dbcolumn,label,visible,sortseq,sortorder,viewdefault,subtotal,grandtotal,drill,pagebreak,crosstab,crosstabtype,linkview,expression,columnedit,columnreq,columngroup,creationname,creationdate)
VALUES('Repower Parameters','cstPriceIndexChecks','creationname',20,'cstpriceindexcheck','creationname','Creation Name',1,NULL,NULL,NULL,0,0,0,0,NULL,NULL,NULL,NULL,1,0,0,'Tiziano Mengotti',getdate() );
INSERT INTO dbo.viewcolumn (viewname,viewpane,viewcolumn,gridseq,dbtable,dbcolumn,label,visible,sortseq,sortorder,viewdefault,subtotal,grandtotal,drill,pagebreak,crosstab,crosstabtype,linkview,expression,columnedit,columnreq,columngroup,creationname,creationdate)
VALUES('Repower Parameters','cstPriceIndexChecks','creationdate',21,'cstpriceindexcheck','creationdate','Creation Date',1,NULL,NULL,NULL,0,0,0,0,NULL,NULL,NULL,NULL,1,0,0,'Tiziano Mengotti',getdate() );
INSERT INTO dbo.viewcolumn (viewname,viewpane,viewcolumn,gridseq,dbtable,dbcolumn,label,visible,sortseq,sortorder,viewdefault,subtotal,grandtotal,drill,pagebreak,crosstab,crosstabtype,linkview,expression,columnedit,columnreq,columngroup,creationname,creationdate)
VALUES('Repower Parameters','cstPriceIndexChecks','revisionname',22,'cstpriceindexcheck','revisionname','Revision Name',1,NULL,NULL,NULL,0,0,0,0,NULL,NULL,NULL,NULL,1,0,0,'Tiziano Mengotti',getdate() );
INSERT INTO dbo.viewcolumn (viewname,viewpane,viewcolumn,gridseq,dbtable,dbcolumn,label,visible,sortseq,sortorder,viewdefault,subtotal,grandtotal,drill,pagebreak,crosstab,crosstabtype,linkview,expression,columnedit,columnreq,columngroup,creationname,creationdate)
VALUES('Repower Parameters','cstPriceIndexChecks','revisiondate',23,'cstpriceindexcheck','revisiondate','Revision Date',1,NULL,NULL,NULL,0,0,0,0,NULL,NULL,NULL,NULL,1,0,0,'Tiziano Mengotti',getdate() );


-- version: 318 module: allegro-collection date: 2013-01-11 09:05:48 
-- applied to:  HEAD 

/*
*  Stored Procedure cspCheckLoadedPriceCurvesIF49
*
*  This stored procedure goes through loaded price curves and see if all are loaded.
*  Information on which curve has to be loaded when is stored in the table cstpriceindexcheck.
*
* Test with
* EXEC cspCheckLoadedPriceCurvesIF49
*
* Retrieve output with
* select top 200 * from cstinterfaceaudit order by creationdate desc;
*
*  author: tiziano.mengotti
*  last changed: 11.1.2013
*/
ALTER PROCEDURE [dbo].[cspCheckLoadedPriceCurvesIF49] AS
BEGIN
   DECLARE @pricedate DATETIME;
   DECLARE @weekday INT;
   DECLARE @priceidxck VARCHAR(32);   
   DECLARE @warninglevel VARCHAR(32);
   DECLARE @countatleast INT;
   DECLARE @curcount INT;
   DECLARE @message VARCHAR(255);

   SELECT @pricedate=(SELECT DATEADD(dd, DATEDIFF(dd,0,getdate()-1), 0));
   SELECT @weekday=DATEPART(WEEKDAY, GETDATE()-1);
   PRINT 'Launching price curve check for '+ CAST(@pricedate AS varchar(20))+' (weekday '+CAST(@weekday AS VARCHAR(10))+')'
   EXECUTE cspUpdateInterfaceAudit 'PriceCk','0', '0', 'cspCheckLoadedPriceCurvesIF49', 'INFO', 'Starting check on loaded price curves via IF49...'

   DECLARE curve_cursor CURSOR FOR 
   SELECT cpi.cstpriceindexcheck,cpi.warninglevel FROM cstpriceindexcheck cpi
   WHERE cpi.active=1 AND cpi.wkday like '%'+CAST(@weekday AS VARCHAR(1))+'%'ORDER BY cpi.cstpriceindexcheck;

   OPEN curve_cursor

   FETCH NEXT FROM curve_cursor 
   INTO @priceidxck,@warninglevel

   WHILE @@FETCH_STATUS = 0
   BEGIN
       --PRINT 'Currently checking '+@priceidxck+' with warning level '+@warninglevel+' and minimal count '+CAST(@countatleast AS VARCHAR(6))
	   
	   SELECT @curcount=count(*) from pricevalue where pricedate=@pricedate and priceindex=@priceidxck;
       
       IF (@curcount=0) 
			BEGIN
                SELECT @message='No prices found for priceindex "'+@priceidxck+'" on pricedate '+CONVERT(VARCHAR(19),@pricedate,20)
                

                PRINT @message
                --EXECUTE cspUpdateInterfaceAudit 'PriceCk','1', '0', 'cspCheckLoadedPriceCurvesIF49', @warninglevel, @Message
         	END

	   FETCH NEXT FROM curve_cursor 
       INTO @priceidxck,@warninglevel
   END -- WHILE over cstpriceindexcheck

   CLOSE curve_cursor;
   DEALLOCATE curve_cursor;
   PRINT 'Price curve check over.'
   EXECUTE cspUpdateInterfaceAudit 'PriceCk','0', '0', 'cspCheckLoadedPriceCurvesIF49', 'INFO', 'Price check of loaded prices via IF49 over.'
END


EXEC cspCheckLoadedPriceCurvesIF49;
select top 100 * from cstinterfaceaudit order by creationdate desc;
--DROP PROCEDURE cspCheckLoadedPriceCurvesIF49;
--DROP TABLE cstpriceindexcheck;


-- version: 319 module: allegro-collection date: 2013-01-11 11:37:57 
-- applied to:  HEAD 
-- marked as: view 
ALTER PROCEDURE [dbo].[cspCheckLoadedPriceCurvesIF49PriceDay]  @pricedate datetime, @includes varchar(32) AS
BEGIN
  DECLARE @weekday INT;
  SELECT @weekday=DATEPART(WEEKDAY, @pricedate);

  DECLARE @priceidxck VARCHAR(32);   
  DECLARE @warninglevel VARCHAR(32);
  DECLARE @message VARCHAR(255);
  DECLARE @curcount INT;


  DECLARE curve_cursor CURSOR FOR 
  SELECT cpi.cstpriceindexcheck,cpi.warninglevel FROM cstpriceindexcheck cpi
  WHERE cpi.active=1 AND cpi.wkday like '%'+CAST(@weekday AS VARCHAR(1))+'%' 
  AND cpi.cstpriceindexcheck like '%'+@includes+'%' ORDER BY cpi.cstpriceindexcheck;

   OPEN curve_cursor

   FETCH NEXT FROM curve_cursor 
   INTO @priceidxck,@warninglevel

   WHILE @@FETCH_STATUS = 0
   BEGIN
       --PRINT 'Currently checking '+@priceidxck+' with warning level '+@warninglevel+' and minimal count '+CAST(@countatleast AS VARCHAR(6))
	   
	   SELECT @curcount=count(*) from pricevalue where pricedate=@pricedate and priceindex=@priceidxck;
       
       IF (@curcount=0) 
			BEGIN
                SELECT @message='No prices found for priceindex "'+@priceidxck+'" on pricedate '+CONVERT(VARCHAR(19),@pricedate,20)
                

                PRINT @message
                --EXECUTE cspUpdateInterfaceAudit 'PriceCk','1', '0', 'cspCheckLoadedPriceCurvesIF49', @warninglevel, @Message
         	END

	   FETCH NEXT FROM curve_cursor 
       INTO @priceidxck,@warninglevel
   END -- WHILE over cstpriceindexcheck

   CLOSE curve_cursor;
   DEALLOCATE curve_cursor;
  
  
END


EXEC cspCheckLoadedPriceCurvesIF49PriceDay '2013-01-10','Forward'

/*
*  Stored Procedure cspCheckLoadedPriceCurvesIF49
*
*  This stored procedure goes through loaded price curves during the previous day and see if all are loaded.
*  Information on which curve has to be loaded when is stored in the table cstpriceindexcheck.
*  Accessible in Allegro in view 'Repower Parameters' Pane 'Priceindex checks'
*
*  Test with
*  EXEC cspCheckLoadedPriceCurvesIF49
*
* Retrieve output with
* select top 200 * from cstinterfaceaudit order by creationdate desc;
*
*  author: tiziano.mengotti
*  last changed: 11.1.2013
*/
ALTER PROCEDURE [dbo].[cspCheckLoadedPriceCurvesIF49] AS
BEGIN
   DECLARE @pricedatetoday DATETIME;
   DECLARE @pricedateyesterday DATETIME;
   
   

   SELECT @pricedatetoday=(SELECT DATEADD(dd, DATEDIFF(dd,0,getdate()), 0));
   SELECT @pricedateyesterday=(SELECT DATEADD(dd, DATEDIFF(dd,0,getdate()-1), 0));
   
   EXECUTE cspUpdateInterfaceAudit 'PriceCk','0', '0', 'cspCheckLoadedPriceCurvesIF49', 'INFO', 'Starting check on loaded price curves via IF49...'
   EXECUTE cspCheckLoadedPriceCurvesIF49PriceDay @pricedateyesterday, 'Forwar';
   EXECUTE cspCheckLoadedPriceCurvesIF49PriceDay @pricedatetoday, 'Settle';
   EXECUTE cspUpdateInterfaceAudit 'PriceCk','0', '0', 'cspCheckLoadedPriceCurvesIF49', 'INFO', 'Price check of loaded prices via IF49 over.'
END

EXEC cspCheckLoadedPriceCurvesIF49;


-- version: 322 module: allegro-collection date: 2013-01-15 11:31:30 
-- applied to:  HEAD 

update trade set tradestatus='Void',revisionname='MAM_2289',revisiondate=GETDATE() where trade in
(
194976,
194977,
194978,
194979,
194980,
194981,
194982,
194983,
194984
);


 EXECUTE cspUpdateDBAudit
                                        'MAM_2289' 
                                        ,'trade'
                                        ,'194984'
                                        ,'MODIFIED'
                                        ,'tradestatus' 
                                        ,'New'
                                        ,'Void';


-- version: 323 module: allegro-collection date: 2013-01-15 11:39:43 
-- applied to:  HEAD 

select * from trade where trade=192742;
select * from position where trade= 192742;
select * from powerquantity where position=192961 and begtime='2013-01-16' order by creationdate;


-- version: 324 module: allegro-collection date: 2013-01-18 14:52:32 
-- applied to:  HEAD 

select * from csttradingstrategy csttrstr
	where csttrstr.tradebook = 'POS Market Place';


-- version: 325 module: allegro-collection date: 2013-01-18 17:52:25 
-- applied to:  HEAD 

select * from dbaudit where dbtable='approval' and origvalue='0';



-- version: 326 module: allegro-collection date: 2013-01-22 09:25:36 
-- applied to:  HEAD 

/*
I should prepare a test as follows (in AllegroTest):
0. verify that no prices are loaded for 5.1.2013
1. Enter a trade in the past with delivdate 5.1.2013
2. Load a settlement price with pricedate=delivdate 5.1.2013
3. Forcing pricedate of this settlement price to be pricedate=4.1.2013 on all loaded prices with sql script
4. Change manually one price in GUI to make sure the value is picked and the cache is cleared
4. Execute Position valuation on this trade
5. See if the trade is correctly valued, or if Allegro can't find prices for 5.1.2013 because pricedate<>delivdate
*/
-- 0
select * from pricevalue where delivdate>='2013-01-05' and delivdate<'2013-01-06' order by delivdate;
select distinct priceindex from pricevalue where delivdate>='2013-01-05' and delivdate<'2013-01-06';

-- 1: trade number is 164345, trade is FO approved
-- 2: Settlement is attached to Mantis 2206, file moved to R:\CORP\App\AllegroInterfaces\TEST\AllegroTest\49\Inbox
-- 3:
update pricevalue set pricedate='2013-01-04' where delivdate>='2013-01-05' and delivdate<'2013-01-06' 
and priceindex='Power DE Hour Settle';
-- 4: Manually changed price in 'Hourly prices' from 2 to 3
-- 5: Executing position valuation with valuationtime 21.1.2013 23:00 on trade 164345
-- 6: No valuationdetails are generated!!!:
select * from valuationdetail where valuation=102847;
-- returns empty result!!!


-- version: 327 module: allegro-collection date: 2013-01-24 09:19:18 
-- applied to:  HEAD 

-- rbsql04  / allegroMAM mam4allegro
select @@version;
select count(*) from pricevalue;
select count(*) from valuationdetail;
select count(*) from trade;

-- Microsoft SQL Server 2012 (SP1) - 11.0.3000.0 (X64)   Oct 19 2012 13:38:57   Copyright (c) Microsoft Corporation  Enterprise Edition (64-bit) on Windows NT 6.1 <X64> (Build 7601: Service Pack 1) (Hypervisor) 
-- la vecchia versione invece
-- Microsoft SQL Server 2005 - 9.00.4035.00 (X64)   Nov 24 2008 16:17:31   Copyright (c) 1988-2005 Microsoft Corporation  Enterprise Edition (64-bit) on Windows NT 5.2 (Build 3790: Service Pack 2) 


-- version: 328 module: allegro-collection date: 2013-01-24 14:14:23 
-- applied to:  HEAD 

select distinct product from position; 


-- version: 329 module: allegro-collection date: 2013-01-28 11:31:11 
-- applied to:  HEAD 

select pq.* from position p, powerquantity pq where p.trade=197528 and pq.position=p.position;

select pp.* from position p, powerposition pp where p.trade=197528 and pp.position=p.position;

-- se questa query ritorna they records essi vanno cancellati
-- il call a cspDeleteUnlinkedPositions non funziona fino al 31.1.2013
select * from powerposition 
where posdetail in 
	(select pw.posdetail from powerposition pw 
	 left outer join powerquantity pq on pw.posdetail = pq.posdetail and pw.position = pq.position
	 join position ps on ps.position = pw.position
	 where pq.position is null
	and ps.trade = 197539 )	


-- version: 330 module: allegro-collection date: 2013-02-01 16:30:07 
-- applied to:  HEAD 

/*
Questa era la select che ho fatto stamattina sui trades in EXPORTED, a parte il primo 116950 che abbiamo verificato a mano fra ET3000 e Allegro, erano tutti nel passato con End date 1.2.2013
*/
select trade.trade, trade.begtime, trade.endtime from trade
where trade in
(
116950,
190656,
190632,
190596,
190551,
190503,
190467,
190455,
190443,
190431,
190371,
190323,
190311,
190287,
190263,
190251,
189735,
183459,
130484,
130340,
130184,
130109,
129641,
129605
) order by endtime desc;



-- version: 331 module: allegro-collection date: 2013-02-01 17:11:19 
-- applied to:  HEAD 

select distinct priceindex from pricevalue where pricedate='2012-09-30' and priceindex like '%NP%' and priceindex<>'Power NP Base Settle'
 group by priceindex;

select count(*) from pricevalue where pricedate='2012-09-30' and priceindex like '%NP%' and priceindex<>'Power NP Base Settle';


select distinct priceindex from pricevalue where pricedate='2012-10-31' and priceindex like '%NP%' and priceindex<>'Power NP Base Settle'
 group by priceindex;

select count(*) from pricevalue where pricedate='2012-10-31' and priceindex like '%NP%' and priceindex<>'Power NP Base Settle'



select distinct priceindex from pricevalue where pricedate='2012-11-30' and priceindex like '%NP%' and priceindex<>'Power NP Base Settle'
 group by priceindex;
select count(*) from pricevalue where pricedate='2012-11-30' and priceindex like '%NP%' and priceindex<>'Power NP Base Settle'



select distinct priceindex from pricevalue where pricedate='2012-12-30' and priceindex like '%NP%' and priceindex<>'Power NP Base Settle'
 group by priceindex;

select count(*) from pricevalue where pricedate='2012-12-30' and priceindex like '%NP%' and priceindex<>'Power NP Base Settle'



select distinct priceindex from pricevalue where pricedate='2013-01-31' and priceindex like '%NP%' and priceindex<>'Power NP Base Settle'
 group by priceindex;

select count(*) from pricevalue where pricedate='2013-01-31' and priceindex like '%NP%' and priceindex<>'Power NP Base Settle'


-- version: 332 module: allegro-collection date: 2013-02-05 08:38:16 
-- applied to:  HEAD 

select * from documentformat;

-- qui si vede che viene utilizzata la tabella documentformat
ALTER PROCEDURE [dbo].[cspExportToExcel]
(
	@TableName    VARCHAR(100),
	@DocumentType VARCHAR(100),
	@TimeStamp    VARCHAR(100) = '',
	@OrderBy	  VARCHAR(1000) = ''
)
/******
 
  Script:		cspExportToExcel
  Script Date:		2011-08-31 18:43:09 
  Project:		Up-Trade
  Author:		AM, Logica
  Description:		Mantis 1359 Credit export contract valuation detail results

  $Id: cspExportToExcel.sql 3493 2011-09-01 08:39:13Z lancaricm $

******/
AS

DECLARE @Columns  VARCHAR(8000)
DECLARE @SQL      VARCHAR(8000)
DECLARE @DataFile VARCHAR(100)
DECLARE @Filename VARCHAR(100)
DECLARE @Path     VARCHAR(100)
DECLARE @DBName   VARCHAR(100)

------------------------------------------------------------------
-- Select document properties from DB
------------------------------------------------------------------

SELECT @Filename=outfilename, @Path=outputlocation
FROM documentformat
WHERE documentformat = @DocumentType

-------------------------------------------

--Qui invece la preparazione dell'export vero e proprio:
ALTER PROCEDURE [dbo].[cspEoDContractValueDetail]
AS
/******
 
  Script:		cspEoDContractValueDetail
  Script Date:		2011-08-31 18:43:09 
  Project:		Up-Trade
  Author:		JG, Logica
  Description:		Mantis 1359 Credit export contract valuation detail results

  $Id: cspEoDContractValueDetail.sql 3493 2011-09-01 08:39:13Z lancaricm $

******/
BEGIN
-- prima si crea la select

-- qui definisce l'export col DocumentType

-- 	SELECT @Timestamp = CONVERT(VARCHAR, @EoDValTime, 112) + '_' + REPLACE(CONVERT(VARCHAR, @EoDValTime, 108), ':', '')
	
	IF(@Timestamp != '')
		SET @SQL = 'EXEC dbo.cspExportToExcel ''cstEoDContractValueDetail'', ''EoD Contract Value Export'', ''' + @Timestamp + ''', ''order by valuation, positiontype, counterparty, company, producttype, currency'''
	ELSE
		SET @SQL = 'EXEC dbo.cspExportToExcel ''cstEoDContractValueDetail'', ''EoD Contract Value Export'',  @OrderBy=''order by valuation, positiontype, counterparty, company, producttype, currency'''

	EXEC(@SQL)	
END

-- l'export va sotto \\corp.repower.com\dfs\Corp\App\Allegro\PROD\Risk


-- version: 333 module: allegro-collection date: 2013-02-06 11:20:48 
-- applied to:  HEAD 


-- trade 172840 2012-10 trade with contract value 119200, market value 120503.75 and market price 32.34
--delete from valuationdetail where valuation=103381 and trade=172840;
select * from valuationdetail where valuation=103381 and trade=172840;

select sum(value),sum(marketvalue) from valuationdetail where valuation=103381 and trade=172840 and isnull(description,'')='';

-- trade 153234 2012-Q4, contract value 465546.750000	market value 408665.000000, price 37
--delete from valuationdetail where valuation=103381 and trade=153234;
select * from valuationdetail where valuation=103381 and trade=153234;
select sum(value),sum(marketvalue) from valuationdetail where valuation=103381 and trade=153234 and isnull(description,'')='';


select * from valuation where valuation=103381;
select * from valuationdetail where valuation=103381 and marketarea='NP';


-- version: 334 module: allegro-collection date: 2013-02-11 16:20:51 
-- applied to:  HEAD 

select creationdate, trade from trade where tradetype='Power Financial' order by creationdate desc;

SELECT t.trade, t.tradedate, t.begtime, f.fee, f.pricediff FROM trade t, position p, fee f WHERE t.tradetype='Power Financial' AND p.trade=t.trade AND f.dbcolumn='POSITION' AND f.dbvalue=p.position
and f.pricediff=(40.35-0.25) and t.begtime='2013-01-01'
--ORDER BY f.pricediff ASC;


SELECT t.trade, t.tradedate, t.begtime, f.fee, f.pricediff FROM trade t, position p, fee f WHERE t.tradetype='Power Financial' AND p.trade=t.trade AND f.dbcolumn='POSITION' AND f.dbvalue=p.position
and f.pricediff=(42.62+0.25) and t.begtime='2013-02-01'
--ORDER BY f.pricediff ASC;


SELECT t.trade, t.tradedate, t.begtime, f.fee, f.pricediff FROM trade t, position p, fee f WHERE t.tradetype='Power Financial' AND p.trade=t.trade AND f.dbcolumn='POSITION' AND f.dbvalue=p.position
and f.pricediff=(38.5-0.25) and t.begtime='2013-03-01'
--ORDER BY f.pricediff ASC;


select top 100 * from fee;


-- version: 335 module: allegro-collection date: 2013-02-12 10:59:03 
-- applied to:  HEAD 

select MAX(creationdate) from pricevalue;


SELECT priceindex, pricesource FROM priceindex WHERE marketarea='IT' AND pricesource IN ('GME_WEEK', 'GME_MONTH', 'IDEX_MON')
AND priceindex LIKE '%Forwar%'
 ORDER BY priceindex;
 
 
select t.* from trade t, position p where p.trade=t.trade and p.marketarea='IT' and t.begtime>='2013-01-01';

select distinct marketarea from position order by marketarea;

select t.* from trade t, position p where p.trade=t.trade and p.marketarea='IT' and t.tradetype='Power Term';


select priceindex, count(*) from pricevalue where pricedate='2013-02-05' group by priceindex;

select * from valuationdetail where valuation=102851;


-- version: 336 module: allegro-collection date: 2013-02-13 15:23:40 
-- applied to:  HEAD 



select distinct block from position;


select begtime, endtime, datediff(DAY, begtime, endtime) as diff from trade t, position p where t.trade=p.trade and p.block='Sat-Sun 08-20h' and t.tradestatus<>'Void'
order by diff asc;


select begtime, endtime, datediff(DAY, begtime, endtime) as diff from trade t, position p where t.trade=p.trade and p.block='Sat-Sun 08-20h' and t.tradestatus<>'Void'
order by diff asc;



select distinct block, datediff(DAY, begtime, endtime) as diff from trade t, position p where t.trade=p.trade and (datediff(DAY, begtime, endtime)<=2)
order by block, diff



-- version: 337 module: allegro-collection date: 2013-02-14 08:54:02 
-- applied to:  HEAD 

Select * from dbobject where dbtable in ('valuationexposure', 'valuationperiod','valuationproduct') and creationname <>'SYSTEM';

/*
�ValCompat� key in the Config pane of the Server Manager to True (Navigation sidebar >> Administration >> Activity Monitoring >> Server Manager).  The key is False, therefore no action required.
*/


-- version: 339 module: allegro-collection date: 2013-02-15 09:23:03 
-- applied to:  HEAD 

--select * from securityuser where userid like 'allegroi';

--select distinct priceindex from pricevalue where priceindex like '%NP%' and pricedate='2012-01-31';

/*
delete from pricevalue where priceindex like '%NP%' and priceindex <> 'Power NP Base Settle'
and pricedate='2012-01-31';

delete from pricevalue where priceindex like '%NP%' and priceindex <> 'Power NP Base Settle'
and pricedate='2012-02-29';

delete from pricevalue where priceindex like '%NP%' and priceindex <> 'Power NP Base Settle'
and pricedate='2012-03-30';

delete from pricevalue where priceindex like '%NP%' and priceindex <> 'Power NP Base Settle'
and pricedate='2012-04-30';

delete from pricevalue where priceindex like '%NP%' and priceindex <> 'Power NP Base Settle'
and pricedate='2012-05-31';

delete from pricevalue where priceindex like '%NP%' and priceindex <> 'Power NP Base Settle'
and pricedate='2012-06-29';


delete from pricevalue where priceindex like '%NP%' and priceindex <> 'Power NP Base Settle'
and pricedate='2012-07-31';


delete from pricevalue where priceindex like '%NP%' and priceindex <> 'Power NP Base Settle'
and pricedate='2012-08-31';
*/

select distinct priceindex from pricevalue where priceindex like '%NP%' and priceindex <> 'Power NP Base Settle'
and pricedate='2012-01-31';
select distinct priceindex  from pricevalue where priceindex like '%NP%' and priceindex <> 'Power NP Base Settle'
and pricedate='2012-02-29';

select distinct priceindex from pricevalue where priceindex like '%NP%' and priceindex <> 'Power NP Base Settle'
and pricedate='2012-03-30';

select distinct priceindex from pricevalue where priceindex like '%NP%' and priceindex <> 'Power NP Base Settle'
and pricedate='2012-04-30';

select distinct priceindex from pricevalue where priceindex like '%NP%' and priceindex <> 'Power NP Base Settle'
and pricedate='2012-05-31';

select distinct priceindex from pricevalue where priceindex like '%NP%' and priceindex <> 'Power NP Base Settle'
and pricedate='2012-06-29';


select distinct priceindex from pricevalue where priceindex like '%NP%' and priceindex <> 'Power NP Base Settle'
and pricedate='2012-07-31';


select distinct priceindex from pricevalue where priceindex like '%NP%' and priceindex <> 'Power NP Base Settle'
and pricedate='2012-08-31';


-- version: 340 module: allegro-collection date: 2013-02-15 13:26:33 
-- applied to:  HEAD 

select top 100 * from cstinterfaceaudit where interfaceid='Int_49'
 and creationdate>='2013-02-09' and creationdate<'2013-02-10' order by creationdate desc;



-- version: 341 module: allegro-collection date: 2013-02-22 11:42:43 
-- applied to:  HEAD 

select trade, tradestatus from trade where trade in (201560);
/*
31.1.2012 23:00
29.2.2012 23:00
30.3.2012 23:00
30.4.2012 23:00
31.5.2012 23:00
29.6.2012 23:00
31.7.2012 23:00
31.8.2012 23:00
30.09.2012 23:00
31.10.2012 23:00
30.11.2012 23:00
30.12.2012 23:00
*/

-- select
select distinct priceindex from pricevalue where pricedate='2012-01-31' and priceindex like '%NP%' and priceindex <> 'Power NP Base Settle';
select distinct priceindex from pricevalue where pricedate='2012-02-29' and priceindex like '%NP%' and priceindex <> 'Power NP Base Settle';
select distinct priceindex from pricevalue where pricedate='2012-03-30' and priceindex like '%NP%' and priceindex <> 'Power NP Base Settle'; 
select distinct priceindex from pricevalue where pricedate='2012-03-31' and priceindex like '%NP%' and priceindex <> 'Power NP Base Settle'; 
select distinct priceindex from pricevalue where pricedate='2012-04-30' and priceindex like '%NP%' and priceindex <> 'Power NP Base Settle'; 
select distinct priceindex from pricevalue where pricedate='2012-05-31' and priceindex like '%NP%' and priceindex <> 'Power NP Base Settle'; 

select distinct priceindex from pricevalue where pricedate='2012-06-29' and priceindex like '%NP%' and priceindex <> 'Power NP Base Settle';
select distinct priceindex from pricevalue where pricedate='2012-06-30' and priceindex like '%NP%' and priceindex <> 'Power NP Base Settle'; 

select distinct priceindex from pricevalue where pricedate='2012-07-31' and priceindex like '%NP%' and priceindex <> 'Power NP Base Settle'; 
select distinct priceindex from pricevalue where pricedate='2012-08-31' and priceindex like '%NP%' and priceindex <> 'Power NP Base Settle'; 

select distinct priceindex from pricevalue where pricedate='2012-09-30' and priceindex like '%NP%' and priceindex <> 'Power NP Base Settle'; 
select distinct priceindex from pricevalue where pricedate='2012-10-31' and priceindex like '%NP%' and priceindex <> 'Power NP Base Settle'; 
select distinct priceindex from pricevalue where pricedate='2012-11-30' and priceindex like '%NP%' and priceindex <> 'Power NP Base Settle'; 

select distinct priceindex from pricevalue where pricedate='2012-12-30' and priceindex like '%NP%' and priceindex <> 'Power NP Base Settle'; 
select distinct priceindex from pricevalue where pricedate='2012-12-31' and priceindex like '%NP%' and priceindex <> 'Power NP Base Settle'; 

select distinct priceindex from pricevalue where pricedate='2013-01-31' and priceindex like '%NP%' and priceindex <> 'Power NP Base Settle'; 
 
-- delete prices del 31.3.2013  PROD OK    UAT OK  
-- delete prices del 30.6.2013  PROD OK    UAT OK 
-- delete prices del 31.12.2013  PROD OK    UAT OK  

-- reexecute valutation del 31.3.2013   PROD OK UAT OK
-- reexecute valutation del 30.6.2013   PROD OK UAT OK
-- reexecute valutation del 31.12.2013   PROD OK UAT OK
-- reexecute valutation del 31.1.2013   PROD OK UAT in progress


-- check report March UAT

select * from valuation where valuationtime='2013-01-31 23:00';


-- version: 342 module: allegro-collection date: 2013-03-01 09:17:10 
-- applied to:  HEAD 

/*
In Energy Position by Region/Hour flat
POS GER+AUT

POS Schaeffler Group
*/
position.counterparty in 
(RUVILLE_DE, AFT_DE, INA_DR_ME_DE,LUK_DE,LUK_TR_DE,LUK_UN_DE,SCHAEFFLER_AT, SCHAEFFLER_AU_AF_DE,SCHAEFFLER_EL_DE,SCHAEFFLER_FR_PR_HA_DE,SCHAEFFLER_TE_DE,SCHAEFFLER_MO_DE)



-- version: 343 module: allegro-collection date: 2013-03-01 17:39:23 
-- applied to:  HEAD 

select * from valuation where valuationtime='2013-02-28 23:00';

--delete from pricevalue where pricedate='2013-02-28' and priceindex like '%IT%' and priceindex like '%Forward%'; --65666 rows deleted
select count(*) from pricevalue where pricedate='2013-02-28' and priceindex like '%IT%' and priceindex like '%Forward%';


SELECT --top 100 
CONVERT(VARCHAR(19),t.tradedate,20),
t.cstaccountingpurpose, t.trade, t.currency, vd.currency, vd.marketarea, vd.counterparty, vd.producttype, vd.price,
vd.marketprice, vd.priceunit, vd.exposure, vd.positionmode, p.positiontype, vd.cstquantityunrealised,vd.quantity,vd.pricequantity,
CONVERT(VARCHAR(19),vd.begtime,20), CONVERT(VARCHAR(19),vd.endtime,20),
vd.cstunrealisedvalue,
vd.cstnpvalue, vd.cstrealisedvalue, vd.validation, vd.block, vd.tsperiod, vd.cstgenplantname, vd.cstdeliverymonth, vd.cstdeliveryyear,
vd.csttradingstrategy, vd.tradebook, vd.company, vd.cstcompetencycentre

FROM valuationdetail vd, trade t, position p
WHERE
vd.valuation=(SELECT valuation FROM valuation WHERE valuationtime='2013-02-28 23:00' AND valuationmode='Position') AND vd.trade=t.trade AND vd.trade=p.trade
AND vd.counterparty NOT IN ('RE_AG')
AND t.cstaccountingpurpose='HfT'  
AND vd.producttype='Power'
AND vd.fee IS NULL 
AND vd.marketarea<>'NP'
AND t.endtime>'2013-03-01 00:00:00'
AND t.tradedate<'2013-03-01 00:00:00'
AND t.tradestatus<>'Void';


-- version: 344 module: allegro-collection date: 2013-03-04 16:08:36 
-- applied to:  HEAD 

-- November 2012
select sum(vd.value) as sumvalue, f.description from valuationdetail vd, fee f, trade t where 
vd.valuation=(select valuation from valuation where valuationtime='2012-11-30 23:00' and valuationmode='Position')
and vd.fee=f.fee and t.trade=vd.trade
and t.tradedate>='2012-11-01 00:00:00' and t.tradedate<'2012-12-01 00:00:00'
and f.description like '%Nordpool%' group by f.description with cube;

-- December 2012
select sum(vd.value) as sumvalue, f.description from valuationdetail vd, fee f, trade t where 
vd.valuation=(select valuation from valuation where valuationtime='2012-12-31 23:00' and valuationmode='Position')
and vd.fee=f.fee and t.trade=vd.trade
and t.tradedate>='2012-12-01 00:00:00' and t.tradedate<'2013-01-01 00:00:00'
and f.description like '%Nordpool%' group by f.description with cube;


-- January 2012 is OK :-)
select sum(vd.value) as sumvalue, f.description from valuationdetail vd, fee f, trade t where 
vd.valuation=(select valuation from valuation where valuationtime='2012-01-31 23:00' and valuationmode='Position')
and vd.fee=f.fee and t.trade=vd.trade
and t.tradedate>='2012-01-01 00:00:00' and t.tradedate<'2012-02-01 00:00:00'
and f.description like '%Nordpool%' group by f.description with cube;


-- version: 345 module: allegro-collection date: 2013-03-07 14:08:20 
-- applied to:  HEAD 

select * from brokerfee where broker like '%Nordpool%';
select broker, feetype, pricediff, paymentterms, counterparty from brokerfee b where broker like '%Nordpool%' order by broker, feetype;


-- version: 349 module: allegro-collection date: 2013-03-11 09:48:12 
-- applied to:  HEAD 

select sum(vd.value) as sumvalue, f.description, f.feetype from valuationdetail vd, fee f, trade t where 
vd.valuation=(select valuation from valuation where valuationtime='2012-03-31 23:00' and valuationmode='Position')
and vd.fee=f.fee and t.trade=vd.trade 
and vd.trade=152754
and f.description like '%Nordpoo%' group by f.description, f.feetype, vd.value;


select sum(vd.value) as sumvalue, t.tradedate, vd.trade, vd.begtime as sumvalue from valuationdetail vd, trade t  where 
vd.valuation=(select valuation from valuation where valuationtime='2012-03-31 23:00' and valuationmode='Position')
and t.trade=vd.trade
and vd.trade=192292
group by t.tradedate, vd.trade, vd.begtime


-- 9 trades in dicembre di Michael, gli altri 4831 dati dal cascading!!
select * from trade t, position p 
where p.trade=t.trade
and p.marketarea='NP'
--and 1=(select count(*) from position p1, trade t1 where t1.trade=t.trade and p1.trade=t1.trade)
and t.creationname<>'Michael Pries'
and t.tradedate>='2012-12-01' and t.tradedate<'2013-01-01';


-- i trades con la loro fee
select t.trade, t.tradetype, t.tradedate, t.timeperiod, f.pricediff from trade t, position p, fee f 
where p.trade=t.trade
and p.marketarea='NP'
and 1=(select count(*) from position p1, trade t1 where t1.trade=t.trade and p1.trade=t1.trade)
--and t.creationname<>'Michael Pries'
and f.dbcolumn='POSITION' and f.dbvalue=p.position
and t.tradestatus<>'Void'
and f.feetype is not null
and t.tradedate>='2012-12-01' and t.tradedate<'2013-01-01' order by trade;


-- i trades nella valuation
select t.trade, t.tradetype, CONVERT(VARCHAR(19), t.tradedate, 20), t.timeperiod, f.pricediff, f.description from trade t, position p, fee f 
where p.trade=t.trade
and p.marketarea='NP'
and 1=(select count(*) from position p1, trade t1 where t1.trade=t.trade and p1.trade=t1.trade)
--and t.creationname<>'Michael Pries'
and f.dbcolumn='POSITION' and f.dbvalue=p.position
and t.tradestatus<>'Void'
and f.feetype is not null
and t.tradedate>='2012-12-01' and t.tradedate<'2013-01-01' order by t.trade;


-- i dettagli di un valuationdetail per un trade
select sum(vd.value) as sumvalue, f.description, f.feetype from valuationdetail vd, fee f, trade t where 
vd.valuation=(select valuation from valuation where valuationtime='2012-12-31 23:00' and valuationmode='Position')
and vd.fee=f.fee and t.trade=vd.trade 
and t.tradedate>='2012-12-01 00:00:00' and t.tradedate<'2013-01-01 00:00:00'
and t.trade=191512
and f.description like '%Nordpoo%' 
group by f.description, f.feetype;


-- version: 350 module: allegro-collection date: 2013-03-11 16:04:31 
-- applied to:  HEAD 

select t.trade, t.tradetype, CONVERT(VARCHAR(19), t.tradedate, 20), t.timeperiod, f.pricediff, f.description from trade t, position p, fee f 
where p.trade=t.trade
and p.marketarea='NP'
and 1=(select count(*) from position p1, trade t1 where t1.trade=t.trade and p1.trade=t1.trade)
--and t.creationname<>'Michael Pries'
and f.dbcolumn='POSITION' and f.dbvalue=p.position
and t.tradestatus<>'Void'
and f.feetype is not null
and t.tradedate>='2012-12-01' and t.tradedate<'2013-01-01' order by t.trade;

-- note: to retrieve the fixed price, one has to set f.feetype is NULL in the query above.


-- version: 351 module: allegro-collection date: 2013-03-11 16:24:09 
-- applied to:  HEAD 

/*
queries for final broker fee check Nordpool
*/
select t.trade, t.tradetype, CONVERT(VARCHAR(19), t.tradedate, 20) as tradedate, t.timeperiod, f.pricediff, f.description from trade t, position p, fee f 
where p.trade=t.trade
and p.marketarea='NP'
and 1=(select count(*) from position p1, trade t1 where t1.trade=t.trade and p1.trade=t1.trade)
--and t.creationname<>'Michael Pries'
and f.dbcolumn='POSITION' and f.dbvalue=p.position
and t.tradestatus<>'Void'
and f.feetype is not null
and t.tradedate>='2012-12-01' and t.tradedate<'2013-01-01' order by t.trade;

select sum(vd.value) as sumvalue, f.description, f.feetype from valuationdetail vd, fee f, trade t where 
vd.valuation=(select valuation from valuation where valuationtime='2012-12-31 23:00' and valuationmode='Position')
and vd.fee=f.fee and t.trade=vd.trade 
and t.tradedate>='2012-12-01 00:00:00' and t.tradedate<'2013-01-01 00:00:00'
and f.description like '%Nordpoo%' group by f.description, f.feetype;


-- version: 355 module: allegro-collection date: 2013-03-18 08:38:00 
-- applied to:  HEAD 

select top 100 * from gridlog order by creationdate desc;

delete from gridlog where surrogate=134518;


-- version: 357 module: allegro-collection date: 2013-03-19 14:58:54 
-- applied to:  HEAD 

-- in prod
EXEC cspCrystalReports_HoM02_G01 '90001704';
/*
Warning: Null value is eliminated by an aggregate or other SET operation.
Warning: Null value is eliminated by an aggregate or other SET operation.
Warning: Null value is eliminated by an aggregate or other SET operation.
Msg 468, Level 16, State 9, Procedure cspCrystalReports_HoM02_G01, Line 221
Cannot resolve the collation conflict between "Latin1_General_CI_AS" and "SQL_Latin1_General_CP1_CI_AS" in the equal to operation.
*/

-- in UAT
EXEC cspCrystalReports_HoM02_G01 '90001390';
OK, ritorna uan lista di valori


EXEC cspCrystalReports_HoM02_G02 '90001704';

EXEC cspCrystalReports_HoM02_G03_G05 '90001704', 'POS';

EXEC cspCrystalReports_HoM02_T01a '90001704';

EXEC cspCrystalReports_HoM02_T01b '90001704';

EXEC cspCrystalReports_HoM02_T01b_Centre_Vr_Column '90001704', 'POS';

EXEC cspCrystalReports_HoM02_T01b_Centre_Vv_Column '90001704', 'POS';


EXEC cspCrystalReports_HoM02_T01b_Group_Vr_Column '90001704';

EXEC cspCrystalReports_HoM02_T01b_Group_Vv_Column '90001704';


-- version: 358 module: allegro-collection date: 2013-03-19 14:59:59 
-- applied to:  HEAD 

USE [Allegro]
GO
/****** Object:  StoredProcedure [dbo].[cspCrystalReports_HoM02_G01]    Script Date: 03/19/2013 15:00:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
 
ALTER PROCEDURE [dbo].[cspCrystalReports_HoM02_G01]
/*
	Object:			Stored procedure	 cspCrystalReports_HoM02_G01
	Script Date:	10-Oct-2010
	Project: 		Up-Trade
	Author:			LN, Logica
	Description:	Returns data for graph HoM02 G01 
					
	$Id: cspCrystalReports_HoM02_G01.sql 3299 2011-07-11 10:19:03Z ondrakj $ 
*/
(
	@collaboration	VARCHAR(8)
)
AS
BEGIN
SET NOCOUNT ON
	
		
	---------------------------------------------------------------------------
	-- Log input parameters into [dbo].[cstInterfaceAudit] as NOTIFICATION type
	-----------------------------------------------------------------------------
	DECLARE	@Message VARCHAR(200)
	SET		@Message =	 'cspCrystalReports_HoM02_G01 ('
						+@collaboration
						+')'
	EXECUTE	cspUpdateInterfaceAudit 'cspCrystalReports_HoM02_G01', 'RISK REPORT', NULL, 'cspCrystalReports_HoM02_G01', 'NOTIFICATION', @Message;

	
	BEGIN TRY

			DECLARE @Vr	VARCHAR(32)				
			DECLARE	@Dv DATETIME					
			DECLARE	@Dr	DATETIME					
			DECLARE	@Vv VARCHAR(32)
			DECLARE	@valtime DATETIME
			DECLARE	@valtimev DATETIME
					
			---------------------------------------------------------------------------
			-- Valuation parameters to be obtained from cstCrystalReportsRiskParamaters
			---------------------------------------------------------------------------
			DECLARE @varianceperiod SMALLINT
			DECLARE @Ymax SMALLINT
			DECLARE @interfaceid VARCHAR(8)
			DECLARE @valmode VARCHAR(32)
			DECLARE @valtype VARCHAR(32)
			DECLARE @valstatus VARCHAR(32)
			DECLARE @interfaceelementid VARCHAR(20)
			DECLARE @varcode VARCHAR(5)
			DECLARE @varseq VARCHAR(5)
			DECLARE @description VARCHAR(1024)

			-- !!! Set INTERFACE ID !!!
			SET @interfaceid = 'HoM02' 

			-- !!! Set INTERFACE ELEMENT ID !!!
			SET @interfaceelementid = 'G01'
			
			--------------------
			-- Get report config
			--------------------
			SELECT	@varianceperiod = varianceperiod,
					@Ymax = Ymax,		
					@valtype = valtype,
					@valstatus = valstatus,
					@varcode = varcode,
					@varseq = varseq,
					@description = description
			FROM	cstCrystalReportsRiskParamaters 
			WHERE	interfaceid = @interfaceid AND interfaceelementid = @interfaceelementid

			SET		@valmode = (SELECT valuationmode FROM valuation WHERE collaboration = @collaboration)

			--Check values
			--SELECT @varianceperiod AS [@varianceperiod],  @Ymax AS [@Ymax],  @valtype AS [@valtype],  @valstatus AS [@valstatus],  @varcode AS [@varcode],  @varseq AS [@varseq],  @description AS [@description],  @valmode AS [@valmode]

			--------------
			-- Set Valtime
			--------------
			SET @valtime = (SELECT valuationtime FROM valuation WHERE collaboration = @collaboration)

			------------------------
			-- Get valuation details
			------------------------	
			EXEC cspCrystalReports_ValuationsDetails 
				 -- Input:
							@collaboration,	
							@valmode,		
							@valtype,		
							@valstatus,		
							@varianceperiod,
							@interfaceid,	
				 -- Output:
							@Vr	OUTPUT,				
							@Dv OUTPUT,				
							@Dr OUTPUT,				
							@Vv OUTPUT,				
							@valtimev OUTPUT	
			SET @valtime = (SELECT valuationtime FROM valuation WHERE collaboration = @collaboration)
			----Check values
			--SELECT  @Vr AS [Vr], @Dr AS [Dr], @Vv AS [Vv], @Dv AS [Dv], @valtime AS [MaxDrValTime], @valtimev AS [MaxDvValTime]

			DECLARE	@Yr	DATETIME	
			SET @Yr = convert(datetime,cast(year(@Dr) as varchar(4))+'-01-01',120)		

			---------------------------
			-- Define the results table
			---------------------------
			CREATE TABLE #T01(
								valuation			VARCHAR(32) NULL,
								ValuationDate		DATETIME NULL,
								RealisedPnLGroup	DECIMAL(24,6) NULL,
								RealisedPnLPOS		DECIMAL(24,6) NULL,	-- will be UPDATEd from own tab.
								RealisedPnLMIL		DECIMAL(24,6) NULL,	-- will be UPDATEd from own tab.
								RealisedPnLPRA		DECIMAL(24,6) NULL,	-- will be UPDATEd from own tab.
								ValuationTime		DATETIME NULL
							 )

			-------------------
			-- Whole Group Data
			-------------------
			INSERT INTO #T01 (valuation,RealisedPnLGroup,ValuationDate,ValuationTime)	
			SELECT	vah.valuation AS [valuation],
					SUM(vah.cstrealisedvalue)/1000000 AS [RealisedPnLGroup],
					dh.valuationdate AS [ValuationDate],
					vah.valuationtime AS [valuationtime]
			FROM	cvwEoDDateHistory dh
				  LEFT OUTER JOIN cvwEoDValuationAggregationHistory vah
						ON    vah.valuationdate = dh.valuationdate
							  AND vah.valuationmode = @valmode
							  AND vah.valuationdate >= @Yr
							  AND vah.valuationdate <= @Dr
							  AND vah.cstdeliveryyear >= CAST(YEAR(@Yr) AS VARCHAR(4))
							  AND vah.cstdeliveryyear <= CAST(YEAR(@Yr) + @YMAX AS VARCHAR(4))
							  AND vah.producttype IN ('Power', 'Power Capacity')
			WHERE dh.valuationdate >= @Yr
				  AND dh.valuationdate < DATEADD(year, 1, @Yr)
			GROUP BY dh.valuationdate,vah.valuationtime, vah.valuation
			ORDER BY dh.valuationdate
					

			-----------
			-- POS Data
			-----------
			SELECT	vah.valuation AS [valuation],
					SUM(vah.cstrealisedvalue)/1000000 AS [RealisedPnLPOS],
					dh.valuationdate AS [ValuationDate],
					vah.valuationtime AS [valuationtime]
			INTO #T02
			FROM	cvwEoDDateHistory dh
				  LEFT OUTER JOIN cvwEoDValuationAggregationHistory vah
						ON    vah.valuationdate = dh.valuationdate
							  AND vah.valuationmode = @valmode
							  AND vah.valuationdate >= @Yr
							  AND vah.valuationdate <= @Dr
							  AND vah.cstdeliveryyear >= CAST(YEAR(@Yr) AS VARCHAR(4))
							  AND vah.cstdeliveryyear <= CAST(YEAR(@Yr) + @YMAX AS VARCHAR(4))
							  AND vah.producttype IN ('Power', 'Power Capacity')
							  AND vah.cstcompetencycentre = 'POS'
			WHERE dh.valuationdate >= @Yr
				  AND dh.valuationdate < DATEADD(year, 1, @Yr)
			GROUP BY dh.valuationdate,vah.valuationtime, vah.valuation
			ORDER BY dh.valuationdate
						
			
			

			-----------
			-- MIL Data
			-----------
			SELECT	vah.valuation AS [valuation],
					SUM(vah.cstrealisedvalue)/1000000 AS [RealisedPnLMIL],
					dh.valuationdate AS [ValuationDate],
					vah.valuationtime AS [valuationtime]
			INTO #T03
			FROM	cvwEoDDateHistory dh
				  LEFT OUTER JOIN cvwEoDValuationAggregationHistory vah
						ON    vah.valuationdate = dh.valuationdate
							  AND vah.valuationmode = @valmode
							  AND vah.valuationdate >= @Yr
							  AND vah.valuationdate <= @Dr
							  AND vah.cstdeliveryyear >= CAST(YEAR(@Yr) AS VARCHAR(4))
							  AND vah.cstdeliveryyear <= CAST(YEAR(@Yr) + @YMAX AS VARCHAR(4))
							  AND vah.producttype IN ('Power', 'Power Capacity')
							  AND vah.cstcompetencycentre = 'MIL'
			WHERE dh.valuationdate >= @Yr
				  AND dh.valuationdate < DATEADD(year, 1, @Yr)
			GROUP BY dh.valuationdate,vah.valuationtime, vah.valuation
			ORDER BY dh.valuationdate


			-----------
			-- PRA Data
			-----------
			SELECT	vah.valuation AS [valuation],
			[dbo].[cfnCrystalReports_RiskReport_Value] (dh.valuationdate, @Dr, SUM(vah.cstrealisedvalue)/1000000) AS [RealisedPnLPRA], --mantis 1305
					--SUM(vah.cstrealisedvalue)/1000000 AS [RealisedPnLPRA],
					dh.valuationdate AS [ValuationDate],
					vah.valuationtime AS [valuationtime]
			INTO #T04
			FROM	cvwEoDDateHistory dh
				  LEFT OUTER JOIN cvwEoDValuationAggregationHistory vah
						ON    vah.valuationdate = dh.valuationdate
							  AND vah.valuationmode = @valmode
							  AND vah.valuationdate >= @Yr
							  AND vah.valuationdate <= @Dr
							  AND vah.cstdeliveryyear >= CAST(YEAR(@Yr) AS VARCHAR(4))
							  AND vah.cstdeliveryyear <= CAST(YEAR(@Yr) + @YMAX AS VARCHAR(4))
							  AND vah.producttype IN ('Power', 'Power Capacity')
							  AND vah.cstcompetencycentre = 'PRA'
			WHERE dh.valuationdate >= @Yr
				  AND dh.valuationdate < DATEADD(year, 1, @Yr)
			GROUP BY dh.valuationdate,vah.valuationtime, vah.valuation
			ORDER BY dh.valuationdate



			---------------------------------------------------------------------------------------------------------
			-- Join competency centres data into #T01 business group table using valuation id and exact valuationtime
			---------------------------------------------------------------------------------------------------------
			UPDATE #T01	SET	#T01.RealisedPnLPOS = #T02.RealisedPnLPOS,
							#T01.RealisedPnLMIL = #T03.RealisedPnLMIL,
							#T01.RealisedPnLPRA = #T04.RealisedPnLPRA
			FROM #T01
			LEFT JOIN	#T02 ON (( #T02.valuation = #T01.valuation) AND (#T02.valuationtime =  #T01.valuationtime)) 
			LEFT JOIN	#T03 ON (( #T03.valuation = #T01.valuation) AND (#T03.valuationtime =  #T01.valuationtime)) 
			LEFT JOIN	#T04 ON (( #T04.valuation = #T01.valuation) AND (#T04.valuationtime =  #T01.valuationtime)) 

			---------
			-- Output
			---------
			SELECT 
				valuation,
				CONVERT(VARCHAR, ValuationDate,4) AS [X_AxisLabels],
				RealisedPnLGroup,
				RealisedPnLPOS,	
				RealisedPnLMIL,	
				RealisedPnLPRA,
				ValuationTime
			
			 FROM #T01




			DROP TABLE #T01
			DROP TABLE #T02
			DROP TABLE #T03
			DROP TABLE #T04



	END TRY	
	BEGIN CATCH
			GOTO proc_error;
	END CATCH

GOTO proc_exit;
	
proc_error:
		    -------------------------------------------------------
			-- Log error into cspUpdateInterfaceAudit as ERROR type
			-------------------------------------------------------
			DECLARE @ErrorMessage varchar(255)
			DECLARE @ErrorLine Int
			SET @ErrorMessage = ERROR_MESSAGE()
			SET @ErrorLine = ERROR_LINE()
			EXEC cspUpdateInterfaceAudit 'cspCrystalReports_HoM02_G01', 'RISK REPORT', @ErrorLine, 'cspCrystalReports_HoM02_G01', 'ERROR', @ErrorMessage

proc_exit:
	

END



-- version: 359 module: allegro-collection date: 2013-03-19 15:33:10 
-- applied to:  HEAD 

USE [Allegro]
GO
/****** Object:  StoredProcedure [dbo].[cspCrystalReports_HoM02_G01]    Script Date: 03/19/2013 15:00:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
 
ALTER PROCEDURE [dbo].[cspCrystalReports_HoM02_G01]
/*
	Object:			Stored procedure	 cspCrystalReports_HoM02_G01
	Script Date:	10-Oct-2010
	Project: 		Up-Trade
	Author:			LN, Logica
	Description:	Returns data for graph HoM02 G01 
					
	$Id: cspCrystalReports_HoM02_G01.sql 3299 2011-07-11 10:19:03Z ondrakj $ 
*/
(
	@collaboration	VARCHAR(8)
)
AS
BEGIN
SET NOCOUNT ON
	
		
	---------------------------------------------------------------------------
	-- Log input parameters into [dbo].[cstInterfaceAudit] as NOTIFICATION type
	-----------------------------------------------------------------------------
	DECLARE	@Message VARCHAR(200)
	SET		@Message =	 'cspCrystalReports_HoM02_G01 ('
						+@collaboration
						+')'
	EXECUTE	cspUpdateInterfaceAudit 'cspCrystalReports_HoM02_G01', 'RISK REPORT', NULL, 'cspCrystalReports_HoM02_G01', 'NOTIFICATION', @Message;

	
	BEGIN TRY

			DECLARE @Vr	VARCHAR(32)				
			DECLARE	@Dv DATETIME					
			DECLARE	@Dr	DATETIME					
			DECLARE	@Vv VARCHAR(32)
			DECLARE	@valtime DATETIME
			DECLARE	@valtimev DATETIME
					
			---------------------------------------------------------------------------
			-- Valuation parameters to be obtained from cstCrystalReportsRiskParamaters
			---------------------------------------------------------------------------
			DECLARE @varianceperiod SMALLINT
			DECLARE @Ymax SMALLINT
			DECLARE @interfaceid VARCHAR(8)
			DECLARE @valmode VARCHAR(32)
			DECLARE @valtype VARCHAR(32)
			DECLARE @valstatus VARCHAR(32)
			DECLARE @interfaceelementid VARCHAR(20)
			DECLARE @varcode VARCHAR(5)
			DECLARE @varseq VARCHAR(5)
			DECLARE @description VARCHAR(1024)

			-- !!! Set INTERFACE ID !!!
			SET @interfaceid = 'HoM02' 

			-- !!! Set INTERFACE ELEMENT ID !!!
			SET @interfaceelementid = 'G01'
			
			--------------------
			-- Get report config
			--------------------
			SELECT	@varianceperiod = varianceperiod,
					@Ymax = Ymax,		
					@valtype = valtype,
					@valstatus = valstatus,
					@varcode = varcode,
					@varseq = varseq,
					@description = description
			FROM	cstCrystalReportsRiskParamaters 
			WHERE	interfaceid = @interfaceid AND interfaceelementid = @interfaceelementid

			SET		@valmode = (SELECT valuationmode FROM valuation WHERE collaboration = @collaboration)

			--Check values
			--SELECT @varianceperiod AS [@varianceperiod],  @Ymax AS [@Ymax],  @valtype AS [@valtype],  @valstatus AS [@valstatus],  @varcode AS [@varcode],  @varseq AS [@varseq],  @description AS [@description],  @valmode AS [@valmode]

			--------------
			-- Set Valtime
			--------------
			SET @valtime = (SELECT valuationtime FROM valuation WHERE collaboration = @collaboration)

			------------------------
			-- Get valuation details
			------------------------	
			EXEC cspCrystalReports_ValuationsDetails 
				 -- Input:
							@collaboration,	
							@valmode,		
							@valtype,		
							@valstatus,		
							@varianceperiod,
							@interfaceid,	
				 -- Output:
							@Vr	OUTPUT,				
							@Dv OUTPUT,				
							@Dr OUTPUT,				
							@Vv OUTPUT,				
							@valtimev OUTPUT	
			SET @valtime = (SELECT valuationtime FROM valuation WHERE collaboration = @collaboration)
			----Check values
			--SELECT  @Vr AS [Vr], @Dr AS [Dr], @Vv AS [Vv], @Dv AS [Dv], @valtime AS [MaxDrValTime], @valtimev AS [MaxDvValTime]

			DECLARE	@Yr	DATETIME	
			SET @Yr = convert(datetime,cast(year(@Dr) as varchar(4))+'-01-01',120)		

			---------------------------
			-- Define the results table
			---------------------------
			CREATE TABLE #T01(
								valuation			VARCHAR(32) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
								ValuationDate		DATETIME NULL,
								RealisedPnLGroup	DECIMAL(24,6) NULL,
								RealisedPnLPOS		DECIMAL(24,6) NULL,	-- will be UPDATEd from own tab.
								RealisedPnLMIL		DECIMAL(24,6) NULL,	-- will be UPDATEd from own tab.
								RealisedPnLPRA		DECIMAL(24,6) NULL,	-- will be UPDATEd from own tab.
								ValuationTime		DATETIME NULL
							 )

			-------------------
			-- Whole Group Data
			-------------------
			INSERT INTO #T01 (valuation,RealisedPnLGroup,ValuationDate,ValuationTime)	
			SELECT	vah.valuation AS [valuation],
					SUM(vah.cstrealisedvalue)/1000000 AS [RealisedPnLGroup],
					dh.valuationdate AS [ValuationDate],
					vah.valuationtime AS [valuationtime]
			FROM	cvwEoDDateHistory dh
				  LEFT OUTER JOIN cvwEoDValuationAggregationHistory vah
						ON    vah.valuationdate = dh.valuationdate
							  AND vah.valuationmode = @valmode
							  AND vah.valuationdate >= @Yr
							  AND vah.valuationdate <= @Dr
							  AND vah.cstdeliveryyear >= CAST(YEAR(@Yr) AS VARCHAR(4))
							  AND vah.cstdeliveryyear <= CAST(YEAR(@Yr) + @YMAX AS VARCHAR(4))
							  AND vah.producttype IN ('Power', 'Power Capacity')
			WHERE dh.valuationdate >= @Yr
				  AND dh.valuationdate < DATEADD(year, 1, @Yr)
			GROUP BY dh.valuationdate,vah.valuationtime, vah.valuation
			ORDER BY dh.valuationdate
			
			-----------
			-- POS Data
			-----------
			/*
			CREATE TABLE #T02(
								valuation			VARCHAR(32) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
								RealisedPnLPOS		DECIMAL(24,6) NULL,	-- will be UPDATEd from own tab.
								ValuationDate		DATETIME NULL,
								ValuationTime		DATETIME NULL
							 )		
			*/				 
			SELECT	vah.valuation AS [valuation],
					SUM(vah.cstrealisedvalue)/1000000 AS [RealisedPnLPOS],
					dh.valuationdate AS [ValuationDate],
					vah.valuationtime AS [valuationtime]
			INTO #T02
			FROM	cvwEoDDateHistory dh
				  LEFT OUTER JOIN cvwEoDValuationAggregationHistory vah
						ON    vah.valuationdate = dh.valuationdate
							  AND vah.valuationmode = @valmode
							  AND vah.valuationdate >= @Yr
							  AND vah.valuationdate <= @Dr
							  AND vah.cstdeliveryyear >= CAST(YEAR(@Yr) AS VARCHAR(4))
							  AND vah.cstdeliveryyear <= CAST(YEAR(@Yr) + @YMAX AS VARCHAR(4))
							  AND vah.producttype IN ('Power', 'Power Capacity')
							  AND vah.cstcompetencycentre = 'POS'
			WHERE dh.valuationdate >= @Yr
				  AND dh.valuationdate < DATEADD(year, 1, @Yr)
			GROUP BY dh.valuationdate,vah.valuationtime, vah.valuation
			ORDER BY dh.valuationdate
						
		
    		-----------
			-- MIL Data
			-----------
			/*
			CREATE TABLE #T03(
					valuation			VARCHAR(32) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
					RealisedPnLMIL		DECIMAL(24,6) NULL,	-- will be UPDATEd from own tab.
					ValuationDate		DATETIME NULL,
					ValuationTime		DATETIME NULL
			 )*/

			SELECT	vah.valuation AS [valuation],
					SUM(vah.cstrealisedvalue)/1000000 AS [RealisedPnLMIL],
					dh.valuationdate AS [ValuationDate],
					vah.valuationtime AS [valuationtime]
			INTO #T03
			FROM	cvwEoDDateHistory dh
				  LEFT OUTER JOIN cvwEoDValuationAggregationHistory vah
						ON    vah.valuationdate = dh.valuationdate
							  AND vah.valuationmode = @valmode
							  AND vah.valuationdate >= @Yr
							  AND vah.valuationdate <= @Dr
							  AND vah.cstdeliveryyear >= CAST(YEAR(@Yr) AS VARCHAR(4))
							  AND vah.cstdeliveryyear <= CAST(YEAR(@Yr) + @YMAX AS VARCHAR(4))
							  AND vah.producttype IN ('Power', 'Power Capacity')
							  AND vah.cstcompetencycentre = 'MIL'
			WHERE dh.valuationdate >= @Yr
				  AND dh.valuationdate < DATEADD(year, 1, @Yr)
			GROUP BY dh.valuationdate,vah.valuationtime, vah.valuation
			ORDER BY dh.valuationdate


			-----------
			-- PRA Data
			-----------
			/*
			CREATE TABLE #T04 (
					valuation			VARCHAR(32) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
					RealisedPnLPRA		DECIMAL(24,6) NULL,	-- will be UPDATEd from own tab.
					ValuationDate		DATETIME NULL,
					ValuationTime		DATETIME NULL
			 )	
			 */	
			SELECT	vah.valuation AS [valuation],
			[dbo].[cfnCrystalReports_RiskReport_Value] (dh.valuationdate, @Dr, SUM(vah.cstrealisedvalue)/1000000) AS [RealisedPnLPRA], --mantis 1305
					--SUM(vah.cstrealisedvalue)/1000000 AS [RealisedPnLPRA],
					dh.valuationdate AS [ValuationDate],
					vah.valuationtime AS [valuationtime]
			INTO #T04
			FROM	cvwEoDDateHistory dh
				  LEFT OUTER JOIN cvwEoDValuationAggregationHistory vah
						ON    vah.valuationdate = dh.valuationdate
							  AND vah.valuationmode = @valmode
							  AND vah.valuationdate >= @Yr
							  AND vah.valuationdate <= @Dr
							  AND vah.cstdeliveryyear >= CAST(YEAR(@Yr) AS VARCHAR(4))
							  AND vah.cstdeliveryyear <= CAST(YEAR(@Yr) + @YMAX AS VARCHAR(4))
							  AND vah.producttype IN ('Power', 'Power Capacity')
							  AND vah.cstcompetencycentre = 'PRA'
			WHERE dh.valuationdate >= @Yr
				  AND dh.valuationdate < DATEADD(year, 1, @Yr)
			GROUP BY dh.valuationdate,vah.valuationtime, vah.valuation
			ORDER BY dh.valuationdate



			---------------------------------------------------------------------------------------------------------
			-- Join competency centres data into #T01 business group table using valuation id and exact valuationtime
			---------------------------------------------------------------------------------------------------------
			UPDATE #T01	SET	#T01.RealisedPnLPOS = #T02.RealisedPnLPOS,
							#T01.RealisedPnLMIL = #T03.RealisedPnLMIL,
							#T01.RealisedPnLPRA = #T04.RealisedPnLPRA
			FROM #T01
			LEFT JOIN	#T02 ON (( #T02.valuation = #T01.valuation) AND (#T02.valuationtime =  #T01.valuationtime)) 
			LEFT JOIN	#T03 ON (( #T03.valuation = #T01.valuation) AND (#T03.valuationtime =  #T01.valuationtime)) 
			LEFT JOIN	#T04 ON (( #T04.valuation = #T01.valuation) AND (#T04.valuationtime =  #T01.valuationtime)) 

			---------
			-- Output
			---------
			SELECT 
				valuation,
				CONVERT(VARCHAR, ValuationDate,4) AS [X_AxisLabels],
				RealisedPnLGroup,
				RealisedPnLPOS,	
				RealisedPnLMIL,	
				RealisedPnLPRA,
				ValuationTime
			
			 FROM #T01 ORDER BY ValuationDate asc;




			DROP TABLE #T01
			DROP TABLE #T02
			DROP TABLE #T03
			DROP TABLE #T04



	END TRY	
	BEGIN CATCH
			GOTO proc_error;
	END CATCH

GOTO proc_exit;
	
proc_error:
		    -------------------------------------------------------
			-- Log error into cspUpdateInterfaceAudit as ERROR type
			-------------------------------------------------------
			DECLARE @ErrorMessage varchar(255)
			DECLARE @ErrorLine Int
			SET @ErrorMessage = ERROR_MESSAGE()
			SET @ErrorLine = ERROR_LINE()
			EXEC cspUpdateInterfaceAudit 'cspCrystalReports_HoM02_G01', 'RISK REPORT', @ErrorLine, 'cspCrystalReports_HoM02_G01', 'ERROR', @ErrorMessage

proc_exit:
	

END



-- version: 361 module: allegro-collection date: 2013-03-20 14:23:04 
-- applied to:  HEAD 

-- main query which creates the graphical report:
SELECT DATENAME(yyyy, creationdate)+'-'+CAST(DATEPART(month, creationdate) AS VARCHAR(2)),
count(*) as occurrences, creationname, ErrorText 
FROM cvwpowerschedulingaudit
WHERE cVWPowerSchedulingAudit.CompetencyCentre = 'POS'
and CreationName='Int_4a'
--and CreationName='Int_5a'
and ErrorText='MessageVersion is less than or equal to previous received version.'
group by creationname, ErrorText, DATENAME(yyyy, creationdate)+'-'+CAST(DATEPART(month, creationdate) AS VARCHAR(2))
--having (min (status)) <> 'COMPLETED' and ErrorText is not null
order by  DATENAME(yyyy, creationdate)+'-'+CAST(DATEPART(month, creationdate) AS VARCHAR(2));


select * from cstinterfaceaudit a 
where 
--a.interfaceid='Int_4a' and
a.event like '%received%'
order by a.creationdate desc;


select * from cstinterfaceaudit a
order by a.creationdate desc;


SELECT distinct AllegroTradeId, creationname, creationdate, ErrorText, min (status)
FROM cvwpowerschedulingaudit
WHERE cVWPowerSchedulingAudit.CompetencyCentre = 'POS'
and AllegroTradeId not in (
      select distinct trade from trade where tradestatus = 'void'
)
AND cVWPowerSchedulingAudit.MessageId
IN (
    select distinct messageid from cvwpowerschedulingaudit
        where creationdate >= CAST(CONVERT(CHAR(11),GETDATE(),113) AS datetime)
        OR revisiondate >= CAST(CONVERT(CHAR(11),GETDATE(),113) AS datetime)
)
group by AllegroTradeId, creationname, ErrorText,creationdate
having (min (status)) <> 'COMPLETED' and ErrorText is not null
order by creationdate desc


-- version: 362 module: allegro-collection date: 2013-03-21 14:22:47 
-- applied to:  HEAD 

-- in AllegroUAT
select * from valuation where valuationtime='2013-03-20 15:00';
select * from valuationdetail where valuation=103654;

select * from valuation where valuationtime='2013-03-20 16:00';
select * from valuationdetail where valuation=103655;


-- version: 363 module: allegro-collection date: 2013-03-22 11:59:33 
-- applied to:  HEAD 

select top 100 * from powerquantity;

select top 100 * from cvwhourpowerquantitybyrow;

select * from valuationdetail where (block is not null) and (timeunit like '%HOUR%');
select * from valuationperiod where (block is not null) and (timeunit like '%HOUR%');
select * from valuationsegment where (block is not null) and (timeunit like '%HOUR%');

select * from powerquantity where (block is not null) and (timeunit like '%HOUR%');
select * from powerposition where (block is not null) and (timeunit like '%HOUR%');
select * from position where (block is not null) and (timeunit like '%HOUR%');

select * from trade where block is not null) and (timeunit like '%HOUR%');


-- version: 364 module: allegro-collection date: 2013-03-26 17:15:24 
-- applied to:  HEAD 

select * from valuation where valuationtime>=GETDATE();
select * from valuationdetail vd where vd.valuation=103658;
select fd.* from valuationdetail vd, findetail fd where vd.valuation=103658 and fd.valuationdetail=vd.valuationdetail;
select fd.trade from valuationdetail vd, findetail fd where vd.valuation=103658 and fd.valuationdetail=vd.valuationdetail;
select * from trade t where t.trade in (196586, 196587, 196588)
update trade set tradestatus='BO Validated' where trade=196587;


-- version: 365 module: allegro-collection date: 2013-03-27 16:34:19 
-- applied to:  HEAD 

-- verifying how allegro populates the quantity fields for BUY and SELL in a valuation

--UAT
--BUY
select * from valuation where valuation=103664;
select * from valuationdetail where valuation=103664;

--SELL
select * from valuation where valuation=103665;
select * from valuationdetail where valuation=103665;


-- PROD
select * from valuation where valuationtime>=GETDATE()-1;
-- BUY
select top 100 * from valuationdetail where valuation=103904 and trade=205137;
-- SELL
select top 100 * from valuationdetail where valuation=103904 and trade=205138;


-- version: 367 module: allegro-collection date: 2013-04-04 14:34:49 
-- applied to:  HEAD 

select * from pricevalue where delivdate>='2013-04-01' and delivdate<'2013-05-01'
and priceindex='Power FR Hour Forward' and pricedate='2013-03-31'
order by delivdate asc;

select distinct priceindex from pricevalue where pricedate='2013-03-31' order by priceindex asc;


select AVG(price) from pricevalue where delivdate>='2013-04-01' and delivdate<'2013-05-01'
and priceindex='Power FR Hour Forward' and pricedate='2013-03-31';

select avg(price) from pricevalue where delivdate>='2013-04-01' and delivdate<'2013-05-01'
and priceindex='Power IT Peak Day Forward' and pricedate='2013-03-31';

select avg(price) from pricevalue where delivdate>='2013-04-01' and delivdate<'2013-05-01'
and priceindex='Power IT Offpeak Day Forward' and pricedate='2013-03-31';

select * from valuation order by revisiondate desc;

-- test line


-- version: 368 module: allegro-collection date: 2013-04-09 18:14:26 
-- applied to:  HEAD 



select * from currexchrate  where basecurrency='GBP';

select * from pricevalue where pricedate=delivdate and pricedate='2013-04-01' and priceindex='Gas NBP Settle';

select trade, * from valuationdetail where valuation=103682;
select trade, * from valuationdetail where valuation=103683;
select trade, * from valuationdetail where valuation=103684;


select * from viewcriteria where viewname='Process Manager Position Mode' and surrogate=1151;

update viewcri


-- version: 370 module: allegro-collection date: 2013-04-11 11:49:24 
-- applied to:  HEAD 

select currency from trade where trade=196671;

--update trade set currency='EUR' where trade=196671;


-- CHF e CHF
select * from valuationdetail where valuation=103688;

-- EUR e EUR
select * from valuationdetail where valuation=103689;


delete from cstvaluationaggregation where valuation=103684;
delete from valuationdetail where valuation=103684;
delete from valuation where valuation=103684;



-- version: 371 module: allegro-collection date: 2013-04-12 11:54:30 
-- applied to:  HEAD 

select * from valuation where valuationtime='2012-12-30 23:00';
select max(t.tradedate) from valuationdetail vd, trade t where vd.valuation=103621 and vd.trade=t.trade;
-- 28.12.2012 is the max tradedate, so in fact the view select criteria
-- in a valuation tradedate<valuationtime is redundant.


-- version: 372 module: allegro-collection date: 2013-04-12 11:56:30 
-- applied to:  HEAD 

select top 100 * from fintransact; -- � un po' il corrispondente della position penso
select top 100 * from findetail;
-- it is close to valuationdetail, if one scrolls to the right. it has information on account and credit and debit columns.


-- version: 375 module: allegro-collection date: 2013-04-15 16:25:56 
-- applied to:  HEAD 

-- forwards
select * from pricevalue where priceindex='Gas NBP Month Forward' and pricedate='2013-04-15' order by delivdate asc;
select * from pricevalue where priceindex='Coal API2ICE Month Forward' and pricedate='2013-04-15' order by delivdate asc;
select * from pricevalue where priceindex='Coal API2CME Month Forward' and pricedate='2013-04-15' order by delivdate asc;

-- settlement
select * from pricevalue where priceindex='Gas NBP Settle' and pricedate='2013-04-15' order by delivdate asc;
--delete from pricevalue where surrogate=117626409;

select * from pricevalue where priceindex='Coal API2ICE Settle' and pricedate='2013-04-15' order by delivdate asc;
select * from pricevalue where priceindex='Coal API2CME Settle' and pricedate='2013-04-15' order by delivdate asc;

select * from currexchrate cr where cr.basecurrency='GBP' and cr.pricedate='2013-04-15'; 
select * from currexchrate cr where cr.basecurrency='USD' and cr.pricedate='2013-04-15'; 


-- version: 378 module: allegro-collection date: 2013-04-18 14:48:36 
-- applied to:  HEAD 

select * from cstvaluationarchive order by valuationtime desc;
-- settlement are never archived, only positions and VaR

sp_spaceused 'valuationdetail';

-- growing tendency for pricevalue table
select count(*) from pricevalue where pricedate>='2013-04-17';


-- version: 379 module: allegro-collection date: 2013-04-19 08:13:55 
-- applied to:  HEAD 

-- archive database: RBSQL03, username: AllegroMAM password:mam4Allegro

-- in allegro prod database
select * from cstvaluationarchive where valuationmode='VaR' 
and archivestatus='ARCHIVED'
order by valuationtime asc;

-- in archive database
select count(*) from valuationdetail where valuation=100685;
select count(*) from valuationdetail where valuation=103840;



-- version: 393 module: allegro-collection date: 2013-04-23 10:24:31 
-- applied to:  HEAD 

/*
counting the number of prices loaded on a particular date. 
The growing tendency for pricevalue table is about 250�000 rows a day. Each row uses about 440 bytes of space, 
which translates in a daily growth of 110 MB per day. The current size of the pricevalue table is 
133 million rows with 30GB size. 
*/
select count(*) from pricevalue where 
pricedate>='2013-04-22' and pricedate<'2013-04-23';

select count(*) from pricevalue where 
creationdate>='2013-04-22' and creationdate<'2013-04-23';

select count(*) from pricevalue where 
creationdate>='2013-04-22';

exec sp_spaceused 'pricevalue';




-- version: 407 module: allegro-collection date: 2013-05-13 09:54:56 
-- applied to:  HEAD 

select priceindex, count(*), sum(price) from pricevalue where pricedate='2013-04-30' group by priceindex order by priceindex asc;


-- version: 408 module: allegro-collection date: 2013-05-13 16:04:15 
-- applied to:  HEAD 

select count(*) from gridqueue;


-- version: 409 module: allegro-collection date: 2013-05-14 10:11:47 
-- applied to:  HEAD 

select count(*) from gridqueue;

select * from valuation where valuationtime='2013-04-30 23:00';
select distinct marketarea from position where marketarea like '%IT%';

-- position
SELECT p.counterparty, p.positiontype, p.marketarea, p.product, SUM(quantity) AS qty, SUM(pricequantity) AS pqty, SUM(value) AS cv, SUM(marketvalue) AS mv
FROM valuationdetail vd, position p
WHERE vd.valuation = 103978
AND vd.position = p.position
AND p.marketarea not in ('IT', 'CH/IT', 'IT/CH')
GROUP BY p.counterparty, p.positiontype, p.marketarea, p.product 
ORDER BY p.counterparty ASC,p.positiontype ASC, p.marketarea ASC, p.product ASC;


-- settlement
SELECT p.counterparty, p.positiontype, p.marketarea, p.product, SUM(quantity) AS qty, SUM(pricequantity) AS pqty, SUM(value) AS cv, SUM(marketvalue) AS mv
FROM valuationdetail vd, position p
WHERE vd.valuation = 103847
AND vd.position = p.position
AND p.marketarea not in ('IT', 'CH/IT', 'IT/CH')
GROUP BY p.counterparty, p.positiontype, p.marketarea, p.product 
ORDER BY p.counterparty ASC,p.positiontype ASC, p.marketarea ASC, p.product ASC;


-- version: 410 module: allegro-collection date: 2013-05-15 11:37:13 
-- applied to:  HEAD 

select * from contact c, counterparty cp where c.counterparty=cp.counterparty;

select * from address a, counterparty cp where a.counterparty=cp.counterparty;


-- version: 411 module: allegro-collection date: 2013-05-15 15:07:59 
-- applied to:  HEAD 

select * from counterparty where cstmilexport=1 and cstposexport=1 order by counterparty asc;


-- version: 413 module: allegro-collection date: 2013-05-21 09:39:00 
-- applied to:  HEAD 

select * from valuation where valuationtime='2013-05-20 23:00';

select count(*) from valuationdetail where valuation=104033;
select count(*) from valuationdetail where valuation=104033 and validation is not null;

select count(*) from valuationdetail where valuation=104034;
select count(*) from valuationdetail where valuation=104034 and validation is not null;

select count(*) from valuationdetail where valuation=104035;
select count(*) from valuationdetail where valuation=104035 and validation is not null;

-------------------

select * from valuation where valuationtime='2013-05-19 23:00';

select count(*) from valuationdetail where valuation=104030;
select count(*) from valuationdetail where valuation=104030 and validation is not null;

select count(*) from valuationdetail where valuation=104031;
select count(*) from valuationdetail where valuation=104031 and validation is not null;

select count(*) from valuationdetail where valuation=104032;
select count(*) from valuationdetail where valuation=104032 and validation is not null;

--------------------------------

select * from valuation where valuationtime='2013-05-16 23:00';

select count(*) from valuationdetail where valuation=104021;
select count(*) from valuationdetail where valuation=104021 and validation is not null;

select count(*) from valuationdetail where valuation=104022;
select count(*) from valuationdetail where valuation=104022 and validation is not null;

select count(*) from valuationdetail where valuation=104023;
select count(*) from valuationdetail where valuation=104023 and validation is not null;


-- version: 414 module: allegro-collection date: 2013-05-22 08:22:30 
-- applied to:  HEAD 

select count(*) from valuationdetail where valuation=104038;
delete from valuationdetail where valuation=104038;
delete from valuation where valuation=104038;


-- version: 415 module: allegro-collection date: 2013-05-22 11:22:31 
-- applied to:  HEAD 

select top 100 vd.cstrealisedvalue, vd.cstunrealisedvalue from valuationdetail vd
 where (vd.cstrealisedvalue<>0) or (vd.cstunrealisedvalue<>0);
 

select * from valuation where valuationtime='2013-04-22 23:00'; 
 
select count(*) from valuationdetail vd
 where ((vd.cstrealisedvalue<>0) or (vd.cstunrealisedvalue<>0)) and vd.valuation=103727;

select count(*) from valuationdetail vd
 where vd.valuation=103727; 


-- version: 416 module: allegro-collection date: 2013-05-22 17:05:39 
-- applied to:  HEAD 

--PROD

select MAX(t.tradedate) from trade t, position p where p.marketarea='NP' and t.tradedate<'2012-02-01';

select count(*), sum(price), priceindex from pricevalue 
where priceindex like 'Power NP%' and pricedate='2012-01-31'
group by priceindex;

select count(*), sum(price), priceindex from pricevalue 
where priceindex like 'Power NP%' and pricedate='2012-02-29'
group by priceindex;

select count(*), sum(price), priceindex from pricevalue 
where priceindex like 'Power NP%' and pricedate='2012-03-30'
group by priceindex;

select count(*), sum(price), priceindex from pricevalue 
where priceindex like 'Power NP%' and pricedate='2012-03-31'
group by priceindex;

select count(*), sum(price), priceindex from pricevalue 
where priceindex like 'Power NP%' and pricedate='2012-04-30'
group by priceindex;

select count(*), sum(price), priceindex from pricevalue 
where priceindex like 'Power NP%' and pricedate='2012-05-31'
group by priceindex;


select count(*), sum(price), priceindex from pricevalue 
where priceindex like 'Power NP%' and pricedate='2012-06-29'
group by priceindex;

select count(*), sum(price), priceindex from pricevalue 
where priceindex like 'Power NP%' and pricedate='2012-06-30'
group by priceindex;

select count(*), sum(price), priceindex from pricevalue 
where priceindex like 'Power NP%' and pricedate='2012-07-31'
group by priceindex;

select count(*), sum(price), priceindex from pricevalue 
where priceindex like 'Power NP%' and pricedate='2012-08-31'
group by priceindex;

select count(*), sum(price), priceindex from pricevalue 
where priceindex like 'Power NP%' and pricedate='2012-09-30'
group by priceindex;

select count(*), sum(price), priceindex from pricevalue 
where priceindex like 'Power NP%' and pricedate='2012-10-31'
group by priceindex;

select count(*), sum(price), priceindex from pricevalue 
where priceindex like 'Power NP%' and pricedate='2012-11-30'
group by priceindex;

select count(*), sum(price), priceindex from pricevalue 
where priceindex like 'Power NP%' and pricedate='2012-12-31'
group by priceindex;


select count(*), sum(price), priceindex from pricevalue 
where priceindex like 'Power NP%' and pricedate='2013-01-31'
group by priceindex;

select count(*), sum(price), priceindex from pricevalue 
where priceindex like 'Power NP%' and pricedate='2013-02-28'
group by priceindex;

select count(*), sum(price), priceindex from pricevalue 
where priceindex like 'Power NP%' and pricedate='2013-03-27'
group by priceindex;

select count(*), sum(price), priceindex from pricevalue 
where priceindex like 'Power NP%' and pricedate='2013-03-28'
group by priceindex;

select count(*), sum(price), priceindex from pricevalue 
where priceindex like 'Power NP%' and pricedate='2013-03-29'
group by priceindex;

select count(*), sum(price), priceindex from pricevalue 
where priceindex like 'Power NP%' and pricedate='2013-03-30'
group by priceindex;


select count(*), sum(price), priceindex from pricevalue 
where priceindex like 'Power NP%' and pricedate='2013-03-31'
group by priceindex;

select count(*), sum(price), priceindex from pricevalue 
where priceindex like 'Power NP%' and pricedate='2013-04-30'
group by priceindex;



-- version: 417 module: allegro-collection date: 2013-05-23 16:44:14 
-- applied to:  HEAD 

ALTER PROCEDURE [dbo].[cspCreateContact]
@counterparty varchar(32),
@name varchar(64),
@cstprimarycontact bit,
@status varchar(8)
AS
BEGIN
 SET NOCOUNT ON;
 
 DECLARE @num int;
 
 select @num=count(*) from counterparty where counterparty=@counterparty;
 IF (@num=0)
	BEGIN
	 PRINT @counterparty+' is not defined!';
	END;
 ELSE
	BEGIN
	 BEGIN TRY
	    INSERT INTO dbo.contact (counterparty, name, cstprimarycontact, status, creationname, creationdate) 
	    VALUES(@counterparty, @name, @cstprimarycontact, @status, 'MAM_2687', GETDATE());
	 END TRY
	 BEGIN CATCH
	    PRINT 'Could not load contact '+@name+' of '+@counterparty+' due to error '+CAST(ERROR_STATE() as varchar(8));
	 END CATCH   	
	END;	

END;

EXEC cspCreateContact  'AXPO_TR_CH' , 'Adam Bromley' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'MSCG' , 'Adam King' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'VITOL' , 'Adam Pollock' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'EXERGIA' , 'Agostino Arsa' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'DUF_IT' , 'Agostino Calcagno' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'A2A_IT' , 'Alberto Ravasi' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'RWE' , 'Aldo Della Valle' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'AXPO_IT' , 'Alessandra Pezzolo' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'EGL_IT' , 'Alessandra Pezzolo' ,FALSE, 'INACTIVE'
EXEC cspCreateContact  'ARGOS' , 'Alessandro Corain' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'ENEL_TRADING' , 'Alessandro Delle Fratte' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'ENEL_TRADING' , 'Alessandro Figus' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'ENOI' , 'Alessandro Plasmati' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'APT' , 'Alessandro Toso' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'EDISONTRADING' , 'Alessandro Zitani' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'EGL_IT' , 'Alfredo Fiore' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'EON_EN_TR_IT' , 'Alfredo Fiore' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'EDISONTRADING' , 'Andi Koka' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'HERA' , 'Andrea Bianchi' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'DUF_IT' , 'Andrea Saronni' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'AXPO_IT' , 'Angela Martella' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'EGL_IT' , 'Angela Martella' ,FALSE, 'INACTIVE'
EXEC cspCreateContact  'GDF_S_E_I_IT' , 'Angelo Andretta' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'GDF_S_E_I_IT' , 'Antonio Rapone' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'BURGO' , 'Antonio Rubino' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'ASSOUTILITY' , 'Assoutility Trader KE' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'HERA' , 'Beatrice Daghia' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'MSCG' , 'Ben Ansellem' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'CEMAG' , 'Bernadett Gyoerfi' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'Sorg_Tr' , 'Carolynn Tschuor' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'ENOI' , 'Chiara Quaglini' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'EGL_IT' , 'Chiara Saba' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'EON' , 'Christian Heringer' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'SHELL' , 'Christoph Jenckel' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'EDISONTRADING' , 'Ciprea Scolari' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'EDISON' , 'Claudia D Este' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'ENOI' , 'Claudio Cecchetto' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'WLDENG' , 'Claudio Giannotti' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'EXO_EN_TR_IT' , 'Corrado Mereu' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'TIRRENO' , 'Corrado Micozzi' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'CEMAG' , 'Dagmar Wallner' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'A2A_IT' , 'Daniele Galli' ,FALSE, 'INACTIVE'
EXEC cspCreateContact  'Sorg_Tr' , 'Daniele Galli' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'VITOL' , 'Daniele Gattamorta' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'ENEL_TRADING' , 'Daniele Olivi' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'ENEL_TRADING' , 'Dario Di Masi' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'Gazprom' , 'Dave Hutchison' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'GASPLUS' , 'Davide Cornaggia' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'YOUTRADE' , 'Davide Villa' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'A2A_IT' , 'Delphine Pihourquet' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'RWE' , 'Didier Magne' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'Gazprom' , 'Duncan Macintyre' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'ENIA' , 'Elena di Blasio' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'A2A_IT' , 'Elisabetta Napoli' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'ENEL_TRADING' , 'Emanuele Colacchi' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'GDF_S_E_I_IT' , 'Emanuele Scrocco' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'AXPO_TR_CH' , 'Emiliano Boffi' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'ENEL_TRADING' , 'Emilio Marsilii' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'ISA' , 'Energy Trader1' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'SHELL' , 'Erik Van Ommeren' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'ENEL_TRADING' , 'Fabio Bonetti' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'ENEL_TRADING' , 'Fabio Cedronio' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'ACEA_E_H_IT' , 'Fabrizio Infortuna' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'VNG' , 'Falko Klymant' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'EUROPE_EN' , 'Federica Pellicciari' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'IDEX' , 'Federica Pellicciari' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'ENEL_TRADING' , 'Federico Celani Tomassoni' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'BLUENERGY' , 'Filippo Boraso' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'GASPLUS' , 'Fiorenza Fiorio' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'Sorg_Tr' , 'Francesca Sigillito' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'APT' , 'Francesco Bertusi' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'AXPO_IT' , 'Francesco Isidori' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'EGL_IT' , 'Francesco Isidori' ,FALSE, 'INACTIVE'
EXEC cspCreateContact  'HERA' , 'Francesco Rotondo' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'ENIPOWER' , 'Francesco Sommaruga' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'EDF' , 'Francisco Cubria' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'EON' , 'Fred Dekker' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'ENEL_TRADING' , 'Frederico Celani Tomassaoni' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'ENEL_TRADING' , 'Frederico Tomassaoni' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'CEMAG' , 'Georg Giokas' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'SHELL' , 'George Demain' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'GASTERRA' , 'Gerwin Schaaphok' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'EDF' , 'Giacomo Schiro' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'A2A_IT' , 'Giandomenico Serra' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'EXERGIA' , 'Gianni Marziali' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'ENEL_TRADING' , 'Gianpaolo Pellecchia' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'CEA' , 'Giovanni Giaroli' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'AXPO_IT' , 'Giovanni Uneddu' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'EGL_IT' , 'Giovanni Uneddu' ,FALSE, 'INACTIVE'
EXEC cspCreateContact  'EGL_IT' , 'Giuseppe Anglana' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'Sonatrach' , 'Giuseppe Bellati' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'ALPIQ' , 'Giuseppe Imparato' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'EON' , 'Giuseppe Suppa' ,FALSE, 'INACTIVE'
EXEC cspCreateContact  'EON_EN_TR_IT' , 'Giuseppe Suppa' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'KELAG' , 'Harald Petutschnig' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'EON' , 'Holger Perrevort' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'ECONGAS' , 'Ihsan Goerec' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'AXPO_AG' , 'Irina Radzikhovskaya' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'AXPO_IT' , 'Ivanhoe Romin' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'EGL_IT' , 'Ivanhoe Romin' ,FALSE, 'INACTIVE'
EXEC cspCreateContact  'MSCG' , 'James Pilkington' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'SHELL' , 'Jenn Nguyen' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'RWE' , 'Joana Esteves' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'Gunvor' , 'Johannes Themel' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'EDF' , 'John Ogilvie' ,FALSE, 'INACTIVE'
EXEC cspCreateContact  'ENEL_TRADING' , 'John Ogilvie' ,FALSE, 'INACTIVE'
EXEC cspCreateContact  'EON' , 'John Ogilvie' ,FALSE, 'INACTIVE'
EXEC cspCreateContact  'EZPADA_CZ' , 'John Ogilvie' ,FALSE, 'INACTIVE'
EXEC cspCreateContact  'Sorg_Tr' , 'John Ogilvie' ,FALSE, 'INACTIVE'
EXEC cspCreateContact  'AXPO_IT' , 'John Ogilvie' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'EGL_IT' , 'John Ogilvie' ,FALSE, 'INACTIVE'
EXEC cspCreateContact  'VITOL' , 'Jorg Steyskal' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'EON' , 'Kai Reindl' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'EZPADA_CZ' , 'Katerina Labanicova' ,FALSE, 'INACTIVE'
EXEC cspCreateContact  'AXPO_IT' , 'Katerina Labanicova' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'VNG' , 'Kati Schoene' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'EGL_IT' , 'Laurent Weinberger' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'VITOL' , 'Leah Cook' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'SHELL' , 'Leo Markou' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'Gunvor' , 'Livio Litterio' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'ENEL_TRADING' , 'Lorenzo Blanco' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'A2A_IT' , 'Luca Quivelli' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'YOUTRADE' , 'Luca Rizzitelli' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'BURGO' , 'Luigi Piombi' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'EON' , 'Mahdi Shahrokhi' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'STATOIL' , 'Manpreet Nahal' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'AXPO_IT' , 'Manuel Previato' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'EGL_IT' , 'Manuel Previato' ,FALSE, 'INACTIVE'
EXEC cspCreateContact  'EZPADA_CZ' , 'Marcela Kopecka' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'EZPADA_CZ' , 'Marcela Kubinova' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'Sorg_Tr' , 'Marco Bussolino' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'EGL_IT' , 'Marco Bussolino' ,FALSE, 'INACTIVE'
EXEC cspCreateContact  'EDF' , 'Marco Centofanti' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'EDISONTRADING' , 'Marco Sacco' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'ENOI' , 'Marco Sacerdoti' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'BURGO' , 'Marco Solatitetto' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'ELECTRADE' , 'Marco Tumolo' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'EDISON' , 'Marika Savoia' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'EON' , 'Marina Caputi' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'VITOL' , 'Mark Ruffles' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'SHELL' , 'Mark Tierney' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'KELAG' , 'Martin Blackert' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'EGL_CH' , 'Martin Mischler' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'EGL_IT' , 'Martin Mischlers' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'EON' , 'Massimiliano Liberatore' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'EON_EN_TR_IT' , 'Massimiliano Liberatore' ,FALSE, 'INACTIVE'
EXEC cspCreateContact  'EDISONTRADING' , 'Massimiliano Sabato' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'TIRRENO' , 'Massimiliano Taverna' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'EDISONTRADING' , 'Massimiliano Vito Sabato' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'TIRRENO' , 'Massmilano Taverna' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'MSCG' , 'Mateusz Marczewski' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'VITOL' , 'Matt O Reilly' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'EGL_IT' , 'Matt O Reilly' ,FALSE, 'INACTIVE'
EXEC cspCreateContact  'UTILITA' , 'Matteo Alesani' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'MERCURIA' , 'Matthias Vercruysse' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'EDISON' , 'Mattia Picco' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'ROMAGAS' , 'Maurizio Argiro' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'GDF_S_E_I_IT' , 'Mauro Carretta' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'ECONGAS' , 'Nastja Vogl' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'VITOL' , 'Neil Bashford' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'MSCG' , 'Neroy Nath' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'ISA' , 'Nicola Stricchiola' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'DUF_IT' , 'Nicola Stricchiola' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'EGL_CH' , 'Nicoletta Frigeni' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'RWE' , 'Nik Leitner' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'RWE' , 'Nikolaus Leitner' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'AXPO_AG' , 'Norbert Gisler' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'SHELL' , 'Oliver Morning' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'Sorg_Tr' , 'Omar Miceli' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'SORGENIA' , 'Omar Miceli' ,FALSE, 'INACTIVE'
EXEC cspCreateContact  'MSCG' , 'Patricia Gutierrez' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'Gunvor' , 'Patrick Schirmann' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'EON' , 'Paul Morris' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'RWE' , 'Paul Warman' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'AXPO_IT' , 'Paul Williams' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'RWE' , 'Pawel Lewin' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'ECONGAS' , 'Peter Eibensteiner' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'AXPO_AG' , 'Philip Schaefer' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'EGEA' , 'Piergiorgio Carotta' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'A2A_IT' , 'Pietro Baldovin' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'A2A_IT' , 'Roberta Raho' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'ISA' , 'Rocco Zotta' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'ENOI' , 'Rocco Zotta' ,FALSE, 'INACTIVE'
EXEC cspCreateContact  'EON' , 'Roland Kuchler' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'GDF_S_E_I_IT' , 'Rossella D�Onofrio' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'SHELL' , 'Sameer Kotecha' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'EDF' , 'Samuel Hernandez' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'EDF' , 'Samuel Lopez Hernandez' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'EDISON' , 'Saverio Grifa' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'BP_GAS' , 'Sebastien Deshayes' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'STATOIL' , 'Sharon Griffiths' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'ECONGAS' , 'Simon O Brien' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'ENEL_TRADING' , 'Simone Corbo' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'AXPO_IT' , 'Simone Corbo' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'EON' , 'Stefan Querfurth' ,FALSE, 'INACTIVE'
EXEC cspCreateContact  'EON_EN_TR_IT' , 'Stefan Querfurth' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'EGEA' , 'Stefano Borgnino' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'ALPIQ' , 'Stefano Coccia' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'EDISONTRADING' , 'Stefano Jimmio Bassi' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'RE_IT' , 'Stefano Reschigg' ,FALSE, 'INACTIVE'
EXEC cspCreateContact  'HERA' , 'Stefano Verde' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'VITOL' , 'Sven Fuhrmann' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'Gazprom' , 'Tom Kenward' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'AET' , 'Trade@aet.ch' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'GDF_S_E_I_IT' , 'Trader 1' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'ENOI' , 'Ugo Iozzo' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'EON' , 'Uwe Winster' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'A2A_IT' , 'Valentina Papini' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'EDF' , 'Valerio Bosa' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'EDISONTRADING' , 'Vito Massimiliano Sabato' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'Gunvor' , 'Wilfried Staub' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'GDF_S_T_FR' , 'Yann Gillard' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'ALPIQ' , 'Yann Guez' ,FALSE, 'ACTIVE'
EXEC cspCreateContact  'SHELL' , 'Yide Dai' ,FALSE, 'ACTIVE'



-- version: 423 module: allegro-collection date: 2013-05-31 07:50:00 
-- applied to:  HEAD 

select t.* from position p, trade t where p.trade=t.trade 
and p.position in
(
210779,
210816,
212339,
210548,
211420,
210683,
210779,
210548,
211420,
210683,
212339,
210816);


-- version: 424 module: allegro-collection date: 2013-06-04 08:16:48 
-- applied to:  HEAD 

select count(*), p.block, p.product from trade t, position p 
where p.trade=t.trade and t.creationname='AllegroInterface'
and t.status<>'Void'
group by p.block, p.product order by p.product asc;


-- version: 426 module: allegro-collection date: 2013-06-06 08:48:19 
-- applied to:  HEAD 

select * from priceindex where priceindex like '%Band%';

select count(*) from pricevalue where priceindex='Power IT Band 1'; 
select * from pricevalue where priceindex='Power IT Band 1'; 

select count(*) from pricevalue where priceindex='Power IT Band 2'; 
select * from pricevalue where priceindex='Power IT Band 2'; 

select count(*) from pricevalue where priceindex='Power IT Band 3'; 
select * from pricevalue where priceindex='Power IT Band 3'; 

select count(*) from pricevalue where priceindex='Power IT Band 6-22 Offpeak'; 
select * from pricevalue where priceindex='Power IT Band 6-22 Offpeak'; 

select count(*) from pricevalue where priceindex='Power IT Band 6-22 Peak'; 
select * from pricevalue where priceindex='Power IT Band 6-22 Peak'; 

SELECT * FROM pricevalue WHERE priceindex='Power IT Band 2' and daylightsaving=1; 
SELECT * FROM pricevalue WHERE priceindex='Power IT Band 3' and daylightsaving=1; 
SELECT * FROM pricevalue WHERE priceindex='Power IT Band 6-22 Offpeak' and daylightsaving=1; 
SELECT * FROM pricevalue WHERE priceindex='Power IT Band 6-22 Peak'  and daylightsaving=1;


-- version: 427 module: allegro-collection date: 2013-06-06 15:22:19 
-- applied to:  HEAD 

select distinct priceindex from pricevalue where priceindex like 'Power IT Band%';
select count(*) from pricevalue where priceindex like 'Power IT Band%';
delete from pricevalue where priceindex like 'Power IT Band%';


-- version: 428 module: allegro-collection date: 2013-06-07 11:20:21 
-- applied to:  HEAD 

select * from valuation where creationdate>GETDATE()-1;
select * from gridqueue;

EXEC cspEoDContractValueDetail 'POS';
EXEC cspEoDContractValueDetail 'MIL';


-- version: 430 module: allegro-collection date: 2013-06-07 16:28:01 
-- applied to:  HEAD 

USE [AllegroSAT]
GO
/****** Object:  StoredProcedure [dbo].[cspEoDContractValueDetail]    Script Date: 06/07/2013 10:02:47 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

ALTER PROCEDURE [dbo].[cspEoDContractValueDetail]
AS
/******
 
  Script:		cspEoDContractValueDetail
  Script Date:		2011-08-31 18:43:09 
  Project:		Up-Trade
  Author:		JG, Logica
  Description:		Mantis 1359 Credit export contract valuation detail results

  $Id: cspEoDContractValueDetail.sql 3493 2011-09-01 08:39:13Z lancaricm $

******/
BEGIN


	---------------------------------------------------------------------
	-- Declarations
	---------------------------------------------------------------------
	DECLARE @PivotColList as VARCHAR(max)
	DECLARE @PivotQuery AS VARCHAR(max)
	DECLARE @SQL varchar(max)
	DECLARE @EoDValDate AS DATETIME
	DECLARE @EoDValTime AS DATETIME
	DECLARE @EoDVal AS VARCHAR(32)
	DECLARE @Timestamp AS VARCHAR(15)
	DECLARE @DBName as VARCHAR(32)

	------------------------------------------------------------------
	-- Initialise
	------------------------------------------------------------------
--	PRINT 'cspEoDContractValueDetail: Begin'
--	PRINT '  Valuation='+ @pValuation

	IF ( OBJECT_ID('dbo.cstEoDContractValueDetail') IS NOT NULL ) 
	   DROP TABLE dbo.cstEoDContractValueDetail

	------------------------------------------------------------------
	-- Identify yesterdays EoD Position valuation
	------------------------------------------------------------------
	SET @EoDValDate = DATEADD(day, DATEDIFF(day, 0, getdate())-1, 0)
	SET @EoDValTime = (	SELECT MAX(valuationtime)
						FROM valuation
						WHERE valuationmode = 'Position' AND
							  valuationtype = 'SUMMATION' AND
							  valuationstatus = 'COMPLETE' AND
							  valuationtime >= @EoDValDate AND
							  valuationtime < DATEADD(day, 1, @EoDValDate) AND
							  DATEPART(hour, valuationtime) >= 23 )
	SET @EoDVal = (	SELECT valuation
					FROM valuation
					WHERE valuationmode = 'Position' AND
						  valuationtype = 'SUMMATION' AND
						  valuationstatus = 'COMPLETE' AND
						  valuationtime = @EoDValTime )

	------------------------------------------------------------------
	-- Dynamically create list of pivot columns
	------------------------------------------------------------------
	SET @PivotColList = NULL

	SELECT	@PivotColList = ISNULL(@PivotColList + ',', '') + '[' + tp.timeperiod + ']'
	FROM	valuation v,
			cvwEoDMonthHistory mth,
			timeperiod tp
	WHERE	v.valuation = @EoDVal AND
			mth.monthsequence >= DATEADD(month, -1, DATEADD(year, DATEDIFF(year, 0, v.valuationtime), 0)) AND
			mth.monthsequence < DATEADD(year, 6, DATEADD(year, DATEDIFF(year, 0, v.valuationtime), 0)) AND
			tp.timeperiodclass = 'CAL' AND 
			tp.method = 'FIXED' AND 
			tp.timeunit = 'MONTH' AND 
			tp.begtime <= mth.monthsequence AND 
			tp.endtime > mth.monthsequence
			
	PRINT @PivotColList

	------------------------------------------------------------------
	-- Dynamically construct pivot table query
	------------------------------------------------------------------
	SET @PivotQuery = 'SELECT valuation,
	    cstcompetencycentre,
		positiontype,
		counterparty,
		company,
		producttype,
		currency,
		' + @PivotColList + ' 
	INTO cstEoDContractValueDetail
	FROM (SELECT v.valuation,
	         vd.cstcompetencycentre,
			 p.positiontype,
			 vd.counterparty,
			 vd.company,
			 vd.producttype,
			 vd.currency,
			 vd.cstdeliverymonth,
			 SUM(vd.value) AS value
		FROM valuation v,
			 valuationdetail vd,
			 position p
		WHERE v.valuation = ' + @EoDVal + ' /* ''100997'' */ AND
			  v.valuationmode = ''Position'' AND
			  v.valuationtype = ''SUMMATION'' AND
			  v.valuationstatus = ''COMPLETE'' AND
			  vd.valuation = v.valuation AND
			  vd.exposure = ''POSITION'' AND
			  vd.quantitytype <> ''LOSS'' AND
			  vd.counterparty <> vd.company AND
			  vd.cstdeliverydate >= dateadd(month, -1, dateadd(year, datediff(year, 0, v.valuationtime), 0)) AND
 			  vd.cstdeliverydate < dateadd(year, 6, dateadd(year, datediff(year, 0, v.valuationtime), 0)) AND
			  p.position = vd.position
		GROUP BY v.valuation,
				 vd.cstcompetencycentre,
				 p.positiontype,
				 vd.counterparty,
				 vd.company,
				 vd.producttype,
				 vd.currency,
				 vd.cstdeliverymonth) AS cdbycol
		PIVOT (SUM(value)
				FOR cstdeliverymonth
				IN (' + @PivotColList + ')
			  ) AS valuebydeliverymonth'
	  
	PRINT @PivotQuery
	
	------------------------------------------------------------------
	-- Dynamically execute pivot table query
	------------------------------------------------------------------

	EXEC(@PivotQuery)
	
	------------------------------------------------------------------
	-- Execute Procedure to export to Excel
	------------------------------------------------------------------

	SELECT @Timestamp = CONVERT(VARCHAR, @EoDValTime, 112) + '_' + REPLACE(CONVERT(VARCHAR, @EoDValTime, 108), ':', '')
	
	IF(@Timestamp != '')
		SET @SQL = 'EXEC dbo.cspExportToExcel ''cstEoDContractValueDetail'', ''EoD Contract Value Export'', ''' + @Timestamp + ''', ''order by valuation, cstcompetencycentre, positiontype, counterparty, company, producttype, currency'''
	ELSE
		SET @SQL = 'EXEC dbo.cspExportToExcel ''cstEoDContractValueDetail'', ''EoD Contract Value Export'',  @OrderBy=''order by valuation,  cstcompetencycentre, positiontype, counterparty, company, producttype, currency'''

	EXEC(@SQL)	
END


select * from valuation where creationdate>GETDATE()-1;
select count(*) from gridqueue;
select * from documentformat;

EXEC cspEoDContractValueDetail;


-- version: 431 module: allegro-module date: 2013-06-10 10:30:48 
-- applied to:  HEAD 

/*
Located at R:\CORP\DIV\MAM\Applications\Trayport\gold-mappings\scripts
*/
UPDATE trayportinstrument SET tradetype='Power Spot', tradebook='MIL Proprietary', tradeclass='MP', marketarea='FR', product='Power', holidaycalendar= 'No Holidays', tradestatus= 'New', currency= 'EUR', unit= 'MW', priceunit= 'MWh', timeunit= 'HOUR', factor= '1', timezone= 'CET', block= 'Base', controlarea= 'RTE', powerpoint= 'RTE', revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001109' and trayportconfigid=1;
UPDATE trayportinstrument SET tradetype='Power Spot', tradebook='MIL Proprietary', tradeclass='MP', marketarea='FR', product='Power', holidaycalendar= 'No Holidays', tradestatus= 'New', currency= 'EUR', unit= 'MW', priceunit= 'MWh', timeunit= 'HOUR', factor= '1', timezone= 'CET', block= 'Offpeak Std', controlarea= 'RTE', powerpoint= 'RTE', revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001110' and trayportconfigid=1;
UPDATE trayportinstrument SET tradetype='Power Spot', tradebook='MIL Proprietary', tradeclass='MP', marketarea='FR', product='Power', holidaycalendar= 'No Holidays', tradestatus= 'New', currency= 'EUR', unit= 'MW', priceunit= 'MWh', timeunit= 'HOUR', factor= '1', timezone= 'CET', block= 'Peak Std Mon-Fri', controlarea= 'RTE', powerpoint= 'RTE', revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001111' and trayportconfigid=1;
UPDATE trayportinstrument SET tradetype='Power Spot', tradebook='MIL Proprietary', tradeclass='MP', marketarea='IT', product='Power', holidaycalendar= 'No Holidays', tradestatus= 'New', currency= 'EUR', unit= 'MW', priceunit= 'MWh', timeunit= 'HOUR', factor= '1', timezone= 'CET', block= 'Base', controlarea= 'TERNA', powerpoint= 'TERNA', revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001750' and trayportconfigid=1;
UPDATE trayportinstrument SET tradetype='Power Spot', tradebook='MIL Proprietary', tradeclass='MP', marketarea='IT', product='Power', holidaycalendar= 'No Holidays', tradestatus= 'New', currency= 'EUR', unit= 'MW', priceunit= 'MWh', timeunit= 'HOUR', factor= '1', timezone= 'CET', block= 'Base', controlarea= 'TERNA', powerpoint= 'TERNA', revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001715' and trayportconfigid=1;
UPDATE trayportinstrument SET tradetype='Power Spot', tradebook='MIL Proprietary', tradeclass='MP', marketarea='IT', product='Power', holidaycalendar= 'No Holidays', tradestatus= 'New', currency= 'EUR', unit= 'MW', priceunit= 'MWh', timeunit= 'HOUR', factor= '1', timezone= 'CET', block= 'Base', controlarea= 'TERNA', powerpoint= 'TERNA', revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001151' and trayportconfigid=1;
UPDATE trayportinstrument SET tradetype='Power Spot', tradebook='MIL Proprietary', tradeclass='MP', marketarea='IT', product='Power', holidaycalendar= 'No Holidays', tradestatus= 'New', currency= 'EUR', unit= 'MW', priceunit= 'MWh', timeunit= 'HOUR', factor= '1', timezone= 'CET', block= 'Offpeak Std', controlarea= 'TERNA', powerpoint= 'TERNA', revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001152' and trayportconfigid=1;
UPDATE trayportinstrument SET tradetype='Power Spot', tradebook='MIL Proprietary', tradeclass='MP', marketarea='IT', product='Power', holidaycalendar= 'No Holidays', tradestatus= 'New', currency= 'EUR', unit= 'MW', priceunit= 'MWh', timeunit= 'HOUR', factor= '1', timezone= 'CET', block= 'Peak Std Mon-Fri', controlarea= 'TERNA', powerpoint= 'TERNA', revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001153' and trayportconfigid=1;
UPDATE trayportinstrument SET tradetype='Power Spot', tradebook='MIL Proprietary', tradeclass='MP', marketarea='IT', product='Power', holidaycalendar= 'No Holidays', tradestatus= 'New', currency= 'EUR', unit= 'MW', priceunit= 'MWh', timeunit= 'HOUR', factor= '1', timezone= 'CET', block= 'Base', controlarea= 'TERNA', powerpoint= 'TERNA', revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001157' and trayportconfigid=1;
UPDATE trayportinstrument SET tradetype='Power Spot', tradebook='MIL Proprietary', tradeclass='MP', marketarea='IT', product='Power', holidaycalendar= 'No Holidays', tradestatus= 'New', currency= 'EUR', unit= 'MW', priceunit= 'MWh', timeunit= 'HOUR', factor= '1', timezone= 'CET', block= 'Offpeak Std', controlarea= 'TERNA', powerpoint= 'TERNA', revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001158' and trayportconfigid=1;
UPDATE trayportinstrument SET tradetype='Power Spot', tradebook='MIL Proprietary', tradeclass='MP', marketarea='IT', product='Power', holidaycalendar= 'No Holidays', tradestatus= 'New', currency= 'EUR', unit= 'MW', priceunit= 'MWh', timeunit= 'HOUR', factor= '1', timezone= 'CET', block= 'Peak Std Mon-Fri', controlarea= 'TERNA', powerpoint= 'TERNA', revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001159' and trayportconfigid=1;


-- version: 432 module: allegro-collection date: 2013-06-10 10:32:14 
-- applied to:  HEAD 

/*
Located at R:\CORP\DIV\MAM\Applications\Trayport\gold-mappings\scripts
*/
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='FR',product='Power Profile',holidaycalendar='No Holidays',tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='Mon-Sun 00-06h',controlarea='RTE',powerpoint='RTE',revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001098' and trayportconfigid=0;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='FR',product='Power Profile',holidaycalendar='No Holidays',tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='Mon-Fri 16-20h',controlarea='RTE',powerpoint='RTE',revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001099' and trayportconfigid=0;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='FR',product='Power Profile',holidaycalendar='No Holidays',tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='Mon-Fri 20-24h',controlarea='RTE',powerpoint='RTE',revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001100' and trayportconfigid=0;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='FR',product='Power',holidaycalendar='No Holidays',tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='Base',controlarea='RTE',powerpoint='RTE',revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001109' and trayportconfigid=0;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='FR',product='Power',holidaycalendar='No Holidays',tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='Offpeak Std',controlarea='RTE',powerpoint='RTE',revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001110' and trayportconfigid=0;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='FR',product='Power',holidaycalendar='No Holidays',tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='DUMMY',controlarea='RTE',powerpoint='RTE',revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001111' and trayportconfigid=0;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='DE',product='Power Profile',holidaycalendar='No Holidays',tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='Mon-Sun 00-06h',controlarea='AMPRION',powerpoint='AMPRION',revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001123' and trayportconfigid=0;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='DE',product='Power Profile',holidaycalendar='No Holidays',tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='Mon-Fri 16-20h',controlarea='AMPRION',powerpoint='AMPRION',revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001124' and trayportconfigid=0;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='DE',product='Power Profile',holidaycalendar='No Holidays',tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='Mon-Sun 20-24h',controlarea='AMPRION',powerpoint='AMPRION',revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001125' and trayportconfigid=0;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='DE',product='Power',holidaycalendar='No Holidays',tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='Base',controlarea='AMPRION',powerpoint='AMPRION',revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001126' and trayportconfigid=0;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='DE',product='Power',holidaycalendar='No Holidays',tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='Offpeak Std',controlarea='AMPRION',powerpoint='AMPRION',revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001128' and trayportconfigid=0;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='DE',product='Power',holidaycalendar='No Holidays',tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='DUMMY',controlarea='AMPRION',powerpoint='AMPRION',revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001129' and trayportconfigid=0;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='DE',product='Power',holidaycalendar='No Holidays',tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='Sat-Sun 00-24h',controlarea='AMPRION',powerpoint='AMPRION',revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001131' and trayportconfigid=0;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='FR',product='Power',holidaycalendar=NULL,tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='Base',controlarea='RTE',powerpoint='RTE/AMPRION',revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001222' and trayportconfigid=0;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='FR',product='Power',holidaycalendar=NULL,tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='Offpeak Std',controlarea='RTE',powerpoint='RTE/AMPRION',revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001223' and trayportconfigid=0;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='FR',product='Power',holidaycalendar=NULL,tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='Peak Std Mon-Fri',controlarea='RTE',powerpoint='RTE/AMPRION',revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001224' and trayportconfigid=0;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='CH',product='Power Profile',holidaycalendar='No Holidays',tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='Mon-Sun 00-06h',controlarea=NULL,powerpoint=NULL,revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001193' and trayportconfigid=0;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='CH',product='Power Profile',holidaycalendar='No Holidays',tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='Mon-Sun 20-24h',controlarea=NULL,powerpoint=NULL,revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001196' and trayportconfigid=0;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='CH',product='Power',holidaycalendar='No Holidays',tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='Base',controlarea=NULL,powerpoint=NULL,revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001197' and trayportconfigid=0;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='CH',product='Power',holidaycalendar='No Holidays',tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='Offpeak Std',controlarea=NULL,powerpoint=NULL,revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001198' and trayportconfigid=0;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='CH',product='Power',holidaycalendar='No Holidays',tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='DUMMY',controlarea=NULL,powerpoint=NULL,revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001199' and trayportconfigid=0;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='DE',product='Power',holidaycalendar=NULL,tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='Base',controlarea='ENBW',powerpoint='ENBW/SG_ST',revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001549' and trayportconfigid=0;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='DE',product='Power',holidaycalendar=NULL,tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='Offpeak Std',controlarea='ENBW',powerpoint='ENBW/SG_ST',revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001569' and trayportconfigid=0;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='DE',product='Power',holidaycalendar=NULL,tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='Peak Std Mon-Fri',controlarea='ENBW',powerpoint='ENBW/SG_ST',revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001551' and trayportconfigid=0;


-- version: 437 module: allegro-collection date: 2013-06-10 16:25:23 
-- applied to:  HEAD 

select distinct priceindex from pricevalue order by priceindex asc;

SELECT DISTINCT pv.priceindex from pricevalue pv, priceindex pidx 
  WHERE (pv.priceindex=pidx.priceindex) AND (pidx.indextype='FORWARD') ORDER BY pv.priceindex ASC;


-- version: 438 module: allegro-collection date: 2013-06-10 16:27:54 
-- applied to:  HEAD 


select * from dbsysgen where dbtable='cstpricevaluearchive';
DECLARE @dbnumber varchar(16);
EXEC dbo.[cspRetrieveDBSysGen] 'PVArch', 'cstpricevaluearchive', 'id', @dbnumber OUTPUT;
select * from dbsysgen where dbtable='cstpricevaluearchive';


-- version: 440 module: allegro-collection date: 2013-06-10 16:55:30 
-- applied to:  HEAD 

-- AllegroSAT

select *  from trayportsequenceitem        where  trayportconfigid = 1;
select *  from trayportsequence            where  trayportconfigid = 1;
select *  from trayportderivedfrom         where  trayportconfigid = 1;
select *  from trayportbtfassociation      where  trayportconfigid = 1;
select *  from trayportbroker              where  trayportconfigid = 1;
select *  from trayporttradingaccount      where  trayportconfigid = 1;
select *  from trayportcompany             where  trayportconfigid = 1;
select *  from trayportterm                where  trayportconfigid = 1;
select *  from trayporttermformat          where  trayportconfigid = 1;
select *  from trayportinstrument          where  trayportconfigid = 1;
select *  from trayportinstrumenttype      where  trayportconfigid = 1;
select *  from trayportconfig              where  trayportconfigid = 1;

--delete FROM trayportinstrument where trayportconfigid=0; 
--delete FROM trayportsequenceitem where trayportconfigid=0; 
--delete FROM trayportsequence where trayportconfigid=0;



select count(*) FROM trayportinstrument where trayportconfigid=0; 
select count(*) FROM trayportsequenceitem where trayportconfigid=0; 
select count(*) FROM trayportsequence where trayportconfigid=0;


select * from gridlog where eventcause='TrayportDeal' order by eventtime desc;

/*
Located at R:\CORP\DIV\MAM\Applications\Trayport\gold-mappings\scripts MIL
*/
UPDATE trayportinstrument SET tradetype='Power Term', tradebook='MIL Proprietary', tradeclass='MP', marketarea='FR', product='Power', holidaycalendar= 'No Holidays', tradestatus= 'New', currency= 'EUR', unit= 'MW', priceunit= 'MWh', timeunit= 'HOUR', factor= '1', timezone= 'CET', block= 'Base', controlarea= 'RTE', powerpoint= 'RTE', revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001109' and trayportconfigid=0;
UPDATE trayportinstrument SET tradetype='Power Term', tradebook='MIL Proprietary', tradeclass='MP', marketarea='FR', product='Power', holidaycalendar= 'No Holidays', tradestatus= 'New', currency= 'EUR', unit= 'MW', priceunit= 'MWh', timeunit= 'HOUR', factor= '1', timezone= 'CET', block= 'Offpeak Std', controlarea= 'RTE', powerpoint= 'RTE', revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001110' and trayportconfigid=0;
UPDATE trayportinstrument SET tradetype='Power Term', tradebook='MIL Proprietary', tradeclass='MP', marketarea='FR', product='Power', holidaycalendar= 'No Holidays', tradestatus= 'New', currency= 'EUR', unit= 'MW', priceunit= 'MWh', timeunit= 'HOUR', factor= '1', timezone= 'CET', block= 'Peak Std Mon-Fri', controlarea= 'RTE', powerpoint= 'RTE', revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001111' and trayportconfigid=0;
UPDATE trayportinstrument SET tradetype='Power Term', tradebook='MIL Proprietary', tradeclass='MP', marketarea='IT', product='Power', holidaycalendar= 'No Holidays', tradestatus= 'New', currency= 'EUR', unit= 'MW', priceunit= 'MWh', timeunit= 'HOUR', factor= '1', timezone= 'CET', block= 'Base', controlarea= 'TERNA', powerpoint= 'TERNA', revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001750' and trayportconfigid=0;
UPDATE trayportinstrument SET tradetype='Power Term', tradebook='MIL Proprietary', tradeclass='MP', marketarea='IT', product='Power', holidaycalendar= 'No Holidays', tradestatus= 'New', currency= 'EUR', unit= 'MW', priceunit= 'MWh', timeunit= 'HOUR', factor= '1', timezone= 'CET', block= 'Base', controlarea= 'TERNA', powerpoint= 'TERNA', revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001715' and trayportconfigid=0;
UPDATE trayportinstrument SET tradetype='Power Term', tradebook='MIL Proprietary', tradeclass='MP', marketarea='IT', product='Power', holidaycalendar= 'No Holidays', tradestatus= 'New', currency= 'EUR', unit= 'MW', priceunit= 'MWh', timeunit= 'HOUR', factor= '1', timezone= 'CET', block= 'Base', controlarea= 'TERNA', powerpoint= 'TERNA', revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001151' and trayportconfigid=0;
UPDATE trayportinstrument SET tradetype='Power Term', tradebook='MIL Proprietary', tradeclass='MP', marketarea='IT', product='Power', holidaycalendar= 'No Holidays', tradestatus= 'New', currency= 'EUR', unit= 'MW', priceunit= 'MWh', timeunit= 'HOUR', factor= '1', timezone= 'CET', block= 'Offpeak Std', controlarea= 'TERNA', powerpoint= 'TERNA', revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001152' and trayportconfigid=0;
UPDATE trayportinstrument SET tradetype='Power Term', tradebook='MIL Proprietary', tradeclass='MP', marketarea='IT', product='Power', holidaycalendar= 'No Holidays', tradestatus= 'New', currency= 'EUR', unit= 'MW', priceunit= 'MWh', timeunit= 'HOUR', factor= '1', timezone= 'CET', block= 'Peak Std Mon-Fri', controlarea= 'TERNA', powerpoint= 'TERNA', revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001153' and trayportconfigid=0;
UPDATE trayportinstrument SET tradetype='Power Term', tradebook='MIL Proprietary', tradeclass='MP', marketarea='IT', product='Power', holidaycalendar= 'No Holidays', tradestatus= 'New', currency= 'EUR', unit= 'MW', priceunit= 'MWh', timeunit= 'HOUR', factor= '1', timezone= 'CET', block= 'Base', controlarea= 'TERNA', powerpoint= 'TERNA', revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001157' and trayportconfigid=0;
UPDATE trayportinstrument SET tradetype='Power Term', tradebook='MIL Proprietary', tradeclass='MP', marketarea='IT', product='Power', holidaycalendar= 'No Holidays', tradestatus= 'New', currency= 'EUR', unit= 'MW', priceunit= 'MWh', timeunit= 'HOUR', factor= '1', timezone= 'CET', block= 'Offpeak Std', controlarea= 'TERNA', powerpoint= 'TERNA', revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001158' and trayportconfigid=0;
UPDATE trayportinstrument SET tradetype='Power Term', tradebook='MIL Proprietary', tradeclass='MP', marketarea='IT', product='Power', holidaycalendar= 'No Holidays', tradestatus= 'New', currency= 'EUR', unit= 'MW', priceunit= 'MWh', timeunit= 'HOUR', factor= '1', timezone= 'CET', block= 'Peak Std Mon-Fri', controlarea= 'TERNA', powerpoint= 'TERNA', revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001159' and trayportconfigid=0;

/*
Located at R:\CORP\DIV\MAM\Applications\Trayport\gold-mappings\scripts
*/
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='FR',product='Power Profile',holidaycalendar='No Holidays',tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='Mon-Sun 00-06h',controlarea='RTE',powerpoint='RTE',revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001098' and trayportconfigid=1;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='FR',product='Power Profile',holidaycalendar='No Holidays',tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='Mon-Fri 16-20h',controlarea='RTE',powerpoint='RTE',revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001099' and trayportconfigid=1;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='FR',product='Power Profile',holidaycalendar='No Holidays',tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='Mon-Fri 20-24h',controlarea='RTE',powerpoint='RTE',revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001100' and trayportconfigid=1;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='FR',product='Power',holidaycalendar='No Holidays',tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='Base',controlarea='RTE',powerpoint='RTE',revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001109' and trayportconfigid=1;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='FR',product='Power',holidaycalendar='No Holidays',tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='Offpeak Std',controlarea='RTE',powerpoint='RTE',revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001110' and trayportconfigid=1;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='FR',product='Power',holidaycalendar='No Holidays',tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='DUMMY',controlarea='RTE',powerpoint='RTE',revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001111' and trayportconfigid=1;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='DE',product='Power Profile',holidaycalendar='No Holidays',tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='Mon-Sun 00-06h',controlarea='AMPRION',powerpoint='AMPRION',revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001123' and trayportconfigid=1;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='DE',product='Power Profile',holidaycalendar='No Holidays',tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='Mon-Fri 16-20h',controlarea='AMPRION',powerpoint='AMPRION',revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001124' and trayportconfigid=1;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='DE',product='Power Profile',holidaycalendar='No Holidays',tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='Mon-Sun 20-24h',controlarea='AMPRION',powerpoint='AMPRION',revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001125' and trayportconfigid=1;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='DE',product='Power',holidaycalendar='No Holidays',tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='Base',controlarea='AMPRION',powerpoint='AMPRION',revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001126' and trayportconfigid=1;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='DE',product='Power',holidaycalendar='No Holidays',tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='Offpeak Std',controlarea='AMPRION',powerpoint='AMPRION',revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001128' and trayportconfigid=1;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='DE',product='Power',holidaycalendar='No Holidays',tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='DUMMY',controlarea='AMPRION',powerpoint='AMPRION',revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001129' and trayportconfigid=1;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='DE',product='Power',holidaycalendar='No Holidays',tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='Sat-Sun 00-24h',controlarea='AMPRION',powerpoint='AMPRION',revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001131' and trayportconfigid=1;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='FR',product='Power',holidaycalendar=NULL,tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='Base',controlarea='RTE',powerpoint='RTE/AMPRION',revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001222' and trayportconfigid=1;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='FR',product='Power',holidaycalendar=NULL,tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='Offpeak Std',controlarea='RTE',powerpoint='RTE/AMPRION',revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001223' and trayportconfigid=1;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='FR',product='Power',holidaycalendar=NULL,tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='Peak Std Mon-Fri',controlarea='RTE',powerpoint='RTE/AMPRION',revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001224' and trayportconfigid=1;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='CH',product='Power Profile',holidaycalendar='No Holidays',tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='Mon-Sun 00-06h',controlarea=NULL,powerpoint=NULL,revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001193' and trayportconfigid=1;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='CH',product='Power Profile',holidaycalendar='No Holidays',tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='Mon-Sun 20-24h',controlarea=NULL,powerpoint=NULL,revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001196' and trayportconfigid=1;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='CH',product='Power',holidaycalendar='No Holidays',tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='Base',controlarea=NULL,powerpoint=NULL,revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001197' and trayportconfigid=1;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='CH',product='Power',holidaycalendar='No Holidays',tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='Offpeak Std',controlarea=NULL,powerpoint=NULL,revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001198' and trayportconfigid=1;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='CH',product='Power',holidaycalendar='No Holidays',tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='DUMMY',controlarea=NULL,powerpoint=NULL,revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001199' and trayportconfigid=1;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='DE',product='Power',holidaycalendar=NULL,tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='Base',controlarea='ENBW',powerpoint='ENBW/SG_ST',revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001549' and trayportconfigid=1;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='DE',product='Power',holidaycalendar=NULL,tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='Offpeak Std',controlarea='ENBW',powerpoint='ENBW/SG_ST',revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001569' and trayportconfigid=1;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='DE',product='Power',holidaycalendar=NULL,tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='Peak Std Mon-Fri',controlarea='ENBW',powerpoint='ENBW/SG_ST',revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001551' and trayportconfigid=1;


-- version: 442 module: allegro-collection date: 2013-06-11 09:20:20 
-- applied to:  HEAD 

USE [AllegroProjectTest]
GO
/****** Object:  StoredProcedure [dbo].[cspPricevalueArchiveFillTable]    Script Date: 06/11/2013 08:20:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
*  Stored Procedure cspPricevalueArchiveFillTable2
*
*  This stored procedure populates the table cstpricevaluearchive with new curves retrieved from pricevalue.
*
*  author: tiziano.mengotti
*  last changed: 6.5.2013
*/
ALTER PROCEDURE [dbo].[cspPricevalueArchiveFillTable2]
AS
BEGIN
  DECLARE  @message       VARCHAR(256);
  DECLARE  @priceindex    VARCHAR(32);
  DECLARE  @pricedate     DATETIME;
  DECLARE  @lastrun       DATETIME;
  DECLARE  @today         DATETIME;
  DECLARE  @dbnumber      VARCHAR(16);
 
  SET @message = 'Populating cstpricevaluearchive...';
  EXECUTE cspUpdateInterfaceAudit 'MAM_1767','1', '0', 'cspPricevalueArchiveFillTable2', 'INFO', @message;
  SET    @today   = Convert(DateTime, DATEDIFF(DAY, 0, GETDATE()));
  SELECT @lastrun = MAX(pricedate) from cstpricevaluearchive;
  
  DECLARE pop_cursor CURSOR FOR 
  SELECT DISTINCT pv.pricedate, pv.priceindex FROM pricevalue pv, priceindex pidx 
  WHERE
  pv.priceindex=pidx.priceindex and pidx.indextype='FORWARD' AND 
  pv.pricedate>@lastrun AND pv.pricedate<=@today ORDER BY pv.pricedate, pv.priceindex asc;
  
  OPEN pop_cursor;
  
  FETCH NEXT FROM pop_cursor INTO @pricedate, @priceindex;
   
  WHILE @@FETCH_STATUS = 0
     BEGIN
       EXEC dbo.[cspRetrieveDBSysGen] 'PVArch', 'cstpricevaluearchive', 'id', @dbnumber OUTPUT;
       INSERT cstpricevaluearchive (id, pricedate, priceindex, archivestatus, creationname, creationdate)
       VALUES(CAST(@dbnumber AS INT), @pricedate, @priceindex, 'FALSE', 'cspPricevalueArchiveFillTable2', GETDATE());
       
       FETCH NEXT FROM pop_cursor INTO @pricedate, @priceindex;
     END;
     
  CLOSE pop_cursor;
  DEALLOCATE pop_cursor;   
  
  SET @message = 'Population of cstpricevaluearchive over.';
  EXECUTE cspUpdateInterfaceAudit 'MAM_1767','1', '0', 'cspPricevalueArchiveFillTable2', 'INFO', @message;
END;





-- version: 443 module: allegro-collection date: 2013-06-11 09:45:43 
-- applied to:  HEAD 

delete from cstpricevaluearchive where pricedate>='2012-12-01';
select count(*) from cstpricevaluearchive;

EXEC cspPriceValueArchiveFillTable;

EXEC cspPriceValueArchiveFillTable2;


-- version: 444 module: allegro-collection date: 2013-06-14 08:38:16 
-- applied to:  HEAD 

-- settlement prices reload

select count(*) from pricevalue where priceindex='Ctice Settle';
select count(*) from pricevalue where priceindex='EUA monthly avg Settle';
select count(*) from pricevalue where priceindex='Im gas release 2004 Settle';
select count(*) from pricevalue where priceindex='Im gas release 2007 Settle';
select count(*) from pricevalue where priceindex='It - Edison Settle';
select count(*) from pricevalue where priceindex='It - Ice Brent 6 mth avg Settle';
select count(*) from pricevalue where priceindex='It - ICEBrent901 Settle';
select count(*) from pricevalue where priceindex='It - Mix 80-20 Settle';
select count(*) from pricevalue where priceindex='It - Pun Mth Avg Settle';
select count(*) from pricevalue where priceindex='It - Swap Settle';
select count(*) from pricevalue where priceindex='PMGas Settle';


delete from pricevalue where priceindex='Ctice Settle';
delete from pricevalue where priceindex='EUA monthly avg Settle';
delete from pricevalue where priceindex='Im gas release 2004 Settle';
delete from pricevalue where priceindex='Im gas release 2007 Settle';
delete from pricevalue where priceindex='It - Edison Settle';
delete from pricevalue where priceindex='It - Ice Brent 6 mth avg Settle';
delete from pricevalue where priceindex='It - ICEBrent901 Settle';
delete from pricevalue where priceindex='It - Mix 80-20 Settle';
delete from pricevalue where priceindex='It - Pun Mth Avg Settle';
delete from pricevalue where priceindex='It - Swap Settle';
delete from pricevalue where priceindex='PMGas Settle';


-- version: 445 module: allegro-collection date: 2013-06-14 08:46:24 
-- applied to:  HEAD 

-- forward prices reload

select count(*) from pricevalue where priceindex='Ctice Forward';
select count(*) from pricevalue where priceindex='EUA monthly avg Forward';
select count(*) from pricevalue where priceindex='Im gas release 2004 Forward';
select count(*) from pricevalue where priceindex='Im gas release 2007 Forward';
select count(*) from pricevalue where priceindex='It - Edison Forward';
select count(*) from pricevalue where priceindex='It - Ice Brent 6 mth avg Forward';
select count(*) from pricevalue where priceindex='It - ICEBrent901 Forward';
select count(*) from pricevalue where priceindex='It - Mix 80-20 Forward';
select count(*) from pricevalue where priceindex='It - Pun Mth Avg Forward';
select count(*) from pricevalue where priceindex='It - Swap Forward';
select count(*) from pricevalue where priceindex='PMGas Forward';


delete from pricevalue where priceindex='Ctice Forward';
delete from pricevalue where priceindex='EUA monthly avg Forward';
delete from pricevalue where priceindex='Im gas release 2004 Forward';
delete from pricevalue where priceindex='Im gas release 2007 Forward';
delete from pricevalue where priceindex='It - Edison Forward';
delete from pricevalue where priceindex='It - Ice Brent 6 mth avg Forward';
delete from pricevalue where priceindex='It - ICEBrent901 Forward';
delete from pricevalue where priceindex='It - Mix 80-20 Forward';
delete from pricevalue where priceindex='It - Pun Mth Avg Forward';
delete from pricevalue where priceindex='It - Swap Forward';
delete from pricevalue where priceindex='PMGas Forward';


-- version: 446 module: allegro-collection date: 2013-06-20 08:05:36 
-- applied to:  HEAD 

select count(*) as count, sum(price) as sumprice, priceindex from pricevalue where priceindex like '%Band%' group by priceindex order by priceindex asc;

delete from pricevalue where priceindex='Power AT Hour Forward' and pricedate='2013-06-19';
delete from pricevalue where priceindex='Power DE Hour Forward' and pricedate='2013-06-19';
delete from pricevalue where priceindex='Power AT Offpeak Day Forward' and pricedate='2013-06-19';
delete from pricevalue where priceindex='Power AT Peak Day Forward' and pricedate='2013-06-19';
delete from pricevalue where priceindex='Power DE Offpeak Day Forward' and pricedate='2013-06-19';
delete from pricevalue where priceindex='Power DE Peak Day Forward' and pricedate='2013-06-19';


-- version: 460 module: allegro-collection date: 2013-06-21 16:28:54 
-- applied to:  HEAD  BRANCH_HEAD.245 

-- should be 60 items
select pricedate, priceindex from pricevalue where priceindex like '%Pwr%' 
group by pricedate, priceindex
order by pricedate,priceindex asc;


-- version: 462 module: allegro-collection date: 2013-06-24 10:23:20 
-- applied to:  HEAD 

--AllegroUAT
-- 3595 Class Event che va in eccezione
select * from classevent where name='cceBeforeSchedInvokeCheckValuation';
select * from classevent where name='cceBeforeSchedInvokeCheckSettlementValuation';

-- 3594 errore nella validation inesistente
select vd.validation,vd.* from valuationdetail vd where vd.valuation=104142 
and vd.trade=214325
order by vd.validation, vd.begtime asc;


--3596 alcuni trade che non vengono valutati
select * from valuation where creationdate>GETDATE()-1;
select * from gridlog order by creationdate desc;
select * from gridqueue;

select vd.validation,vd.* from valuationdetail vd where vd.valuation=104142 
and vd.trade=215827
order by vd.validation, vd.begtime asc;

-- check if there are powerquantities
SELECT pq.* FROM trade t, position p, powerposition pp, powerquantity pq 
WHERE p.trade=t.trade AND t.trade=215827
AND pp.position=p.position AND pq.position=p.position;


select * from gridlog where eventcause='Create Valuation Valuation Mode= Position' 
order by creationdate desc;

select * from gridlog where eventcause='Create Valuation Valuation Mode= Position' 
and creationdate>GETDATE()-1
order by creationdate desc;

select * from cstinterfaceaudit order by creationdate desc;

-- 1
select t.* from trade t, position p where p.trade=t.trade and
p.position in (215823 , 215824 , 215825 , 215826 , 215827);

-- 2
select t.* from trade t, position p where p.trade=t.trade and
p.position in (215828 , 215835 , 215836 , 215837 , 215838);

--3
select t.* from trade t, position p where p.trade=t.trade and
p.position in (215827 , 215828 , 215835 , 215836 , 215837);

--4 ecco finalmente i due colpevoli in questione:
select t.* from trade t, position p where p.trade=t.trade and
p.position in (215827 ,215835);


-- no questi no, sono le positions sopra che ci interessano
select * from trade where trade in (215823 , 215824 , 215825 , 215826 , 215827);
select * from trade where trade in (215828 , 215835 , 215836 , 215837 , 215838);


select * from position p, trade t where p.trade=t.trade and p.position=214716;
select * from position where position=214716; -- il contratto maledetto 200025;
select * from trade t, position p where p.contract=200025 and p.trade=t.trade order by t.trade asc;



-- version: 463 module: allegro-collection date: 2013-06-24 11:08:45 
-- applied to:  HEAD  BRANCH_HEAD.245 

--AllegroUAT
/*
SELECT * FROM gridlog WHERE eventcause='TrayportDeal' ORDER BY eventtime DESC;
*/
UPDATE gridservice SET parenturl='http://192.168.0.72/allegrouat' WHERE servicename='TrayportDeal';
/*
UPDATE trayportinstrument SET tradetype='Power Spot', tradebook='MIL Proprietary', tradeclass='MP', marketarea='FR', product='Power', holidaycalendar= 'No Holidays', tradestatus= 'New', currency= 'EUR', unit= 'MW', priceunit= 'MWh', timeunit= 'HOUR', factor= '1', timezone= 'CET', block= 'Base', controlarea= 'RTE', powerpoint= 'RTE', revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001109' and trayportconfigid=1;
UPDATE trayportinstrument SET tradetype='Power Spot', tradebook='MIL Proprietary', tradeclass='MP', marketarea='FR', product='Power', holidaycalendar= 'No Holidays', tradestatus= 'New', currency= 'EUR', unit= 'MW', priceunit= 'MWh', timeunit= 'HOUR', factor= '1', timezone= 'CET', block= 'Offpeak Std', controlarea= 'RTE', powerpoint= 'RTE', revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001110' and trayportconfigid=1;
UPDATE trayportinstrument SET tradetype='Power Spot', tradebook='MIL Proprietary', tradeclass='MP', marketarea='FR', product='Power', holidaycalendar= 'No Holidays', tradestatus= 'New', currency= 'EUR', unit= 'MW', priceunit= 'MWh', timeunit= 'HOUR', factor= '1', timezone= 'CET', block= 'Peak Std Mon-Fri', controlarea= 'RTE', powerpoint= 'RTE', revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001111' and trayportconfigid=1;
UPDATE trayportinstrument SET tradetype='Power Spot', tradebook='MIL Proprietary', tradeclass='MP', marketarea='IT', product='Power', holidaycalendar= 'No Holidays', tradestatus= 'New', currency= 'EUR', unit= 'MW', priceunit= 'MWh', timeunit= 'HOUR', factor= '1', timezone= 'CET', block= 'Base', controlarea= 'TERNA', powerpoint= 'TERNA', revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001750' and trayportconfigid=1;
UPDATE trayportinstrument SET tradetype='Power Spot', tradebook='MIL Proprietary', tradeclass='MP', marketarea='IT', product='Power', holidaycalendar= 'No Holidays', tradestatus= 'New', currency= 'EUR', unit= 'MW', priceunit= 'MWh', timeunit= 'HOUR', factor= '1', timezone= 'CET', block= 'Base', controlarea= 'TERNA', powerpoint= 'TERNA', revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001715' and trayportconfigid=1;
UPDATE trayportinstrument SET tradetype='Power Spot', tradebook='MIL Proprietary', tradeclass='MP', marketarea='IT', product='Power', holidaycalendar= 'No Holidays', tradestatus= 'New', currency= 'EUR', unit= 'MW', priceunit= 'MWh', timeunit= 'HOUR', factor= '1', timezone= 'CET', block= 'Base', controlarea= 'TERNA', powerpoint= 'TERNA', revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001151' and trayportconfigid=1;
UPDATE trayportinstrument SET tradetype='Power Spot', tradebook='MIL Proprietary', tradeclass='MP', marketarea='IT', product='Power', holidaycalendar= 'No Holidays', tradestatus= 'New', currency= 'EUR', unit= 'MW', priceunit= 'MWh', timeunit= 'HOUR', factor= '1', timezone= 'CET', block= 'Offpeak Std', controlarea= 'TERNA', powerpoint= 'TERNA', revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001152' and trayportconfigid=1;
UPDATE trayportinstrument SET tradetype='Power Spot', tradebook='MIL Proprietary', tradeclass='MP', marketarea='IT', product='Power', holidaycalendar= 'No Holidays', tradestatus= 'New', currency= 'EUR', unit= 'MW', priceunit= 'MWh', timeunit= 'HOUR', factor= '1', timezone= 'CET', block= 'Peak Std Mon-Fri', controlarea= 'TERNA', powerpoint= 'TERNA', revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001153' and trayportconfigid=1;
UPDATE trayportinstrument SET tradetype='Power Spot', tradebook='MIL Proprietary', tradeclass='MP', marketarea='IT', product='Power', holidaycalendar= 'No Holidays', tradestatus= 'New', currency= 'EUR', unit= 'MW', priceunit= 'MWh', timeunit= 'HOUR', factor= '1', timezone= 'CET', block= 'Base', controlarea= 'TERNA', powerpoint= 'TERNA', revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001157' and trayportconfigid=1;
UPDATE trayportinstrument SET tradetype='Power Spot', tradebook='MIL Proprietary', tradeclass='MP', marketarea='IT', product='Power', holidaycalendar= 'No Holidays', tradestatus= 'New', currency= 'EUR', unit= 'MW', priceunit= 'MWh', timeunit= 'HOUR', factor= '1', timezone= 'CET', block= 'Offpeak Std', controlarea= 'TERNA', powerpoint= 'TERNA', revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001158' and trayportconfigid=1;
UPDATE trayportinstrument SET tradetype='Power Spot', tradebook='MIL Proprietary', tradeclass='MP', marketarea='IT', product='Power', holidaycalendar= 'No Holidays', tradestatus= 'New', currency= 'EUR', unit= 'MW', priceunit= 'MWh', timeunit= 'HOUR', factor= '1', timezone= 'CET', block= 'Peak Std Mon-Fri', controlarea= 'TERNA', powerpoint= 'TERNA', revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001159' and trayportconfigid=1;
*/

DELETE FROM trayportinstrument where trayportconfigid=0; DELETE FROM trayportsequenceitem where trayportconfigid=0; DELETE FROM trayportsequence where trayportconfigid=0;

UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='FR',product='Power Profile',holidaycalendar='No Holidays',tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='Mon-Sun 00-06h',controlarea='RTE',powerpoint='RTE',revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001098' and trayportconfigid=0;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='FR',product='Power Profile',holidaycalendar='No Holidays',tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='Mon-Fri 16-20h',controlarea='RTE',powerpoint='RTE',revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001099' and trayportconfigid=0;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='FR',product='Power Profile',holidaycalendar='No Holidays',tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='Mon-Fri 20-24h',controlarea='RTE',powerpoint='RTE',revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001100' and trayportconfigid=0;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='FR',product='Power',holidaycalendar='No Holidays',tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='Base',controlarea='RTE',powerpoint='RTE',revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001109' and trayportconfigid=0;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='FR',product='Power',holidaycalendar='No Holidays',tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='Offpeak Std',controlarea='RTE',powerpoint='RTE',revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001110' and trayportconfigid=0;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='FR',product='Power',holidaycalendar='No Holidays',tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='DUMMY',controlarea='RTE',powerpoint='RTE',revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001111' and trayportconfigid=0;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='DE',product='Power Profile',holidaycalendar='No Holidays',tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='Mon-Sun 00-06h',controlarea='AMPRION',powerpoint='AMPRION',revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001123' and trayportconfigid=0;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='DE',product='Power Profile',holidaycalendar='No Holidays',tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='Mon-Fri 16-20h',controlarea='AMPRION',powerpoint='AMPRION',revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001124' and trayportconfigid=0;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='DE',product='Power Profile',holidaycalendar='No Holidays',tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='Mon-Sun 20-24h',controlarea='AMPRION',powerpoint='AMPRION',revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001125' and trayportconfigid=0;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='DE',product='Power',holidaycalendar='No Holidays',tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='Base',controlarea='AMPRION',powerpoint='AMPRION',revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001126' and trayportconfigid=0;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='DE',product='Power',holidaycalendar='No Holidays',tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='Offpeak Std',controlarea='AMPRION',powerpoint='AMPRION',revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001128' and trayportconfigid=0;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='DE',product='Power',holidaycalendar='No Holidays',tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='DUMMY',controlarea='AMPRION',powerpoint='AMPRION',revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001129' and trayportconfigid=0;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='DE',product='Power',holidaycalendar='No Holidays',tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='Sat-Sun 00-24h',controlarea='AMPRION',powerpoint='AMPRION',revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001131' and trayportconfigid=0;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='FR',product='Power',holidaycalendar=NULL,tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='Base',controlarea='RTE',powerpoint='RTE/AMPRION',revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001222' and trayportconfigid=0;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='FR',product='Power',holidaycalendar=NULL,tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='Offpeak Std',controlarea='RTE',powerpoint='RTE/AMPRION',revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001223' and trayportconfigid=0;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='FR',product='Power',holidaycalendar=NULL,tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='Peak Std Mon-Fri',controlarea='RTE',powerpoint='RTE/AMPRION',revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001224' and trayportconfigid=0;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='CH',product='Power Profile',holidaycalendar='No Holidays',tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='Mon-Sun 00-06h',controlarea=NULL,powerpoint=NULL,revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001193' and trayportconfigid=0;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='CH',product='Power Profile',holidaycalendar='No Holidays',tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='Mon-Sun 20-24h',controlarea=NULL,powerpoint=NULL,revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001196' and trayportconfigid=0;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='CH',product='Power',holidaycalendar='No Holidays',tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='Base',controlarea=NULL,powerpoint=NULL,revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001197' and trayportconfigid=0;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='CH',product='Power',holidaycalendar='No Holidays',tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='Offpeak Std',controlarea=NULL,powerpoint=NULL,revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001198' and trayportconfigid=0;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='CH',product='Power',holidaycalendar='No Holidays',tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='DUMMY',controlarea=NULL,powerpoint=NULL,revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001199' and trayportconfigid=0;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='DE',product='Power',holidaycalendar=NULL,tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='Base',controlarea='ENBW',powerpoint='ENBW/SG_ST',revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001549' and trayportconfigid=0;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='DE',product='Power',holidaycalendar=NULL,tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='Offpeak Std',controlarea='ENBW',powerpoint='ENBW/SG_ST',revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001569' and trayportconfigid=0;
UPDATE trayportinstrument SET tradetype='Power Term',tradebook='POS Proprietary',tradeclass='Prop',marketarea='DE',product='Power',holidaycalendar=NULL,tradestatus='New',currency='EUR',unit='MW',priceunit='MWh',timeunit='HOUR',factor='1',timezone='CET',block='Peak Std Mon-Fri',controlarea='ENBW',powerpoint='ENBW/SG_ST',revisionname='MAM_1548',revisiondate=GETDATE() WHERE instid='10001551' and trayportconfigid=0;


-- version: 468 module: allegro-collection date: 2013-06-25 11:24:37 
-- applied to:  HEAD 

--AllegroUAT
-- 3595 Class Event che va in eccezione
select * from classevent where name='cceBeforeSchedInvokeCheckValuation';
select * from classevent where name='cceBeforeSchedInvokeCheckSettlementValuation';

-- 3594 errore nella validation inesistente
select vd.validation,vd.* from valuationdetail vd where vd.valuation=104142 
and vd.trade=214325
order by vd.validation, vd.begtime asc;


--3596 alcuni trade che non vengono valutati
select * from valuation where creationdate>GETDATE()-1;
select * from gridlog order by creationdate desc;
select * from gridqueue;

select vd.validation,vd.* from valuationdetail vd where vd.valuation=104142 
and vd.trade=215827
order by vd.validation, vd.begtime asc;

-- check if there are powerquantities
SELECT pq.* FROM trade t, position p, powerposition pp, powerquantity pq 
WHERE p.trade=t.trade AND t.trade=215827
AND pp.position=p.position AND pq.position=p.position;

select * from gridlog where eventcause='Create Valuation Valuation Mode= Position' 
order by creationdate desc;

select * from gridlog where eventcause='Create Valuation Valuation Mode= Position' 
and creationdate>GETDATE()-1
order by creationdate desc;

select * from cstinterfaceaudit order by creationdate desc;

-- 1
select t.* from trade t, position p where p.trade=t.trade and
p.position in (215823 , 215824 , 215825 , 215826 , 215827);

-- 2
select t.* from trade t, position p where p.trade=t.trade and
p.position in (215828 , 215835 , 215836 , 215837 , 215838);

-- no questi no, sono le positions sopra che ci interessano
select * from trade where trade in (215823 , 215824 , 215825 , 215826 , 215827);
select * from trade where trade in (215828 , 215835 , 215836 , 215837 , 215838);


-- version: 469 module: allegro-collection date: 2013-06-26 14:54:32 
-- applied to:  HEAD 

--AllegroTarget
select top 100 * from fee;
select * from brokerfee;


-- Se sono giuste le fee configurate in Allegro e sbagliate le fee migrate sui trades, allora si devono corregere questi 113 trades:
-- trades
select t.trade, t.cstcompetencycentre, t.tradetype,t.begtime, t.endtime,p.position, f.feetype, f.description, f.pricediff as migratedfeepricediff, 
bf.pricediff as brokerpricediff  
from brokerfee bf, fee f, position p, trade t where 
bf.feetype=f.feetype and bf.description=f.description and
f.dbcolumn='POSITION' and f.dbvalue=p.position and
p.trade = t.trade AND
1=(select count(*) from position where trade=p.trade) AND
t.cstcompetencycentre='MIL' AND
f.pricediff<>bf.pricediff;

-- Altrimenti se le fee migrate sui trades sono giuste e quelle configurate in Allegro sbagliate, allora basta correggere queste due fee
-- broker fees da aggiustare
select distinct f.feetype, f.description, f.pricediff as migratedfeepricediff, 
bf.pricediff as brokerpricediff  
from brokerfee bf, fee f, position p, trade t where 
bf.feetype=f.feetype and bf.description=f.description and
f.dbcolumn='POSITION' and f.dbvalue=p.position and
p.trade = t.trade AND
1=(select count(*) from position where trade=p.trade) AND
t.cstcompetencycentre='MIL' AND
f.pricediff<>bf.pricediff



-- version: 470 module: allegro-collection date: 2013-06-26 15:32:59 
-- applied to:  HEAD 

-- there is only one position not attached to trades but to the contract 200025
select * from position p, trade t where p.trade=t.trade and p.position=214716;
select * from position where position=214716; -- il contratto maledetto 200025;
select * from trade t, position p where p.contract=200025 and p.trade=t.trade order by t.trade asc;


-- version: 471 module: allegro-collection date: 2013-06-28 10:08:32 
-- applied to:  HEAD  BRANCH_HEAD.245 

USE [AllegroUAT]
GO
/****** Object:  StoredProcedure [dbo].[cspEoDContractValueDetail]    Script Date: 06/28/2013 10:24:08 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

ALTER PROCEDURE [dbo].[cspEoDContractValueDetail]
@competencycentre varchar(32)
AS
/******
 
  Script:               cspEoDContractValueDetail
  Script Date:          2011-08-31 18:43:09 
  Project:              Up-Trade
  Author:               JG, Logica
  Description:          Mantis 1359 Credit export contract valuation detail results

  $Id: cspEoDContractValueDetail.sql 3493 2011-09-01 08:39:13Z lancaricm $

******/
BEGIN


        ---------------------------------------------------------------------
        -- Declarations
        ---------------------------------------------------------------------
        DECLARE @PivotColList AS VARCHAR(max)
        DECLARE @PivotQuery AS VARCHAR(max)
        DECLARE @SQL varchar(max)
        DECLARE @EoDValDate AS DATETIME
        DECLARE @EoDValTime AS DATETIME
        DECLARE @EoDVal AS VARCHAR(32)
        DECLARE @Timestamp AS VARCHAR(15)
        DECLARE @DBName AS VARCHAR(32)

        ------------------------------------------------------------------
        -- Initialise
        ------------------------------------------------------------------
--      PRINT 'cspEoDContractValueDetail: Begin'
--      PRINT '  Valuation='+ @pValuation

        IF ( OBJECT_ID('dbo.cstEoDContractValueDetail') IS NOT NULL ) 
           DROP TABLE dbo.cstEoDContractValueDetail

        ------------------------------------------------------------------
        -- Identify yesterdays EoD Position valuation
        ------------------------------------------------------------------
        SET @EoDValDate = DATEADD(day, DATEDIFF(day, 0, getdate())-1, 0)
        SET @EoDValTime = (     SELECT MAX(valuationtime)
                                                FROM valuation
                                                WHERE valuationmode = 'Position' AND
                                                          valuationtype = 'SUMMATION' AND
                                                          valuationstatus = 'COMPLETE' AND
                                                          valuationtime >= @EoDValDate AND
                                                          valuationtime < DATEADD(day, 1, @EoDValDate) AND
                                                          DATEPART(hour, valuationtime) >= 23 )
        SET @EoDVal = ( SELECT valuation
                                        FROM valuation
                                        WHERE valuationmode = 'Position' AND
                                                  valuationtype = 'SUMMATION' AND
                                                  valuationstatus = 'COMPLETE' AND
                                                  valuationtime = @EoDValTime )

        ------------------------------------------------------------------
        -- Dynamically create list of pivot columns
        ------------------------------------------------------------------
        SET @PivotColList = NULL

        SELECT  @PivotColList = ISNULL(@PivotColList + ',', '') + '[' + tp.timeperiod + ']'
        FROM    valuation v,
                        cvwEoDMonthHistory mth,
                        timeperiod tp
        WHERE   v.valuation = @EoDVal AND
                        mth.monthsequence >= DATEADD(month, -1, DATEADD(year, DATEDIFF(year, 0, v.valuationtime), 0)) AND
                        mth.monthsequence < DATEADD(year, 6, DATEADD(year, DATEDIFF(year, 0, v.valuationtime), 0)) AND
                        tp.timeperiodclass = 'CAL' AND 
                        tp.method = 'FIXED' AND 
                        tp.timeunit = 'MONTH' AND 
                        tp.begtime <= mth.monthsequence AND 
                        tp.endtime > mth.monthsequence
                        
        PRINT @PivotColList

        ------------------------------------------------------------------
        -- Dynamically construct pivot table query
        ------------------------------------------------------------------
        SET @PivotQuery = 'SELECT valuation,
                positiontype,
                cstcompetencycentre,
                counterparty,
                company,
                producttype,
                currency,
                ' + @PivotColList + ' 
        INTO cstEoDContractValueDetail
        FROM (SELECT v.valuation,
                         p.positiontype,
                         vd.cstcompetencycentre,
                         vd.counterparty,
                         vd.company,
                         vd.producttype,
                         vd.currency,
                         vd.cstdeliverymonth,
                         SUM(vd.value) AS value
                FROM valuation v,
                         valuationdetail vd,
                         position p
                WHERE v.valuation = ' + @EoDVal + ' /* ''100997'' */ AND
                          v.valuationmode = ''Position'' AND
                          v.valuationtype = ''SUMMATION'' AND
                          v.valuationstatus = ''COMPLETE'' AND
                          vd.valuation = v.valuation AND
                          vd.exposure = ''POSITION'' AND
                          vd.quantitytype <> ''LOSS'' AND
                          vd.counterparty <> vd.company AND 
                          vd.cstcompetencycentre = '''+@competencycentre+''' AND
                          vd.cstdeliverydate >= dateadd(month, -1, dateadd(year, datediff(year, 0, v.valuationtime), 0)) AND
                          vd.cstdeliverydate < dateadd(year, 6, dateadd(year, datediff(year, 0, v.valuationtime), 0)) AND
                          p.position = vd.position
                GROUP BY v.valuation,
                                 p.positiontype,
                                 vd.cstcompetencycentre,
                                 vd.counterparty,
                                 vd.company,
                                 vd.producttype,
                                 vd.currency,
                                 vd.cstdeliverymonth) AS cdbycol
                PIVOT (SUM(value)
                                FOR cstdeliverymonth
                                IN (' + @PivotColList + ')
                          ) AS valuebydeliverymonth'
          
        PRINT @PivotQuery
        
        ------------------------------------------------------------------
        -- Dynamically execute pivot table query
        ------------------------------------------------------------------

        EXEC(@PivotQuery)
        
        ------------------------------------------------------------------
        -- Execute Procedure to export to Excel
        ------------------------------------------------------------------

        SELECT @Timestamp = CONVERT(VARCHAR, @EoDValTime, 112) + '_' + REPLACE(CONVERT(VARCHAR, @EoDValTime, 108), ':', '')
        
        IF(@Timestamp != '')
                SET @SQL = 'EXEC dbo.cspExportToExcel ''cstEoDContractValueDetail'', ''EoD Contract Value Export '+@competencycentre+''', ''' + @Timestamp + ''', ''order by valuation, positiontype, counterparty, company, producttype, currency'''
        ELSE
                SET @SQL = 'EXEC dbo.cspExportToExcel ''cstEoDContractValueDetail'', ''EoD Contract Value Export '+@competencycentre+''',  @OrderBy=''order by valuation, positiontype, counterparty, company, producttype, currency'''

        PRINT @SQL
        EXEC(@SQL)      
END


-- version: 472 module: allegro-collection date: 2013-06-28 11:07:12 
-- applied to:  HEAD 

USE [msdb]
GO

/****** Object:  Job [batEodContractValueDetail_MIL]    Script Date: 06/28/2013 11:06:33 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 06/28/2013 11:06:33 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'batEodContractValueDetail_MIL', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'svcAllegroSQLAgentJobs', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [execute_stored_proc]    Script Date: 06/28/2013 11:06:33 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'execute_stored_proc', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'execute cspEoDContractValueDetail ''MIL''', 
		@database_name=N'AllegroUAT', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Daily_Run', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20120212, 
		@active_end_date=99991231, 
		@active_start_time=64500, 
		@active_end_time=235959, 
		@schedule_uid=N'72bd326e-e99a-408f-a31c-a3c9b4c854f4'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO




-- version: 473 module: allegro-collection date: 2013-06-28 11:08:00 
-- applied to:  HEAD 

USE [msdb]
GO

/****** Object:  Job [batEodContractValueDetail_POS]    Script Date: 06/28/2013 11:07:21 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 06/28/2013 11:07:21 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'batEodContractValueDetail_POS', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'svcAllegroSQLAgentJobs', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [execute_stored_proc]    Script Date: 06/28/2013 11:07:22 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'execute_stored_proc', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'execute cspEoDContractValueDetail ''POS''', 
		@database_name=N'AllegroUAT', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Daily_Run', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20120212, 
		@active_end_date=99991231, 
		@active_start_time=64500, 
		@active_end_time=235959, 
		@schedule_uid=N'72bd326e-e99a-408f-a31c-a3c9b4c854f4'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO




-- version: 474 module: allegro-collection date: 2013-06-28 14:05:42 
-- applied to:  HEAD 

UPDATE gridservice SET parenturl='http://192.168.0.81/allegrosat' WHERE servicename='TrayportDeal';

--DELETE FROM trayportinstrument where trayportconfigid=0; DELETE FROM trayportsequenceitem where trayportconfigid=0; DELETE FROM trayportsequence where trayportconfigid=0;

select count(*) from trayportinstrument;
select count(*) from trayportsequenceitem;
select count(*) from trayportsequence;

/*
"1. Change in table gridservice the parenturl for servicename Trayportdeal, e.g. with
UPDATE gridservice SET parenturl='http://192.168.X.YYY/allegrouat' WHERE servicename='TrayportDeal';
2. Check that both trayportconfigids are configured in 'Trayport Parameters' and set to Active
3. Ask for a IIS reset and kill of all AllegroWP.exe. The IF1 should fire up right after that. If not, go to pane 'Grid Manager', 'Grid service' and restart the service TrayportDeal
4. Verify in 'Grid Manager', pane 'Grid service', that the TrayportDeal service is in status Running
5. Define instrument types 'Atomic Instument', 'Combination Instrument', 'Sequential Instrument for configid=1  
6. Delete old swiss instruments with 
DELETE FROM trayportinstrument where trayportconfigid=0; DELETE FROM trayportsequenceitem where trayportconfigid=0; DELETE FROM trayportsequence where trayportconfigid=0;
7. Select connection with configid=0 in trayportconfig, and ""Sequential Instrument"" in Instrument Type. Then hit button 'Instrument Definition""  
8. Select connection with configid=1 in trayportconfig, and ""Sequential Instrument"" in Instrument Type. Then hit button 'Instrument Definition""
9. Very important: change comopany in trayportcompany from ENERGIASUD to RE_IT
10. Execute SQL script IF1_refresh_Trayport_mapping_Italy.txt under R:\CORP\DIV\MAM\Applications\Trayport\gold-mappings\scripts
11. Execute SQL script IF1_refresh_Trayport_mapping_Swiss.txt under R:\CORP\DIV\MAM\Applications\Trayport\gold-mappings\scripts
12. Check that the data migration populated panes Trayport Counterparty (with the dummy contract 300008 set!) and Trayport Contract Mapping in 'Trayport Parameters'
13. IF1 is ready!
14. As last step: void all trades retrieved by the interface from the previous month, which are already in the data migration!"
*/



-- version: 476 module: allegro-collection date: 2013-07-01 16:57:26 
-- applied to:  HEAD 

select priceindex from pricevalue where
priceindex like 'Power IT%' and
pricedate='2013-06-30' 
group by priceindex order by priceindex asc;

delete from pricevalue where pricedate='2013-06-28' and priceindex='Power IT IPEX CSud Hour Forward';
delete from pricevalue where pricedate='2013-06-29' and priceindex='Power IT IPEX CSud Hour Forward';
delete from pricevalue where pricedate='2013-06-30' and priceindex='Power IT IPEX CSud Hour Forward';

delete from pricevalue where pricedate='2013-06-28' and priceindex='';
delete from pricevalue where pricedate='2013-06-29' and priceindex='';
delete from pricevalue where pricedate='2013-06-30' and priceindex='';

delete from pricevalue where pricedate='2013-06-28' and priceindex='Power IT IPEX North Hour Forward';
delete from pricevalue where pricedate='2013-06-29' and priceindex='Power IT IPEX North Hour Forward';
delete from pricevalue where pricedate='2013-06-30' and priceindex='Power IT IPEX North Hour Forward';

delete from pricevalue where pricedate='2013-06-28' and priceindex='Power IT IPEX PUN Hour Forward';
delete from pricevalue where pricedate='2013-06-29' and priceindex='Power IT IPEX PUN Hour Forward';
delete from pricevalue where pricedate='2013-06-30' and priceindex='Power IT IPEX PUN Hour Forward';

delete from pricevalue where pricedate='2013-06-28' and priceindex='Power IT IPEX Sicily Hour Forwar';
delete from pricevalue where pricedate='2013-06-29' and priceindex='Power IT IPEX Sicily Hour Forwar';
delete from pricevalue where pricedate='2013-06-30' and priceindex='Power IT IPEX Sicily Hour Forwar';

delete from pricevalue where pricedate='2013-06-28' and priceindex='Power IT IPEX Sud Hour Forward';
delete from pricevalue where pricedate='2013-06-29' and priceindex='Power IT IPEX Sud Hour Forward';
delete from pricevalue where pricedate='2013-06-30' and priceindex='Power IT IPEX Sud Hour Forward';

delete from pricevalue where pricedate='2013-06-28' and priceindex='Power IT Offpeak Day Forward';
delete from pricevalue where pricedate='2013-06-29' and priceindex='Power IT Offpeak Day Forward';
delete from pricevalue where pricedate='2013-06-30' and priceindex='Power IT Offpeak Day Forward';

delete from pricevalue where pricedate='2013-06-28' and priceindex='Power IT Peak Day Forward';
delete from pricevalue where pricedate='2013-06-29' and priceindex='Power IT Peak Day Forward';
delete from pricevalue where pricedate='2013-06-30' and priceindex='Power IT Peak Day Forward';


-- version: 478 module: allegro-collection date: 2013-07-03 15:59:11 
-- applied to:  HEAD 

SELECT * FROM viewname
ORDER BY creationdate DESC
 
SELECT * FROM viewname
ORDER BY revisiondate DESC
 
 
SELECT * FROM viewpane
ORDER BY creationdate DESC
 
SELECT * FROM viewpane
ORDER BY revisiondate DESC
 
 
SELECT * FROM viewcolumn 
ORDER BY creationdate DESC
 
SELECT * FROM viewcolumn 
ORDER BY revisiondate DESC
 
 
 
SELECT * FROM viewcriteria 
ORDER BY creationdate DESC
 
SELECT * FROM viewcriteria 
ORDER BY revisiondate DESC
 
 
SELECT * FROM class
ORDER BY creationdate DESC
 
SELECT * FROM class
ORDER BY revisiondate DESC
 
 
SELECT * FROM classevent
ORDER BY creationdate DESC
 
SELECT * FROM classevent
ORDER BY revisiondate DESC
 
 
SELECT * FROM template 
ORDER BY creationdate DESC
 
SELECT * FROM template 
ORDER BY revisiondate DESC
 
 
SELECT * FROM viewtemplate
ORDER BY creationdate DESC
 
SELECT * FROM viewtemplate 


-- version: 479 module: allegro-collection date: 2013-07-04 08:47:16 
-- applied to:  HEAD 

select * from valuation where valuationstatus='INCOMPLETE';
select count(*) from gridqueue;

select * from gridlog order by creationdate desc;

select * from gridlog where eventcause='Create Valuation Valuation Mode= Position' order by creationdate desc;
select * from cstinterfaceaudit order by creationdate desc;

-- they are positions!!
select t.* from trade t, position p where p.trade=t.trade and
p.position in (215823 , 215824 , 215825 , 215826 , 215827);
select t.* from trade t, position p where p.trade=t.trade and
p.position in (215828 , 215835 , 215836 , 215837 , 215838);

select * from powerquantity
where creationname = 'DM2c'
and tsperiod = 'Off Peak'
and he2 is NULL
and begtime not in ( '2014-10-26 02:00:00.000' , '2013-10-27 02:00:00.000' , '2012-10-28 02:00:00.000' , '2011-10-30 02:00:00.000' , '2015-10-25 02:00:00.000' )

select * from powerquantity
where creationname = 'DM2c'
and tsperiod = 'Peak'
and he9 is NULL

update powerquantity
set he2 = 0,  he3 = 0,  he4 = 0,  he5 = 0,  he6 = 0,  he7 = 0,  he8 = 0, he21 = 0,  he22 = 0,  he23 = 0,  he24 = 0
where creationname = 'DM2c'
and tsperiod = 'Off Peak'
and he2 is NULL
and begtime not in ( '2014-10-26 02:00:00.000' , '2013-10-27 02:00:00.000' , '2012-10-28 02:00:00.000' , '2011-10-30 02:00:00.000' , '2015-10-25 02:00:00.000' )

update powerquantity
set he9 = 0,  he10 = 0,  he11 = 0,  he12 = 0,  he13 = 0,  he14 = 0,  he15 = 0, he16 = 0,  he17 = 0,  he18 = 0,  he19 = 0, he20 = 0
where creationname = 'DM2c'
and tsperiod = 'Peak'
and he9 is NULL


select * from powerquantity
where creationname = 'DM2c'
and tsperiod = 'Off Peak'
and he2 is NULL
and begtime not in ( '2014-10-26 02:00:00.000' , '2013-10-27 02:00:00.000' , '2012-10-28 02:00:00.000' , '2011-10-30 02:00:00.000' , '2015-10-25 02:00:00.000' )

select * from powerquantity
where creationname = 'DM2c'
and tsperiod = 'Peak'
and he9 is NULL


-- version: 481 module: allegro-collection date: 2013-07-04 15:49:46 
-- applied to:  HEAD 

--AllegroUAT;
select count(*) from trayportsequence;  -- 52550 righe
select distinct seqname from trayportsequence;
select * from trayportsequence;

-- AllegroSAT
select count(*) from trayportsequence; -- solo 219 con instdefinitionid settati un po' strani
select * from trayportsequence;



-- version: 482 module: allegro-collection date: 2013-07-04 16:50:51 
-- applied to:  HEAD 


--UAT - Reference

-- three exports from UAT which need to be reimported in SAT
select * from trayportinstrument where tradetype<>'';
select distinct ts.* from trayportsequence ts, trayportinstrument ti where ts.instdefinitionid=ti.instdefinitionid and ti.tradetype<>'';
select distinct tsi.* from trayportsequenceitem tsi, trayportsequence ts, trayportinstrument ti 
where 
ts.instdefinitionid=ti.instdefinitionid and ti.tradetype<>'' and
tsi.seqid=ts.seqid;


-- counts of sequenceitem
select * from trayportsequenceitem;
select count(*) from trayportsequenceitem;


-- version: 484 module: allegro-collection date: 2013-07-08 18:05:37 
-- applied to:  HEAD 

select * from pricevalue where priceindex='Power NP Base Settle' order by pricedate desc;


select distinct pricedate from pricevalue where priceindex='Power NP Base Year Forward' order by pricedate desc;

select sum(price) from pricevalue where priceindex='Power NP Base Year Forward' and pricedate='2013-07-07';
select sum(price) from pricevalue where priceindex='Power NP Base Year Forward' and pricedate='2013-07-05';

select distinct pricedate from pricevalue where priceindex='Power NP Base Year Forward' order by pricedate desc;


select pricedate, sum(price) from pricevalue where priceindex='Power IDEX Base Month Forward' group by pricedate order by pricedate desc;

select pricedate, sum(price) from pricevalue where priceindex='Power IT IPEX PUN Hour Forward' group by pricedate order by pricedate desc;
select pricedate, sum(price) from pricevalue where priceindex='Power DE Hour Forward' group by pricedate order by pricedate desc;
select pricedate, sum(price) from pricevalue where priceindex='It - Mix 80-20 Forward' group by pricedate order by pricedate desc;


-- version: 485 module: allegro-collection date: 2013-07-09 15:16:54 
-- applied to:  HEAD 

select * from pricevalue where pricedate='2013-06-28' and priceindex='Gas NBP Month Forward' order by pricedate asc;

select * from pricevalue where /*pricedate='2013-05-31' and */priceindex='Gas NBP Month Forward' order by pricedate asc;


select * from pricevalue where priceindex='Gas NBP Settle' order by pricedate asc;


select * from valuation where valuationtime='2013-07-04 23:00';
select * from valuationdetail where valuation=104187 and marketarea like '%NBP%' 
and begtime>='2013-07-01' and endtime<='2013-08-01' and trade=212583
order by valuationdetail asc;

select * from trade where trade in (212583, 212584);


-- version: 494 module: allegro-collection date: 2013-07-30 11:19:52 
-- applied to:  HEAD 

USE [AllegroUAT]
GO

/****** Object:  StoredProcedure [dbo].[cspEoDContractValueDetail3]    Script Date: 08/08/2013 14:18:55 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[cspEoDContractValueDetail3]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[cspEoDContractValueDetail3]
GO

USE [AllegroUAT]
GO

/****** Object:  StoredProcedure [dbo].[cspEoDContractValueDetail3]    Script Date: 08/08/2013 14:18:55 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



-- =============================================
-- Author: Jeremy Gann, Tiziano Mengotti
-- Create date: 2013-07-05
-- Description: cspEoDContractValueDetail3
-- =============================================
CREATE PROCEDURE [dbo].[cspEoDContractValueDetail3]
@competencycentre varchar(32),
@positiontype varchar(16), -- either BUY or SELL, taken from position.positiontype
@producttype varchar(16),   --  taken from product.producttype
@fixvaluation varchar (32) = NULL
AS
/******
 
  Script:               cspEoDContractValueDetail3
  Script Date:          2011-08-31 18:43:09 
  Project:              Up-Trade
  Author:               JG, Logica / modified for multiple competency centers by TM, Repower
  Parameter:            @competencycentre: defines for which competency centre the export applies.
                        'POS' for Poschiavo, 'MIL' for Milan and 'PRA' for Prague.
                        @positiontype: direction of the trades, either 'BUY' or 'SELL
                        @producttype: product, either 'Power', 'Emissions', 'Coal' or 'Natural Gas'  
                        @fixvaluation: this optional parameter can be passed, if older files need to be reconstructed.
                                       the parameter is the valuation number.
                        
  Description:          Mantis 1359 Credit export contract valuation detail results
                        Mantis 2799 IF70 - Extend Credit Risk Export for cc POS to cc MIL
                        
                        cspEoDContractValueDetail3 is the enhanced version of cspEodContractValueDetail to export
                        data for several competency centres.
                        
                        cspEoDContractValueDetail3 (codenamed IF70) generates an Excel file which includes the monthly contract value in Euro for the period 
                        (current-year-1, December)...(current-year+5, December) in monthly granularity, in direction SELL and BUY broken down by counterparty. 
                        This file is used by Risk Management to generate several reports, in particular the one needed for the Risk Management Committee, 
                        the Broker Report and the Trader Report.
  $Id: 

******/
BEGIN


        ---------------------------------------------------------------------
        -- Declarations
        ---------------------------------------------------------------------
        DECLARE @PivotColList AS VARCHAR(max)
        DECLARE @PivotQuery AS VARCHAR(max)
        DECLARE @SQL varchar(max)
        DECLARE @EoDValDate AS DATETIME
        DECLARE @EoDValTime AS DATETIME
        DECLARE @EoDVal AS VARCHAR(32)
        DECLARE @Timestamp AS VARCHAR(15)
        DECLARE @DBName AS VARCHAR(32)
        DECLARE @FileName AS VARCHAR(256)
        DECLARE @headerfile varchar(256)

        ------------------------------------------------------------------
        -- Initialise
        ------------------------------------------------------------------
--      PRINT 'cspEoDContractValueDetail: Begin'
--      PRINT '  Valuation='+ @pValuation

        IF ( OBJECT_ID('dbo.cstEoDContractValueDetail') IS NOT NULL ) 
           DROP TABLE dbo.cstEoDContractValueDetail

        IF @fixvaluation is NULL
        BEGIN
			------------------------------------------------------------------
			-- Identify yesterdays EoD Position valuation
			------------------------------------------------------------------
			SET @EoDValDate = DATEADD(day, DATEDIFF(day, 0, getdate())-1, 0)
			SET @EoDValTime = (     SELECT MAX(valuationtime)
                                                FROM valuation
                                                WHERE valuationmode = 'Position' AND
                                                          valuationtype = 'SUMMATION' AND
                                                          valuationstatus = 'COMPLETE' AND
                                                          valuationtime >= @EoDValDate AND
                                                          valuationtime < DATEADD(day, 1, @EoDValDate) AND
                                                          DATEPART(hour, valuationtime) >= 23 )
			SET @EoDVal = ( SELECT valuation
                                        FROM valuation
                                        WHERE valuationmode = 'Position' AND
                                                  valuationtype = 'SUMMATION' AND
                                                  valuationstatus = 'COMPLETE' AND
                                                  valuationtime = @EoDValTime )
        END
        ELSE
        BEGIN
            ------------------------------------------------------------------
			-- Use the valuation passed as parameter
			------------------------------------------------------------------
			SET @EoDVal=@fixvaluation;
			SET @EoDValTime=(select valuationtime from valuation where valuation=@fixvaluation);
			SET @EoDValDate=DATEADD(day, DATEDIFF(day, 0, @EodValTime)-1, 0);
			
        END
        
        ------------------------------------------------------------------
        -- Dynamically create list of pivot columns
        ------------------------------------------------------------------
        SET @PivotColList = NULL

        SELECT  @PivotColList = ISNULL(@PivotColList + ',', '') + '[' + tp.timeperiod + ']'
        FROM    valuation v,
                        cvwEoDMonthHistory mth,
                        timeperiod tp
        WHERE   v.valuation = @EoDVal AND
                        mth.monthsequence >= DATEADD(month, -1, DATEADD(year, DATEDIFF(year, 0, v.valuationtime), 0)) AND
                        mth.monthsequence < DATEADD(year, 6, DATEADD(year, DATEDIFF(year, 0, v.valuationtime), 0)) AND
                        tp.timeperiodclass = 'CAL' AND 
                        tp.method = 'FIXED' AND 
                        tp.timeunit = 'MONTH' AND 
                        tp.begtime <= mth.monthsequence AND 
                        tp.endtime > mth.monthsequence
                        
        PRINT @PivotColList

        ------------------------------------------------------------------
        -- Dynamically construct pivot table query
        ------------------------------------------------------------------
        SET @PivotQuery = 'SELECT 
                Counterparty,
                Elements,
                Unit,
                ' + @PivotColList + ' 
        INTO cstEoDContractValueDetail
        FROM (SELECT     vd.counterparty as Counterparty,
                         ''Amount'' as Elements,
                         vd.currency as Unit,
                         vd.cstdeliverymonth,
                         SUM(vd.value) AS value
                FROM valuation v,
                         valuationdetail vd,
                         position p
                   
                WHERE v.valuation = ' + @EoDVal + ' AND
                          v.valuationmode = ''Position'' AND
                          v.valuationtype = ''SUMMATION'' AND
                          v.valuationstatus = ''COMPLETE'' AND
                          vd.valuation = v.valuation AND
                          vd.exposure = ''POSITION'' AND
                          vd.quantitytype <> ''LOSS'' AND
                          vd.counterparty <> vd.company AND 
                          vd.cstcompetencycentre = '''+@competencycentre+''' AND
                          vd.cstdeliverydate >= dateadd(month, -1, dateadd(year, datediff(year, 0, v.valuationtime), 0)) AND
                          vd.cstdeliverydate < dateadd(year, 6, dateadd(year, datediff(year, 0, v.valuationtime), 0)) AND
                          p.position = vd.position AND
                          p.positiontype = '''+@positiontype+''' AND
                          vd.producttype = '''+@producttype+'''
                GROUP BY         vd.counterparty,
                                 vd.currency,
                                 vd.cstdeliverymonth) AS cdbycol
                PIVOT (SUM(value)
                                FOR cstdeliverymonth
                                IN (' + @PivotColList + ')
                          ) AS valuebydeliverymonth'
          
        PRINT @PivotQuery
        
        ------------------------------------------------------------------
        -- Dynamically execute pivot table query
        ------------------------------------------------------------------

        EXEC(@PivotQuery)
        
        ------------------------------------------------------------------
        -- Execute Procedure to export to Excel
        ------------------------------------------------------------------

        SELECT @Timestamp = CONVERT(VARCHAR, @EoDValTime, 112) -- + '_' + REPLACE(CONVERT(VARCHAR, @EoDValTime, 108), ':', '') -- no hour needed
        
        -- FileName convention
        /*
         �	filemane convention: <YYYYMMDD>_<CC>_<COM>_<DIR>_credit_risk.csv where
			o	<YYYYMMDD> is Reference Date.
			o	<CC> is the competency center. Value List. POS, PRA, MIL
			o	<COM> is the commodity. Value list: PWR, GAS, CO2
			o	<DIR> is the trade direction. Value list: BUY, SEL
			o	example: 20130712_POS_PWR_SEL_credit_risk.csv
       
        */
        SET @FileName= @Timestamp+'_'+@competencycentre+'_';
        IF @producttype='Power' 
             SET @FileName = @FileName + 'PWR'
        ELSE IF @producttype='Emissions' 
			SET @FileName = @FileName + 'CO2'
		ELSE IF @producttype='Natural Gas' 
			SET @FileName = @FileName + 'GAS'
		ELSE IF @producttype='Coal' 
			SET @FileName = @FileName + 'COA'	
		SET @FileName = @FileName+'_';	
		
		IF @positiontype='BUY'
			SET @FileName = @FileName + 'BUY'
		ELSE
		IF @positiontype='SELL'
			SET @FileName = @FileName + 'SEL'
		SET @FileName = @FileName+'_credit_risk.xls';
        -- End of FileName convention
        
        -- take the header files in the folder above
        SET @headerfile = '..\headers\'+@competencycentre+'_'+@producttype+'_'+@positiontype+'.xls';
        
        SET @SQL = 'EXEC dbo.cspExportToExcelWithHeader ''cstEoDContractValueDetail'', ''EoD Contract Value Export '+@competencycentre+''', '''+@HeaderFile+''', '''+@FileName+''', ''order by Counterparty, Unit'''
        PRINT @SQL
        EXEC(@SQL)      
END

GO




-- version: 495 module: allegro-collection date: 2013-07-30 16:21:54 
-- applied to:  HEAD 

USE [Allegro]
GO

/****** Object:  StoredProcedure [dbo].[cspExportToExcelWithHeader]    Script Date: 08/02/2013 09:47:51 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[cspExportToExcelWithHeader]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[cspExportToExcelWithHeader]
GO

USE [Allegro]
GO

/****** Object:  StoredProcedure [dbo].[cspExportToExcelWithHeader]    Script Date: 08/02/2013 09:47:51 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[cspExportToExcelWithHeader]
(
	@TableName    VARCHAR(100),
	@DocumentType VARCHAR(100),
	@HeaderFile   VARCHAR(256),
	@OutputFileName  VARCHAR(256),
	@OrderBy	  VARCHAR(1000) = ''
)
/******
 
  Script:		cspExportToExcelWithHeader
  Script Date:		2011-08-31 18:43:09 
  Project:		Up-Trade
  Author:		AM, Logica; TM, Repower
  Description:		Mantis 1359 Credit export contract valuation detail results

  $Id: 

******/
AS

DECLARE @Columns  VARCHAR(8000)
DECLARE @SQL      VARCHAR(8000)
DECLARE @DataFile VARCHAR(100)
DECLARE @ColumnFile VARCHAR(100)
DECLARE @Path     VARCHAR(100)
DECLARE @DBName   VARCHAR(100)

------------------------------------------------------------------
-- Select document properties from DB
------------------------------------------------------------------
SELECT @Path=outputlocation
FROM documentformat
WHERE documentformat = @DocumentType

SELECT @DBName = DB_NAME()

IF ( OBJECT_ID('dbo.' + @TableName) IS NOT NULL )
	BEGIN
		SELECT @Columns=coalesce(@Columns+',','')+column_name+' as '''''+column_name+''''''
		FROM information_schema.columns
		WHERE table_name=@TableName
		SELECT @Columns=''''''+replace(replace(@Columns,' as ',''''' as '),',',',''''')
		
		SELECT @DataFile= 'data_file.xls'
		SELECT @ColumnFile= 'column_file.xls'

        SET @SQL= 'EXEC master..xp_cmdshell ''type '+ @Path + '\' + @HeaderFile+' > "' + @Path + '\' + @OutputFileName +'"'''
		EXEC(@SQL)

		SET @SQL='EXEC master..xp_cmdshell ''bcp "select * from (select '+@Columns+') as t" queryout "'+ @Path + '\' + @ColumnFile + '" -c -T'''
		EXEC(@SQL)
		
		SET @SQL= 'EXEC master..xp_cmdshell ''type '+ @Path + '\' + @ColumnFile+' >> "' + @Path + '\' + @OutputFileName +'"'''
		EXEC(@SQL)

		SET @SQL='EXEC master..xp_cmdshell ''bcp "select * from [' + @DBName + '].dbo.' + @TableName + ' ' + @OrderBy + '" queryout "' + @Path + '\' + @DataFile +'" -c -T'''
		EXEC(@SQL)

		SET @SQL= 'EXEC master..xp_cmdshell ''type '+ @Path + '\' + @DataFile+' >> "' + @Path + '\' + @OutputFileName +'"'''
		EXEC(@SQL)
		
		SET @SQL= 'EXEC master..xp_cmdshell ''del '+ @Path + '\' + @DataFile+''''
		EXEC(@SQL)
		
		SET @SQL= 'EXEC master..xp_cmdshell ''del '+ @Path + '\' + @ColumnFile+''''
		EXEC(@SQL)
		
	END
ELSE

	BEGIN
		SET @SQL='EXEC master..xp_cmdshell ''bcp "select ''''ERROR - No Data To Export''''" queryout "' + @Path + '\' + @OutputFileName +'" -c -T'''
		EXEC(@sql)
	END

GO




-- version: 496 module: allegro-collection date: 2013-07-30 16:33:20 
-- applied to:  HEAD 

-- AllegroUAT					
EXEC cspEoDContractValueDetail3 'POS', 'BUY', 'Power';
EXEC cspEoDContractValueDetail3 'POS', 'SELL', 'Power';
EXEC cspEoDContractValueDetail3 'POS', 'BUY', 'Emissions';
EXEC cspEoDContractValueDetail3 'POS', 'SELL', 'Emissions';
EXEC cspEoDContractValueDetail3 'MIL', 'BUY', 'Power';
EXEC cspEoDContractValueDetail3 'MIL', 'SELL', 'Power';
EXEC cspEoDContractValueDetail3 'MIL', 'BUY', 'Emissions';
EXEC cspEoDContractValueDetail3 'MIL', 'SELL', 'Emissions';

select distinct producttype from product;



-- version: 497 module: allegro-collection date: 2013-07-31 11:40:37 
-- applied to:  HEAD 

select pricedate, priceindex, CONVERT(char(8),CAST(AVG(CAST(creationdate AS FLOAT) - FLOOR(CAST(creationdate AS FLOAT))) AS datetime),108)
AS time, count(*) as entries, sum(price)/count(*) as avgprice from pricevalue where priceindex like '%Forwar%' and 
creationdate>GETDATE()-2 group by pricedate, priceindex order by pricedate, priceindex;


-- version: 498 module: allegro-collection date: 2013-07-31 16:41:49 
-- applied to:  HEAD 

select t.* from powerquantity pq, position p, trade t 
where pq.surrogate in (16854491, 17005898) and pq.position=p.position and p.trade=t.trade;
select * from powerquantity where surrogate in (16854491, 17005898);


select t.* from powerquantity pq, position p, trade t 
where pq.surrogate in (16854494, 17005906) and pq.position=p.position and p.trade=t.trade;
select * from powerquantity where surrogate in (16854494, 17005906);


select * from pricevalue where priceindex='Power IT IPEX North Hour Settle' and pricedate>='2013-06-28'
and pricedate<'2013-07-12' order by priceindex asc;


-- version: 500 module: allegro-collection date: 2013-08-06 08:05:19 
-- applied to:  HEAD 

select * from pricevalue where priceindex='CO2 EUA Forward' and pricedate='2013-08-05';
select * from pricevalue where priceindex='Coal API2ICE Month Forward' and pricedate='2013-08-05';


-- version: 502 module: allegro-collection date: 2013-08-06 08:14:49 
-- applied to:  HEAD 

select * from viewpane where viewpane='cstImmediatePriceAvail';
select * from viewcolumn where viewpane='cstImmediatePriceAvail';


-- version: 505 module: allegro-collection date: 2013-08-08 08:43:56 
-- applied to:  HEAD 

select c.counterparty, c.cstcounterpartystatus from counterparty c where c.cstcounterpartystatus in ('INVALID','INACTIVE'/*,'NOT ACCEPTED'*/) order by c.counterparty;
--select c.status, * from counterparty c where c.status in ('INVALID','INACTIVE');

--select distinct status from counterparty;
select distinct cstcounterpartystatus from counterparty;


select MAX(t.enddate) from trade t, position p where p.trade=t.trade and p.counterparty = 'EWE_OLDEN'


-- version: 508 module: allegro-collection date: 2013-08-08 14:35:04 
-- applied to:  HEAD 

--AllegroUAT
-- 1.8.2013
EXEC cspEoDContractValueDetail3 'POS', 'BUY', 'Power', 104275;
EXEC cspEoDContractValueDetail3 'POS', 'SELL', 'Power', 104275;
EXEC cspEoDContractValueDetail3 'POS', 'BUY', 'Emissions', 104275;
EXEC cspEoDContractValueDetail3 'POS', 'SELL', 'Emissions', 104275;

UPDATE valuation set valuationmode='Position' where valuation=104294;
EXEC cspEoDContractValueDetail3 'MIL', 'BUY', 'Power', 104294;
EXEC cspEoDContractValueDetail3 'MIL', 'SELL', 'Power', 104294;
EXEC cspEoDContractValueDetail3 'MIL', 'BUY', 'Emissions', 104294;
EXEC cspEoDContractValueDetail3 'MIL', 'SELL', 'Emissions', 104294;
UPDATE valuation set valuationmode='Position MIL' where valuation=104294;

--analysis why it does not work
select vd.cstcompetencycentre,count(*) from valuationdetail vd where vd.valuation=104294 
group by vd.cstcompetencycentre;

select vd.product,count(*) from valuationdetail vd where vd.valuation=104294 group by vd.product;
select vd.product,count(*) from valuationdetail vd where vd.valuation=104275 group by vd.product;

select p.positiontype,count(*) from valuationdetail vd, position p where vd.valuation=104294
and vd.position=p.position group by p.positiontype; 



--2.8.2013
EXEC cspEoDContractValueDetail3 'POS', 'BUY', 'Power', 104278;
EXEC cspEoDContractValueDetail3 'POS', 'SELL', 'Power', 104278;
EXEC cspEoDContractValueDetail3 'POS', 'BUY', 'Emissions', 104278;
EXEC cspEoDContractValueDetail3 'POS', 'SELL', 'Emissions', 104278;

UPDATE valuation set valuationmode='Position' where valuation=104295;
EXEC cspEoDContractValueDetail3 'MIL', 'BUY', 'Power', 104295;
EXEC cspEoDContractValueDetail3 'MIL', 'SELL', 'Power', 104295;
EXEC cspEoDContractValueDetail3 'MIL', 'BUY', 'Emissions', 104295;
EXEC cspEoDContractValueDetail3 'MIL', 'SELL', 'Emissions', 104295;
UPDATE valuation set valuationmode='Position MIL' where valuation=104295;


--3.8.2013
EXEC cspEoDContractValueDetail3 'POS', 'BUY', 'Power', 104281;
EXEC cspEoDContractValueDetail3 'POS', 'SELL', 'Power', 104281;
EXEC cspEoDContractValueDetail3 'POS', 'BUY', 'Emissions', 104281;
EXEC cspEoDContractValueDetail3 'POS', 'SELL', 'Emissions', 104281;

UPDATE valuation set valuationmode='Position' where valuation=104296;
EXEC cspEoDContractValueDetail3 'MIL', 'BUY', 'Power', 104296;
EXEC cspEoDContractValueDetail3 'MIL', 'SELL', 'Power', 104296;
EXEC cspEoDContractValueDetail3 'MIL', 'BUY', 'Emissions', 104296;
EXEC cspEoDContractValueDetail3 'MIL', 'SELL', 'Emissions', 104296;
UPDATE valuation set valuationmode='Position MIL' where valuation=104296;


-- version: 509 module: allegro-collection date: 2013-08-09 08:13:19 
-- applied to:  HEAD 

select validation, * from valuationdetail where valuation=104294 and trade=214325;

select trade, validation, * from valuationdetail where (validation is not null) and validation<>''
and valuation=104294;


-- version: 510 module: allegro-collection date: 2013-08-09 14:44:47 
-- applied to:  HEAD 

--AllegroTarget
select * from pricevalue where priceindex='Power DE Hour Forward' and pricedate='2013-08-08';
select * from pricevalue where priceindex='Power DE Offpeak Settle' and pricedate='2013-08-08';



-- updating synchronization information for the database schema
INSERT INTO tbsynchronize (PROJECTNAME, VERSIONNR, BRANCHNAME, TAGNAME, UPDATE_USER, UPDATE_TYPE, UPDATE_FROMVERSION, UPDATE_FROMSOURCE, DBTYPE)
VALUES ('Allegro-Project', 510, 'HEAD', '', 'time', 'dbredactor-client', 267, 'HEAD', 'sqlserver');
-- all scripts to reach db HEAD beginning from version 510 on date 2013-08-09
-- synchronization script generated in 1.1403 seconds



