#!/bin/bash
# nothing needed for mysql, script is okay
