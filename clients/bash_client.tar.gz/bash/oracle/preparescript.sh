#!/bin/bash
echo "quit" >> $1
