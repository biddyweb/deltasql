#!/bin/bash
# don't do anything, just remove rawversion.txt
rm $1
