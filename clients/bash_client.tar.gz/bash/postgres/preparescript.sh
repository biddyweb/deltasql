#!/bin/bash
# nothing needed for postgresql, script is okay
