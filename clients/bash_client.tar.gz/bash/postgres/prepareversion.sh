#!/bin/bash
mv $1 $2
