rm *~
rm *.pyc
rm script.sql
rm script.out
rm project.properties
rm fullscript.out
