To get the deltasql pyclient running, you need the package MySQL-python. E.g. to install it on Fedora, launch
yum install MySQL-python
Do something similar to get the package MySQL-python for your Linux installation.

More info on how to install and use the Python client at
http://www.deltasql.org/deltasql/manual.php#install-pyclient

To start, please edit the configuration file config.ini with your settings. Launch the Python client with ./pyclient.py once you made everything executable with 
chmod 755 *.py

Note: the unit SimpleConfigParser.py is copyright by Philippe Lagadec

