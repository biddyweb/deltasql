#!/bin/bash
rm test.sql
rm -rf backup
rm -rf lib