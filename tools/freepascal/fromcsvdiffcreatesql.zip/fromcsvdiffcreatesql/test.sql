UPDATE test SET C=98,D=99 WHERE id=1;
DELETE FROM test WHERE id=2;
UPDATE test SET A='1',B='2',C=3,D=4 WHERE id=6;
INSERT test (A,B,C,D) VALUES('New row','This is a new row',4,5);
